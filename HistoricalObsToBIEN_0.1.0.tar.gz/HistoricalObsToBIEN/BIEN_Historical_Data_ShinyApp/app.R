for (f in list.files("R", pattern = "\\.R$", full.names = TRUE)) {
  source(f, local = TRUE)
}

library(shiny)

reconcile_taxonomy_local <- function(scientific_names) {
  if (length(scientific_names) == 0) {
    return(data.frame(
      scientificName = character(0),
      canonicalName = character(0),
      status = character(0),
      note = character(0),
      stringsAsFactors = FALSE
    ))
  }

  x <- trimws(as.character(scientific_names))
  x[is.na(x)] <- ""

  # Simple local parser to flag likely unresolved names before external backbone checks.
  status <- ifelse(
    x == "",
    "UNRESOLVED",
    ifelse(grepl("\\b(sp|spp|cf|aff|indet)\\.?$", tolower(x)), "REVIEW", "CANDIDATE")
  )

  canonical <- gsub("\\s+", " ", x)
  canonical <- sub("\\s+(subsp\\.|var\\.|forma)\\s+.*$", "", canonical, ignore.case = TRUE)

  note <- ifelse(
    status == "REVIEW",
    "Contains uncertain qualifier (sp./cf./aff./indet)",
    ifelse(status == "UNRESOLVED", "Blank scientificName", "Candidate for external taxonomy backbone")
  )

  data.frame(
    scientificName = x,
    canonicalName = canonical,
    status = status,
    note = note,
    stringsAsFactors = FALSE
  )
}

read_local_app_version <- function(desc_path = "DESCRIPTION") {
  if (!file.exists(desc_path)) {
    return("unknown")
  }

  desc <- tryCatch(read.dcf(desc_path), error = function(e) NULL)
  if (is.null(desc) || !"Version" %in% colnames(desc)) {
    return("unknown")
  }

  as.character(desc[1, "Version"])
}

build_release_note <- function() {
  version_txt <- read_local_app_version()
  app_mtime <- tryCatch(format(file.info("app.R")$mtime, "%Y-%m-%d %H:%M"), error = function(e) "unknown")
  paste0("Build ", version_txt, " | app.R updated ", app_mtime, " | includes GNRS preview and submission packet export")
}

write_submission_packet <- function(zipfile, combined_tbl, join_audit_tbl, mapping_tbl, qc_tbl, bien_tbl, handoff_tbls, join_conflicts_tbl = NULL) {
  packet_dir <- file.path(tempdir(), paste0("historical_obs_packet_", as.integer(Sys.time())))
  dir.create(packet_dir, recursive = TRUE, showWarnings = FALSE)

  file_specs <- list(
    list(name = "combined_observation_stream.csv", data = combined_tbl, description = "Linked source table after chosen joins."),
    list(name = "join_audit_report.csv", data = join_audit_tbl, description = "Join coverage and cardinality audit."),
    list(name = "active_mapping.csv", data = mapping_tbl, description = "Current source-to-Darwin-Core mapping used in build step."),
    list(name = "dwc_qc_report.csv", data = qc_tbl, description = "QC results for the Darwin Core draft."),
    list(name = "bien_loading_table.csv", data = bien_tbl, description = "Draft BIEN loading table with staging and augmentation columns."),
    list(name = "tnrs_handoff.csv", data = handoff_tbls$tnrs, description = "Draft TNRS handoff for external name reconciliation."),
    list(name = "gnrs_handoff.csv", data = handoff_tbls$gnrs, description = "Draft GNRS handoff with GNRS-ready geography fields."),
    list(name = "gvs_handoff.csv", data = handoff_tbls$gvs, description = "Draft GVS handoff for coordinate review."),
    list(name = "nsr_handoff.csv", data = handoff_tbls$nsr, description = "Draft NSR handoff for native-status review.")
  )

  if (!is.null(join_conflicts_tbl) && is.data.frame(join_conflicts_tbl) && nrow(join_conflicts_tbl) > 0) {
    file_specs[[length(file_specs) + 1]] <- list(
      name = "join_duplicate_conflict_report.csv",
      data = join_conflicts_tbl,
      description = "Conflicting duplicate metadata values detected during join review."
    )
  }

  manifest_rows <- lapply(file_specs, function(spec) {
    out_path <- file.path(packet_dir, spec$name)
    utils::write.csv(spec$data, out_path, row.names = FALSE)
    data.frame(
      file_name = spec$name,
      description = spec$description,
      n_rows = if (is.data.frame(spec$data)) nrow(spec$data) else NA_integer_,
      stringsAsFactors = FALSE
    )
  })
  manifest <- do.call(rbind, manifest_rows)
  utils::write.csv(manifest, file.path(packet_dir, "submission_packet_manifest.csv"), row.names = FALSE)

  readme_lines <- c(
    "Historical Observation Data to BIEN - Submission Packet",
    paste0("Build note: ", build_release_note()),
    "",
    "Contents:",
    "- BIEN loading draft",
    "- TNRS, GNRS, GVS, and NSR handoff tables",
    "- Join audit, active mapping, QC report",
    "- Optional duplicate-join conflict report when conflicts were detected",
    "- submission_packet_manifest.csv describing the included files",
    "",
    "These are draft handoff tables and require downstream external review before BIEN submission."
  )
  writeLines(readme_lines, file.path(packet_dir, "README_submission_packet.txt"), useBytes = TRUE)

  old_wd <- setwd(packet_dir)
  on.exit(setwd(old_wd), add = TRUE)
  utils::zip(zipfile = zipfile, files = list.files(packet_dir, all.files = FALSE))
}

ui <- fluidPage(
  titlePanel("Historical Observation Data to BIEN"),
  tags$div(
    style = "margin: 10px 0; padding: 10px; background: #eef6ff; border-left: 4px solid #2f6fab;",
    strong("Goal: "),
    "Upload flat files, link tables, map to Darwin Core, run validation, and export BIEN draft handoff tables."
  ),
  tags$div(
    style = "margin: 0 0 10px 0; color: #5a6b7a; font-size: 0.9em;",
    build_release_note()
  ),
  sidebarLayout(
    sidebarPanel(
      h4("Data Source"),
      checkboxInput("use_tutorial_data", "Use built-in tutorial fake data", value = FALSE),
      fileInput("input_csv", "Upload CSV File(s)", accept = ".csv", multiple = TRUE),
      tags$hr(),
      h4("Step Actions"),
      actionButton("prepare_btn", "Step 2: Prepare Linked Table", class = "btn-primary"),
      actionButton("suggest_btn", "Step 3: Suggest Mapping", class = "btn-primary"),
      fileInput("mapping_csv", "Optional Mapping Override CSV", accept = ".csv"),
      actionButton("build_btn", "Step 5: Build BIEN Draft Tables", class = "btn-success"),
      tags$hr(),
      h4("Downloads"),
      tags$p(
        style = "font-size: 0.9em; color: #555;",
        "Use these only after Step 5 build succeeds. TNRS handoff is a name-check file (occurrenceID + scientificName) for external taxonomic resolution."
      ),
      downloadButton("download_combined", "Combined Source Table"),
      downloadButton("download_join_audit", "Join Audit Report"),
      downloadButton("download_mapping", "Active Mapping"),
      downloadButton("download_qc", "QC Report"),
      downloadButton("download_bien", "BIEN Loading Draft"),
      downloadButton("download_tnrs", "TNRS Handoff"),
      downloadButton("download_gnrs", "GNRS Handoff"),
      downloadButton("download_gvs", "GVS Handoff"),
      downloadButton("download_nsr", "NSR Handoff"),
      downloadButton("download_submission_packet", "Submission Packet Zip"),
      tags$hr(),
      tags$div(
        style = "padding: 10px; background: #fff8e1; border-left: 4px solid #c28b00; font-size: 0.92em;",
        strong("Important"),
        tags$p(
          style = "margin: 6px 0 0 0;",
          "Exports are draft handoff tables. Complete downstream TNRS, GNRS, GVS, and NSR review before BIEN submission."
        )
      )
    ),
    mainPanel(
      tabsetPanel(
        id = "workflow_tabs",
        tabPanel(
          "Step 1 Upload",
          h3("Step 1. Upload and Inspect Files"),
          uiOutput("merge_controls"),
          uiOutput("merge_plan_box"),
          h4("Suggested Merge Plan"),
          tableOutput("merge_plan_table"),
          h4("Loaded File Summary"),
          tableOutput("upload_summary_table"),
          h4("Primary File Preview"),
          tableOutput("primary_preview")
        ),
        tabPanel(
          "Step 2 Link",
          h3("Step 2. Link Observations with Metadata"),
          p("Select a primary observation file and one or more metadata files (location, plot, traits)."),
          h4("Join Audit"),
          uiOutput("join_warning_box"),
          tableOutput("join_audit_table"),
          h4("Linked Table Preview"),
          tableOutput("combined_preview")
        ),
        tabPanel(
          "Step 3 Map",
          h3("Step 3. Darwin Core Mapping"),
          p("Auto-suggestions come from header synonym matching plus BIEN-aware field matching. You can upload a mapping override CSV with source_column,dwc_term."),
          tags$div(
            style = "margin: 10px 0; padding: 10px; background: #f4f8ff; border-left: 4px solid #2f6fab;",
            strong("What to do now"),
            tags$ol(
              tags$li("Click 'Step 3: Suggest Mapping' in the left sidebar."),
              tags$li("Confirm key mappings: species column -> scientificName, lat -> decimalLatitude, long/lon -> decimalLongitude."),
              tags$li("If a DBH or diameter column is detected, the app may map it to measurementValue automatically and add measurementType = diameter_at_breast_height with a default unit when possible."),
              tags$li("Optional: upload a mapping override CSV if any suggested mapping is wrong."),
              tags$li("Then continue to Step 4 for taxonomy review.")
            )
          ),
          h4("Suggested Mapping"),
          tableOutput("mapping_table"),
          h4("Active Mapping"),
          tableOutput("active_mapping_table")
        ),
        tabPanel(
          "Step 4 Taxonomy",
          h3("Step 4. Taxonomic Reconciliation Triage"),
          p("This is a review step. You do not edit data here; you check whether scientific names look complete and sensible before building outputs."),
          tags$div(
            style = "margin: 10px 0; padding: 10px; background: #f9f9f9; border-left: 4px solid #666;",
            strong("How to use TNRS handoff"),
            tags$ol(
              tags$li("Complete Step 5 first so exports are generated."),
              tags$li("Download TNRS Handoff: this file contains occurrenceID + scientificName only."),
              tags$li("Run that file through a TNRS service/workflow to standardize or correct names."),
              tags$li("Join TNRS results back to occurrenceID in your BIEN workflow records.")
            )
          ),
          h4("Taxonomy Summary"),
          tableOutput("taxonomy_summary"),
          h4("Names Requiring Review"),
          tableOutput("taxonomy_review")
        ),
        tabPanel(
          "Step 5 Validate",
          h3("Step 5. QC Validation"),
          h4("QC Dashboard"),
          tableOutput("qc_table"),
          h4("Build Summary"),
          verbatimTextOutput("summary_text")
        ),
        tabPanel(
          "Step 6 Export",
          h3("Step 6. Export BIEN Draft Tables"),
          p("Download the draft loading and handoff tables for external validation and BIEN review."),
          tags$div(
            style = "margin: 10px 0; padding: 10px; background: #eef7ee; border-left: 4px solid #3a7d44;",
            strong("What is in the BIEN Loading Draft now"),
            tags$ul(
              tags$li("Mapped Darwin Core fields plus BIEN-backed taxonomy and coordinate augmentation columns."),
              tags$li("Explicit staging status columns so you can see which rows still need review before BIEN loading."),
              tags$li("GNRS-ready location fields and query identifiers in the GNRS handoff export."),
              tags$li("Submission Packet Zip bundles the BIEN draft, handoff tables, QC, mapping, join audit, and a manifest file."),
              tags$li("These files are still draft handoff tables, not final proof that names or places are validated.")
            )
          ),
          h4("BIEN Loading Preview"),
          tableOutput("bien_preview"),
          h4("GNRS Handoff Preview"),
          tableOutput("gnrs_preview"),
          h4("Export Readiness"),
          verbatimTextOutput("export_readiness")
        ),
        tabPanel(
          "Help",
          h3("How to Use This App"),
          tags$ol(
            tags$li("Upload one or more observation and metadata CSV files or turn on tutorial mode."),
            tags$li("Choose primary and metadata join keys, then click 'Step 2: Prepare Linked Table'."),
            tags$li("Click 'Step 3: Suggest Mapping', confirm required Darwin Core terms, and review any automatic DBH measurement mapping."),
            tags$li("Review taxonomy triage and unresolved names."),
            tags$li("Click 'Step 5: Build BIEN Draft Tables' and resolve any BLOCK QC issues."),
            tags$li("Export the BIEN loading draft plus TNRS, GNRS, GVS, and NSR handoff tables for downstream review.")
          )
        )
      )
    )
  )
)

server <- function(input, output, session) {
  tutorial_files <- reactive({
    list(
      "tutorial_observations.csv" = read_historical_csv("inst/extdata/tutorial_observations.csv"),
      "sample_plot_metadata.csv" = read_historical_csv("inst/extdata/sample_plot_metadata.csv")
    )
  })

  available_files <- reactive({
    if (isTRUE(input$use_tutorial_data)) {
      return(tutorial_files())
    }
    req(input$input_csv)
    read_uploaded_csv_list(input$input_csv)
  })

  merge_plan <- reactive({
    files <- available_files()
    req(length(files) > 0)
    suggest_merge_plan(files)
  })

  output$merge_controls <- renderUI({
    files <- names(available_files())
    req(length(files) > 0)

    plan <- merge_plan()
    primary_default <- if (!is.null(plan$primary_file) && nzchar(plan$primary_file)) plan$primary_file else files[1]
    metadata_choices <- setdiff(files, primary_default)
    metadata_default <- intersect(metadata_choices, plan$metadata_files)

    tagList(
      selectInput("primary_file", "Primary observation file", choices = files, selected = primary_default),
      uiOutput("primary_key_ui"),
      selectizeInput("metadata_files", "Metadata file(s)", choices = metadata_choices, selected = metadata_default, multiple = TRUE),
      uiOutput("metadata_keys_ui")
    )
  })

  output$primary_key_ui <- renderUI({
    req(input$primary_file)
    df <- available_files()[[input$primary_file]]
    plan <- merge_plan()
    selected_key <- if (!is.null(plan$primary_key) && plan$primary_key %in% names(df)) plan$primary_key else names(df)[[1]]
    selectInput("primary_key", "Primary join key", choices = names(df), selected = selected_key)
  })

  output$metadata_keys_ui <- renderUI({
    req(input$metadata_files)
    plan <- merge_plan()

    controls <- lapply(input$metadata_files, function(f) {
      df <- available_files()[[f]]
      selected_key <- NULL
      if (is.data.frame(plan$join_suggestions) && nrow(plan$join_suggestions) > 0) {
        hit <- plan$join_suggestions[plan$join_suggestions$metadata_file == f, , drop = FALSE]
        if (nrow(hit) > 0 && hit$metadata_key[[1]] %in% names(df)) {
          selected_key <- hit$metadata_key[[1]]
        }
      }
      selectInput(
        inputId = paste0("meta_key_", make.names(f)),
        label = paste0("Join key in metadata file: ", f),
        choices = names(df),
        selected = if (!is.null(selected_key)) selected_key else names(df)[[1]]
      )
    })

    do.call(tagList, controls)
  })

  output$merge_plan_box <- renderUI({
    plan <- merge_plan()

    if (!is.data.frame(plan$join_suggestions) || nrow(plan$join_suggestions) == 0) {
      return(tags$div(
        style = "margin: 8px 0 12px 0; padding: 10px; background: #eef6ff; border-left: 4px solid #2f6fab;",
        strong("Merge suggestion: "),
        "The app could not infer a high-confidence join pair automatically. Select the primary file and keys manually below."
      ))
    }

    best <- plan$join_suggestions[1, , drop = FALSE]
    tags$div(
      style = "margin: 8px 0 12px 0; padding: 10px; background: #eef6ff; border-left: 4px solid #2f6fab;",
      strong("Merge suggestion: "),
      paste0(
        "Use ", best$primary_file[[1]], " as the primary observation file, then join ",
        best$metadata_file[[1]], " by ", best$primary_key[[1]], " = ", best$metadata_key[[1]],
        " (shared unique values: ", best$shared_unique_values[[1]], ")."
      )
    )
  })

  output$merge_plan_table <- renderTable({
    plan <- merge_plan()
    if (!is.data.frame(plan$join_suggestions) || nrow(plan$join_suggestions) == 0) {
      return(data.frame(note = "No automatic merge candidates detected.", stringsAsFactors = FALSE))
    }
    plan$join_suggestions
  }, striped = TRUE, bordered = TRUE)

  output$upload_summary_table <- renderTable({
    plan <- merge_plan()
    req(is.data.frame(plan$file_summary))
    plan$file_summary
  }, striped = TRUE, bordered = TRUE)

  output$primary_preview <- renderTable({
    req(input$primary_file)
    utils::head(available_files()[[input$primary_file]], 10)
  }, striped = TRUE, bordered = TRUE)

  combined_state <- eventReactive(input$prepare_btn, {
    files <- available_files()
    req(length(files) > 0)
    req(input$primary_file)
    req(input$primary_key)

    metadata_files <- if (is.null(input$metadata_files)) character(0) else input$metadata_files
    metadata_keys <- setNames(vector("list", length(metadata_files)), metadata_files)

    for (f in metadata_files) {
      metadata_keys[[f]] <- input[[paste0("meta_key_", make.names(f))]]
    }

    merged <- merge_uploaded_streams(
      data_list = files,
      primary_file = input$primary_file,
      primary_key = input$primary_key,
      metadata_files = metadata_files,
      metadata_keys = metadata_keys
    )

    audit <- audit_join_quality(
      data_list = files,
      primary_file = input$primary_file,
      primary_key = input$primary_key,
      metadata_files = metadata_files,
      metadata_keys = metadata_keys
    )

    list(merged = merged, audit = audit)
  })

  combined_df <- reactive({
    req(combined_state())
    combined_state()$merged
  })

  join_audit <- reactive({
    req(combined_state())
    combined_state()$audit
  })

  suggested_mapping <- eventReactive(input$suggest_btn, {
    suggest_dwc_mapping(combined_df(), dictionary_path = "inst/dictionaries/header_synonyms.csv")
  })

  active_mapping <- reactive({
    req(suggested_mapping())

    if (!is.null(input$mapping_csv)) {
      m <- utils::read.csv(input$mapping_csv$datapath, stringsAsFactors = FALSE)
      needed <- c("source_column", "dwc_term")
      if (all(needed %in% names(m))) {
        return(m)
      }
    }

    data.frame(
      source_column = suggested_mapping()$source_column,
      dwc_term = suggested_mapping()$suggested_dwc_term,
      stringsAsFactors = FALSE
    )
  })

  build_state <- eventReactive(input$build_btn, {
    dwc <- apply_dwc_mapping(combined_df(), active_mapping())
    qc <- run_dwc_qc(dwc)
    list(dwc = dwc, qc = qc)
  })

  dwc_df <- reactive({
    req(build_state())
    build_state()$dwc
  })

  qc_df <- reactive({
    req(build_state())
    build_state()$qc
  })

  staging_preview_df <- reactive({
    req(build_state())
    build_bien_loading_table(dwc_df())
  })

  taxonomy_df <- reactive({
    if (!is.null(build_state())) {
      df <- dwc_df()
      if ("scientificName" %in% names(df)) {
        names_vec <- unique(df$scientificName)
      } else {
        names_vec <- character(0)
      }
    } else if (!is.null(combined_state()) && "scientificName" %in% names(combined_df())) {
      names_vec <- unique(combined_df()$scientificName)
    } else {
      names_vec <- character(0)
    }
    reconcile_taxonomy_local(names_vec)
  })

  bien_df <- reactive({
    req(build_state())
    validate(need(!qc_has_blockers(qc_df()), "QC blockers detected. Fix BLOCK issues before building BIEN outputs."))
    staging_preview_df()
  })

  handoff <- reactive({
    req(build_state())
    validate(need(!qc_has_blockers(qc_df()), "QC blockers detected. Fix BLOCK issues before exporting handoff tables."))
    build_bien_handoff_tables(staging_preview_df())
  })

  output$combined_preview <- renderTable({
    req(combined_df())
    utils::head(combined_df(), 12)
  }, striped = TRUE, bordered = TRUE)

  output$join_audit_table <- renderTable({
    req(join_audit())
    join_audit()
  }, striped = TRUE, bordered = TRUE)

  output$join_warning_box <- renderUI({
    req(join_audit())
    audit <- join_audit()

    if (nrow(audit) == 0 || !any(audit$duplicate_metadata_collapse)) {
      return(NULL)
    }

    tags$div(
      style = "margin: 8px 0 12px 0; padding: 12px; background: #fff3cd; border-left: 4px solid #b7791f;",
      strong("Duplicate metadata warning: "),
      "At least one metadata file has duplicate join keys. The merge uses first non-empty values per key. Review before export."
    )
  })

  output$mapping_table <- renderTable({
    req(suggested_mapping())
    suggested_mapping()
  }, striped = TRUE, bordered = TRUE)

  output$active_mapping_table <- renderTable({
    req(active_mapping())
    active_mapping()
  }, striped = TRUE, bordered = TRUE)

  output$taxonomy_summary <- renderTable({
    if (!is.null(build_state())) {
      bien_tbl <- staging_preview_df()
      data.frame(
        metric = c("Total records", "Unique submitted names", "BIEN/backbone matched", "Needs review", "Blank scientificName"),
        value = c(
          nrow(bien_tbl),
          length(unique(bien_tbl$scientificName)),
          sum(!is.na(bien_tbl$bien_matched_name) & trimws(as.character(bien_tbl$bien_matched_name)) != ""),
          sum(grepl("review|unresolved", bien_tbl$bien_taxonomy_status, ignore.case = TRUE), na.rm = TRUE),
          sum(is.na(bien_tbl$scientificName) | trimws(as.character(bien_tbl$scientificName)) == "")
        ),
        stringsAsFactors = FALSE
      )
    } else {
      tx <- taxonomy_df()
      data.frame(
        metric = c("Total unique names", "Candidate", "Review", "Unresolved"),
        value = c(
          nrow(tx),
          sum(tx$status == "CANDIDATE"),
          sum(tx$status == "REVIEW"),
          sum(tx$status == "UNRESOLVED")
        ),
        stringsAsFactors = FALSE
      )
    }
  }, striped = TRUE, bordered = TRUE)

  output$taxonomy_review <- renderTable({
    if (!is.null(build_state())) {
      bien_tbl <- staging_preview_df()
      review_idx <- grepl("review|unresolved", bien_tbl$bien_taxonomy_status, ignore.case = TRUE) |
        is.na(bien_tbl$scientificName) |
        trimws(as.character(bien_tbl$scientificName)) == ""
      bien_tbl[review_idx, c("occurrenceID", "scientificName", "bien_matched_name", "bien_taxonomy_status", "bien_family"), drop = FALSE]
    } else {
      tx <- taxonomy_df()
      tx[tx$status %in% c("REVIEW", "UNRESOLVED"), , drop = FALSE]
    }
  }, striped = TRUE, bordered = TRUE)

  output$qc_table <- renderTable({
    req(qc_df())
    qc_df()
  }, striped = TRUE, bordered = TRUE)

  output$summary_text <- renderText({
    req(build_state())
    req(active_mapping())

    req_terms <- required_dwc_terms()
    missing <- setdiff(req_terms, names(dwc_df()))

    metadata_count <- if (is.null(input$metadata_files)) 0 else length(input$metadata_files)
    join_blockers <- if (nrow(join_audit()) == 0) 0 else sum(join_audit()$severity == "BLOCK")
    join_warnings <- if (nrow(join_audit()) == 0) 0 else sum(join_audit()$severity == "WARN")
    qc_blocks <- qc_severity_count(qc_df(), "BLOCK")
    qc_warns <- qc_severity_count(qc_df(), "WARN")
    bien_matches <- if ("bien_matched_name" %in% names(staging_preview_df())) sum(!is.na(staging_preview_df()$bien_matched_name) & trimws(as.character(staging_preview_df()$bien_matched_name)) != "") else 0
    coord_ready <- if ("coordinate_valid_basic" %in% names(staging_preview_df())) sum(isTRUE(staging_preview_df()$coordinate_valid_basic), na.rm = TRUE) else 0

    paste(
      paste0("Loaded files: ", length(available_files())),
      paste0("Data mode: ", if (isTRUE(input$use_tutorial_data)) "Tutorial fake data" else "Uploaded files"),
      paste0("Metadata files joined: ", metadata_count),
      paste0("Combined rows (primary records): ", nrow(combined_df())),
      paste0("Join audit blockers: ", join_blockers, " | warnings: ", join_warnings),
      paste0("Mapped Darwin Core columns: ", ncol(dwc_df())),
      paste0("BIEN/backbone matched names: ", bien_matches),
      paste0("Rows with basic-valid coordinates: ", coord_ready),
      if (length(missing) == 0) "Required Darwin Core terms present: yes" else paste0("Missing required terms: ", paste(missing, collapse = ", ")),
      paste0("QC blockers: ", qc_blocks, " | warnings: ", qc_warns),
      if (qc_blocks > 0) "BIEN export blocked until BLOCK issues are fixed." else "Draft handoff tables generated.",
      sep = "\n"
    )
  })

  output$bien_preview <- renderTable({
    req(bien_df())
    utils::head(bien_df(), 10)
  }, striped = TRUE, bordered = TRUE)

  output$gnrs_preview <- renderTable({
    req(handoff())
    utils::head(handoff()$gnrs, 10)
  }, striped = TRUE, bordered = TRUE)

  output$export_readiness <- renderText({
    req(qc_df())
    if (qc_has_blockers(qc_df())) {
      "Export blocked: resolve BLOCK issues in Step 5 Validate before BIEN loading export."
    } else {
      "Export ready: download the BIEN loading draft with BIEN-backed taxonomy, coordinate, staging-status, and GNRS-ready augmentation plus TNRS/GNRS/GVS/NSR handoff files."
    }
  })

  output$download_combined <- downloadHandler(
    filename = function() "combined_observation_stream.csv",
    content = function(file) utils::write.csv(combined_df(), file, row.names = FALSE)
  )

  output$download_join_audit <- downloadHandler(
    filename = function() "join_audit_report.csv",
    content = function(file) utils::write.csv(join_audit(), file, row.names = FALSE)
  )

  output$download_mapping <- downloadHandler(
    filename = function() "active_mapping.csv",
    content = function(file) utils::write.csv(active_mapping(), file, row.names = FALSE)
  )

  output$download_qc <- downloadHandler(
    filename = function() "dwc_qc_report.csv",
    content = function(file) utils::write.csv(qc_df(), file, row.names = FALSE)
  )

  output$download_bien <- downloadHandler(
    filename = function() "bien_loading_table.csv",
    content = function(file) utils::write.csv(bien_df(), file, row.names = FALSE)
  )

  output$download_tnrs <- downloadHandler(
    filename = function() "tnrs_handoff.csv",
    content = function(file) utils::write.csv(handoff()$tnrs, file, row.names = FALSE)
  )

  output$download_gnrs <- downloadHandler(
    filename = function() "gnrs_handoff.csv",
    content = function(file) utils::write.csv(handoff()$gnrs, file, row.names = FALSE)
  )

  output$download_gvs <- downloadHandler(
    filename = function() "gvs_handoff.csv",
    content = function(file) utils::write.csv(handoff()$gvs, file, row.names = FALSE)
  )

  output$download_nsr <- downloadHandler(
    filename = function() "nsr_handoff.csv",
    content = function(file) utils::write.csv(handoff()$nsr, file, row.names = FALSE)
  )

  output$download_submission_packet <- downloadHandler(
    filename = function() paste0("historical_obs_submission_packet_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".zip"),
    content = function(file) {
      write_submission_packet(
        zipfile = file,
        combined_tbl = combined_df(),
        join_audit_tbl = join_audit(),
        mapping_tbl = active_mapping(),
        qc_tbl = qc_df(),
        bien_tbl = bien_df(),
        handoff_tbls = handoff(),
        join_conflicts_tbl = if (exists("join_conflicts", inherits = FALSE)) join_conflicts() else NULL
      )
    }
  )
}

shinyApp(ui = ui, server = server)
