#..........................................#
#...........Nutrient Network Project.......#
#...............Leaf Treat Study...........#
#....................SEM...................#
#..........................................#

#................................................................................#
#... Authors script: Eric                                                        #
#... Date of creation: May 31 2017                                               #
#... Contact: eric.harvey@umontreal.ca                                               #                                                                      
#................................................................................#

#########################################################################
################# DATA STRUCTURE
#########################################################################

##################
#Clear any variables from the R environment 
##################
rm(list=ls())

##################
#Directory paths 
##################
to.data <- "./data/"
to.script <- "./scripts/"
to.output <- "./output/"
to.figs <- "./figs/"
to.R <- "./R/"

##################
#Load library 
##################
library(vegan)
library(plyr)

##################
#Load data 
##################
load(paste0(to.output,"Wide.Rdata"))
DataT0 = droplevels(DataT0)
DataTx = droplevels(DataTx)
TraitTx = droplevels(TraitTx)

#Extract all species names for later use
sp0 = c(colnames(DataT0[,-c(1:6)]),colnames(DataTx[,-c(1:6)]),colnames(TraitTx[,-c(1:26)]))
sp = unique(sp0) 
dom.sp = colnames(TraitTx[,-c(1:26)])

#Remove rows with NAs to avoid further problems
# DataT0 = na.omit(DataT0)
# DataT1 = na.omit(DataT1)
# which(is.na(DataT1[,c(4,5,6,7,8)]))

#Verify if some empty rows or NAs in community matrix
which(rowSums(TraitTx[,colnames(TraitTx) %in% sp])==0)
which(rowSums(DataT0[,colnames(DataT0) %in% sp])==0)
which(rowSums(DataTx[,colnames(DataTx) %in% sp])==0)
which(is.na((TraitTx[,colnames(TraitTx) %in% sp])))
which(is.na((DataT0[,colnames(DataT0) %in% sp])))
which(is.na((DataTx[,colnames(DataTx) %in% sp])))

#Remove two empty rows in DataT1 
to.rm = TraitTx$megaCol[which(rowSums(TraitTx[,colnames(TraitTx) %in% sp])==0)]
DataTx = DataTx[-which(DataTx$megaCol %in% to.rm),]
TraitTx = TraitTx[-which(TraitTx$megaCol %in% to.rm),]
DataT0 = DataT0[-which(DataT0$megaCol %in% to.rm),]

##################
#Extract species turnover metrics
##################
{ 

#Prepare data (Create community matrices nrow by nspecies)
  #Create a column in each data to identify that it's either T0 or T1
  DataT0$Time = rep("T0",nrow(DataT0))
  DataTx$Time = rep("Tx",nrow(DataTx))
  
  #Merge both data frame so that all species are present in both T0 and T1 data
  merge.dat =  rbind.fill(DataT0, DataTx)
  
  #re-separate them (now will have the same number of columns)
  T0.dat = subset(merge.dat,Time=="T0")
  Tx.dat = subset(merge.dat,Time=="Tx")
  
  #Extract community matrices (nsites by nspecies)
  mat.T0 = T0.dat[,colnames(T0.dat) %in% sp]
  mat.T0[is.na(mat.T0)] = 0
  mat.Tx = Tx.dat[,colnames(Tx.dat) %in% sp]
  mat.Tx[is.na(mat.Tx)] = 0
  Mat.traitx = TraitTx[,-c(1:25)]
  Mat.Tx = DataTx[,colnames(DataTx) %in% sp]  
  

#colnames(mat.T0) %in% dom.sp instead use colnames(mat.T0) %in% colnames(TraitTx[i,-c(1:24)])
#Temporal turnover
Temp.turn = 0
for(i in 1:nrow(mat.Tx)){ 
    d = rbind(mat.T0[i,which(colnames(mat.T0) %in% colnames(Mat.traitx[i,]))],mat.Tx[i,which(colnames(mat.Tx) %in% colnames(Mat.traitx[i,]))])
    d = d[,colSums(d)>0]
    Temp.turn[i] =  vegdist(decostand(d,"hell"),"bray")}
summary(Temp.turn)

#Among-plots turnover per site 
# Space.turn1 = vector('numeric')
# Space.turn2 = vector('numeric')
# for(i in 1:nlevels(DataTx$site_code)) {
#   site = levels(DataTx$site_code)[i]
#   x = Mat.Tx[DataTx$site_code==site,which(colnames(Mat.Tx) %in% dom.sp)]
#   x = x[,colSums(x)>0]
#   Bray = vegdist(decostand(x,"hell"),"bray")
#   mds = metaMDS(Bray,autotransform=F)
#   mds1 = scores(mds)[,1]
#   mds2 = scores(mds)[,2]
#   Space.turn1 =  c(Space.turn1,mds1)
#   Space.turn2 =  c(Space.turn2,mds2)
#   }

#can save into .RData 
save(Temp.turn,file=paste0(to.output,"Species_turnover.RData"))
}


#########################################################################
################# STRUCTURAL EQUATION MODELING 
#########################################################################
library(lavaan)
library(lavaan.survey)
library(AICcmodavg)
library(semPlot)
load(paste0(to.data,"Species_turnover.RData"))

#Extract predictors of interest
colnames(TraitTx[,!colnames(TraitTx) %in% sp])
pred = c("site_code","block","year_trt","site_richness","SLA","SLA_v2","leaf_pct_N","leaf_pct_C","leaf_pct_P","leaf_pct_K","N",
         "P","K","MAT","MAP","MAP_VAR","TEMP_VAR","soil_C","soil_N","soil_P","soil_K","Exclosure","trt")

#Data frame for SEM
x = data.frame(TraitTx[,pred],Space.turn1,Space.turn2,Temp.turn)

#set experimental design
design <- svydesign(ids=~0, strata=~site_code/block, data=x)
#design <- svydesign(ids=~1, strata=~site_code/block, prob=~1, data=x)
#design <- svydesign(ids=~site_code+block, prob=~1, data=x)


#x = na.omit(x)
x$SLA_v2 = x$SLA_v2/10000

# 
Verify co-linearity among predictors and frequency distribution of each predictor
library(psych)
pdf(paste0(to.figure,'Cor_matrix.pdf'),width=15,height = 10)
pairs.panels(x,smooth=F,density=T,ellipses=F,lm=T,digits=3,scale=T, cor = T, rug=T)
dev.off()
detach("package:psych", unload=TRUE)

##################
#Simplified model version (no abiotic variables)
##################

#Model 1
mod1 <- '   
Temp.turn ~  N + P + K 
leaf_pct_N ~ N +  Temp.turn
leaf_pct_P ~ P + Temp.turn
leaf_pct_K ~ K + Temp.turn
leaf_pct_C ~ Temp.turn
SLA ~ N + P + K + Temp.turn
'
mod1.fit = sem(mod1,data=x,fixed.x=T) #run the SEM
survey.fit1 <- lavaan.survey(mod1.fit,design)
survey.fit1
summary(survey.fit, stand=T, rsq=T) #visualize path coefficients
mod1.fit #visualize fitting resultss
modindices(survey.fit1, sort.=T) #modification indices


#Model 2 - Adding leaf_pct_K ~ N based on modindices 

mod2 <- '   
Temp.turn ~  N + P + K
leaf_pct_N ~ N +  Temp.turn
leaf_pct_P ~ P + Temp.turn
leaf_pct_K ~ K + N + Temp.turn
leaf_pct_C ~ Temp.turn
SLA ~ N + P + K + Temp.turn
'

mod2.fit = sem(mod2,data=x,fixed.x=T) #run the SEM
survey.fit2 <- lavaan.survey(mod2.fit,design)
survey.fit2
summary(survey.fit2, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit2, sort.=T) #modification indices

#Model 3 - No modindices higher than 2 - prune all unsignificants
#Keep SLA ~ Temp.turn so that the three model have same variable sturcture and can be compared

mod3 <- '   
Temp.turn ~  P 
leaf_pct_N ~ N + Temp.turn
leaf_pct_P ~ P 
leaf_pct_K ~ K + N
leaf_pct_C ~ Temp.turn
SLA ~ Temp.turn
'

mod3.fit = sem(mod3,data=x,fixed.x=T) #run the SEM
survey.fit3 <- lavaan.survey(mod3.fit,design)
survey.fit3 
summary(survey.fit3, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit3, sort.=T) #modification indices


aictab(list(survey.fit1,survey.fit2,survey.fit3),c("mod1","mod2","mod3"))


##################
#Complex model version (with abiotic variables)
##################

#Addition of abiotic effects on Temp.turn
#then Temp.turn might in turn affect leaf nutrients. 

mod4 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N
leaf_pct_P ~ P + soil_P 
leaf_pct_K ~ K + N + soil_K 
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod4.fit = sem(mod4,data=x,fixed.x=T) #run the SEM
mod4.fit
survey.fit4 <- lavaan.survey(mod4.fit,design)
survey.fit4 
summary(survey.fit4, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit4, sort.=T) #modification indices


#leaf_pct_K ~  MAP 112.868 
mod5 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N
leaf_pct_P ~ P + soil_P 
leaf_pct_K ~ K + N + soil_K + MAP
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod5.fit = sem(mod5,data=x,fixed.x=T) #run the SEM
survey.fit5 <- lavaan.survey(mod5.fit,design)
survey.fit5
summary(survey.fit5, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit5, sort.=T) #modification indices

#leaf_pct_K  ~     soil_P 42.319 

mod6 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N
leaf_pct_P ~ P + soil_P 
leaf_pct_K ~ K + N + soil_K + MAP + soil_P
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod6.fit = sem(mod6,data=x,fixed.x=T) #run the SEM
survey.fit6 <- lavaan.survey(mod6.fit,design)
survey.fit6
summary(survey.fit6, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit6, sort.=T) #modification indices

#121 leaf_pct_N  ~  MAT 23.079 

mod7 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT
leaf_pct_P ~ P + soil_P 
leaf_pct_K ~ K + N + soil_K + MAP + soil_P
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod7.fit = sem(mod7,data=x,fixed.x=T) #run the SEM
survey.fit7 <- lavaan.survey(mod7.fit,design)
survey.fit7
summary(survey.fit7, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit7, sort.=T) #modification indices


#leaf_pct_P  ~        MAP 31.854 

mod8 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT
leaf_pct_P ~ P + soil_P + MAP
leaf_pct_K ~ K + N + soil_K + MAP + soil_P
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod8.fit = sem(mod8,data=x,fixed.x=T) #run the SEM
survey.fit8 <- lavaan.survey(mod8.fit,design)
survey.fit8
summary(survey.fit8, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit8, sort.=T) #modification indices

# leaf_pct_N  ~    MAP_VAR 18.774 

mod9 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR
leaf_pct_P ~ P + soil_P + MAP
leaf_pct_K ~ K + N + soil_K + MAP + soil_P
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod9.fit = sem(mod9,data=x,fixed.x=T) #run the SEM
survey.fit9 <- lavaan.survey(mod9.fit,design)
survey.fit9
summary(survey.fit9, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit9, sort.=T) #modification indices

# leaf_pct_N  ~     soil_K 22.740 
mod10 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K
leaf_pct_P ~ P + soil_P + MAP
leaf_pct_K ~ K + N + soil_K + MAP + soil_P
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod10.fit = sem(mod10,data=x,fixed.x=T) #run the SEM
survey.fit10 <- lavaan.survey(mod10.fit,design)
survey.fit10
summary(survey.fit10, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit10, sort.=T) #modification indices

#leaf_pct_K  ~        MAT 14.366 

mod11 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K
leaf_pct_P ~ P + soil_P + MAP
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod11.fit = sem(mod11,data=x,fixed.x=T) #run the SEM
survey.fit11 <- lavaan.survey(mod11.fit,design)
survey.fit11
summary(survey.fit11, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit11, sort.=T) #modification indices

#leaf_pct_P  ~        MAT 14.335
mod12 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K
leaf_pct_P ~ P + soil_P + MAP + MAT
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod12.fit = sem(mod12,data=x,fixed.x=T) #run the SEM
survey.fit12 <- lavaan.survey(mod12.fit,design)
survey.fit12
summary(survey.fit12, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit12, sort.=T) #modification indices

#leaf_pct_K  ~  Temp.turn
mod13 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K
leaf_pct_P ~ P + soil_P + MAP + MAT
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT + Temp.turn
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod13.fit = sem(mod13,data=x,fixed.x=T) #run the SEM
survey.fit13 <- lavaan.survey(mod13.fit,design)
survey.fit13
summary(survey.fit13, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit13, sort.=T) #modification indices

#leaf_pct_N  ~     soil_P 11.835
mod14 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P
leaf_pct_P ~ P + soil_P + MAP + MAT
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT + Temp.turn
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod14.fit = sem(mod14,data=x,fixed.x=T) #run the SEM
survey.fit14 <- lavaan.survey(mod14.fit,design)
survey.fit14
summary(survey.fit14, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit14, sort.=T) #modification indices

#leaf_pct_P  ~   TEMP_VAR  7.681 
mod15 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P
leaf_pct_P ~ P + soil_P + MAP + MAT + TEMP_VAR
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT + Temp.turn
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod15.fit = sem(mod15,data=x,fixed.x=T) #run the SEM
survey.fit15 <- lavaan.survey(mod15.fit,design)
survey.fit15
summary(survey.fit15, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit15, sort.=T) #modification indices

#leaf_pct_P  ~     soil_K 5.990  
mod16 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P
leaf_pct_P ~ P + soil_P + MAP + MAT + TEMP_VAR + soil_K
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT + Temp.turn
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod16.fit = sem(mod16,data=x,fixed.x=T) #run the SEM
survey.fit16 <- lavaan.survey(mod16.fit,design)
survey.fit16
summary(survey.fit16, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit16, sort.=T) #modification indices

#leaf_pct_P  ~    MAP_VAR 5.793 
mod17 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P
leaf_pct_P ~ P + soil_P + MAP + MAT + TEMP_VAR + soil_K + MAP_VAR
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT + Temp.turn
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod17.fit = sem(mod17,data=x,fixed.x=T) #run the SEM
survey.fit17 <- lavaan.survey(mod17.fit,design)
survey.fit17
summary(survey.fit17, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit17, sort.=T) #modification indices

#leaf_pct_N  ~        MAP 4.507 
mod18 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P + MAP
leaf_pct_P ~ P + soil_P + MAP + MAT + TEMP_VAR + soil_K + MAP_VAR
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT + Temp.turn
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod18.fit = sem(mod18,data=x,fixed.x=T) #run the SEM
survey.fit18 <- lavaan.survey(mod18.fit,design)
survey.fit18
summary(survey.fit18, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit18, sort.=T) #modification indices

#leaf_pct_P  ~          N 2.913 
mod19 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P + MAP
leaf_pct_P ~ P + soil_P + MAP + MAT + TEMP_VAR + soil_K + MAP_VAR + N
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT + Temp.turn
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod19.fit = sem(mod19,data=x,fixed.x=T) #run the SEM
survey.fit19 <- lavaan.survey(mod19.fit,design)
survey.fit19
summary(survey.fit19, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit19, sort.=T) #modification indices

#leaf_pct_N  ~          P 2.738 
mod20 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P + MAP + P
leaf_pct_P ~ P + soil_P + MAP + MAT + TEMP_VAR + soil_K + MAP_VAR + N
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT + Temp.turn
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod20.fit = sem(mod20,data=x,fixed.x=T) #run the SEM
survey.fit20 <- lavaan.survey(mod20.fit,design)
survey.fit20
summary(survey.fit20, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit20, sort.=T) #modification indices

#leaf_pct_K  ~   TEMP_VAR 2.268
mod21 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P + MAP + P
leaf_pct_P ~ P + soil_P + MAP + MAT + TEMP_VAR + soil_K + MAP_VAR + N
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT + Temp.turn + TEMP_VAR
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod21.fit = sem(mod21,data=x,fixed.x=T) #run the SEM
survey.fit21 <- lavaan.survey(mod21.fit,design)
survey.fit21
summary(survey.fit21, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit21, sort.=T) #modification indices

#leaf_pct_K  ~     soil_N 3.611 
mod22 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P + MAP + P
leaf_pct_P ~ P + soil_P + MAP + MAT + TEMP_VAR + soil_K + MAP_VAR + N
leaf_pct_K ~ K + N + soil_K + MAP + soil_P + MAT + Temp.turn + TEMP_VAR + soil_N
SLA ~ soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod22.fit = sem(mod22,data=x,fixed.x=T) #run the SEM
survey.fit22 <- lavaan.survey(mod22.fit,design)
survey.fit22
summary(survey.fit22, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit22, sort.=T) #modification indices

#no modification indices higher than 2 - prune all not significant paths at p<0.05
mod23 <- '   
Temp.turn ~  MAT + TEMP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P + MAP
leaf_pct_P ~ P + MAP + MAT + TEMP_VAR + soil_K + MAP_VAR
leaf_pct_K ~ K + soil_K + MAP + soil_P + MAT + Temp.turn + TEMP_VAR
SLA_v2 ~  soil_P + soil_K + MAT + MAP
'

mod23.fit = sem(mod23,data=x,fixed.x=T) #run the SEM
survey.fit23 <- lavaan.survey(mod23.fit,design)
survey.fit23
summary(survey.fit23, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit23, sort.=T) #modification indices
resid(survey.fit23)



##################
#Compare models
##################

#First sigificant model = model 10
#Select models 10 to 23
models = list()
for(i in 10:23){
  models[[i]] = eval(as.name(paste("survey.fit",i,sep="")))
}
models = models[10:23]

#Compare with AICc
aictab(models,paste("mod",10:23,sep=""))

#aictab(list(survey.fit10,survey.fit11,survey.fit12,survey.fit13,survey.fit14,survey.fit15,survey.fit16,survey.fit17,survey.fit18,survey.fit19,survey.fit20,survey.fit21,survey.fit22,survey.fit23),c(10:23))





interaction(x$site_code,x$block)
################################
#Aposteriori addition of variable (year_trt)

design <- svydesign(ids=~0, strata=~site_code/block, data=x)

mod24 <- '   
Temp.turn ~  MAT + TEMP_VAR + year_trt 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P + MAP + year_trt
leaf_pct_P ~ P + MAP + MAT + TEMP_VAR + soil_K 
leaf_pct_K ~ K + soil_K + MAP + soil_P + MAT + Temp.turn 
SLA ~  soil_P + soil_K + MAT + MAP 
'

mod24.fit = sem(mod24,data=x,fixed.x=T) #run the SEM
survey.fit24 <- lavaan.survey(mod24.fit,design)
survey.fit24
summary(survey.fit24, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit24, sort.=T) #modification indices
resid(survey.fit24)


#####
#Extract parameter estimates 
semPaths(survey.fit24,what="stand",layout="tree",edge.label.cex = 1,intercepts=F,residuals=F,exoCov=F)
semCors(survey.fit4)
write.csv(parameterEstimates(survey.fit24,standardized=T),paste0(to.output,'SEM.csv'))



##################
#END
##################


