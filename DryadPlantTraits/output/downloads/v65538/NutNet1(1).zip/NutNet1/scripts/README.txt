# Re-analysis following issues found in the data

The new corrected data file is named "foliar_cover_updated_2.csv".

The original path analysis models can be found in the R script "NutNet_LeafStudy_SEM.R"

The re-run of those analyses can be found in the R script "NutNet_LeafStudy_SEM_v2.R"

Nature of the issue found: SLA measures across the different replicated experiments were not in the same unit. In the new corrected data, that issue has been fixed. 

# Path analysis

My first objective was too verify whether the results remained qualitatively the same or not. Changing the scaling of a variable will always change the absolute value of the path coefficient but what matter is the change in relation to the other patch coefficients. 

Then, my second objective with the re-analysis was to assess whether the change in scaling affected the fit to the data and if so, whether new missing paths needed to be added or if others needed to be removed. 

To meet those objectives I did not re-run the 23 candidate models built in the original version of the analysis. Rather I only ran the first and last models for each for each "model run" (i.e., simplified version without abiotic factors vs. complex model with abiotic factors - see Methods section of the manuscript and supplementary information). This allowed me to evaluate whether results remained qualitatively the same between the initial and final model and if not what was missing from the model. 

# Instability from the lavaan.survey() function from the lavaan.survey package. 

During revision, I noticed an instability in the lavaan.survey function. For some reasons, sometime the lavaan.survey function will not converge even when the main model converges. The fact that the main model converge (with the sem() function) suggests that nothing is wrong with the model itself. One potential reason for this is the fact that the NutNet design is somewhat unbalanced because the number of block per site is not always the same. For now, the quick fix seems to be to re-run the specification of the design with the svydesign function several times until the lavaan.survey function runs properly. 

For future analysis with more complex design I would advise to use the "piecewise SEM" package now in its 2.0 edition that can now accommodate more complex designs 



