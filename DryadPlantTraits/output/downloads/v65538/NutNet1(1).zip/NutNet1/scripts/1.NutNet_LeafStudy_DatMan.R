#..........................................#
#...........Nutrient Network Project.......#
#...............Leaf Treat Study...........#
#..........SEM - DATA CLEANING SCRIPT...................#
#..........................................#

#................................................................................#
#... Authors script: Eric                                                        #
#... Date of creation: May 31 2017                                               #
#... Contact: eric.harvey@eawag.ch                                               #                                                                      
#................................................................................#

#########################################################################
################# DATA STRUCTURE
#########################################################################

##################
#Clear any variables from the R environment 
##################
rm(list=ls())

##################
#Directory paths 
##################
to.data <- "./data/"
to.script <- "./scripts/"
to.output <- "./output/"
to.figs <- "./figs/"
to.R <- "./R/"

##################
#Load data 
##################

Data.t0 = read.csv(paste0(to.data,"time zero cover data for functional trait NutNet.csv"), sep=",",header=T)
Data.tx = read.csv(paste0(to.data,"Tx community level.csv"), sep=",",header=T)
Traits.tx = read.csv(paste0(to.data,"foliar_cover_updated_2.csv"), sep=",",header=T)

#Verify that the three data sets correspond to each other
Traits.tx$site_code[!(Traits.tx$site_code %in% Data.tx$site_code)]
Data.tx$site_code[!(Data.tx$site_code %in% Traits.tx$site_code)]
#Sites in Traits.tx are all in Data.tx and vice versa. 
Traits.tx$site_code[!(Traits.tx$site_code %in% Data.t0$site_code)]
Data.tx$site_code[!(Data.tx$site_code %in% Data.t0$site_code)]
#27 sites in Data.tx and Traits.tx are not present in Data.T0
#Remove those sites
Data.tx = Data.tx[Data.tx$site_code %in% Data.t0$site_code,]
Data.tx = droplevels(Data.tx)
Traits.tx = Traits.tx[Traits.tx$site_code %in% Data.t0$site_code,]
Traits.tx = droplevels(Traits.tx)

#Verify for duplicates in the data
dup = which(Traits.tx$site_code=="shps.us" & Traits.tx$plot==22 & Traits.tx$Taxon=="POA SECUNDA") #duplicate!
Traits.tx = Traits.tx[-dup[1],]
dup2 = which(Data.t0$site_code=="sgs.us" & Data.t0$plot==16 & Data.t0$Taxon=="GROUND") #duplicate!
dup3 = which(Data.t0$site_code=="sgs.us" & Data.t0$plot==29 & Data.t0$Taxon=="GROUND") #duplicate!
Data.t0 = Data.t0[-c(dup2[1],dup3[1]),]

##################
#Convert data from Long to Wide format
##################
library(dplyr)
library(tidyr)

###############
#For T0 

#Add every Taxon to each plot and create megaCol 
t0.all.taxon = Data.t0 %>%
  mutate(megaCol=paste(site_code,block,plot,sep="/")) %>% 
  select(megaCol,Taxon) %>% 
  expand(megaCol,Taxon)

# Create megaCol 
t0.megacol = Data.t0 %>%
  mutate(megaCol=paste(site_code,block,plot,sep="/")) %>% 
  select(megaCol,Taxon,max_cover)

# join t0.all.taxon into t0.megacol so that each plot as all Taxon and absent Taxon are given max_cover = NA
t0 =  full_join(t0.all.taxon,t0.megacol)
nrow(t0.all.taxon)
nrow(t0)
#Turn NAs into 0
t0$max_cover[is.na(t0$max_cover)] = 0

#Transform to wide format
com.T0 = spread(t0,key=Taxon,value=max_cover)
com.T0 = as.data.frame(com.T0)

# Umerge MegaCol
com.T0 <- com.T0 %>%
  mutate(site_code=strsplit(megaCol,split="/") %>% sapply(function(x) x[1])) %>%
  mutate(block=strsplit(megaCol,split="/") %>% sapply(function(x) x[2])) %>%
  mutate(plot=strsplit(megaCol,split="/") %>% sapply(function(x) x[3])) 
   
  
com.T0$block = as.numeric(com.T0$block)
com.T0$plot = as.numeric(com.T0$plot)

com.T0 = com.T0[order(com.T0$site_code,com.T0$block,com.T0$plot),]

DataT0 = data.frame(com.T0[,c(798:800)],com.T0[,-c(798:800)])

T0.summary = Data.t0 %>%
  group_by(site_code,block,plot) %>%
  summarize(year=mean(year),trt=trt[1]) %>%
  ungroup() #sometime ungroup is not needed


DataT0 = data.frame(T0.summary,DataT0[,-c(1:3)])


###############
#For Tx 

#Add every Taxon to each plot and create megaCol 
tx.all.taxon = Data.tx %>%
  mutate(megaCol=paste(site_code,block,plot,sep="/")) %>% 
  select(megaCol,Taxon) %>% 
  expand(megaCol,Taxon)

# Create megaCol 
tx.megacol = Data.tx %>%
  mutate(megaCol=paste(site_code,block,plot,sep="/")) %>% 
  select(megaCol,Taxon,max_cover)

# join t0.all.taxon into t0.megacol so that each plot as all Taxon and absent Taxon are given max_cover = NA
tx.j =  full_join(tx.all.taxon,tx.megacol)
nrow(tx.all.taxon)
nrow(tx.j)
#Turn NAs into 0
tx.j$max_cover[is.na(tx.j$max_cover)] = 0

#Transform to wide format
com.Tx = spread(tx.j,key=Taxon,value=max_cover)
com.Tx = as.data.frame(com.Tx)

# Umerge MegaCol
com.Tx <- com.Tx %>%
  mutate(site_code=strsplit(megaCol,split="/") %>% sapply(function(x) x[1])) %>%
  mutate(block=strsplit(megaCol,split="/") %>% sapply(function(x) x[2])) %>%
  mutate(plot=strsplit(megaCol,split="/") %>% sapply(function(x) x[3]))
  

com.Tx$block = as.numeric(com.Tx$block)
com.Tx$plot = as.numeric(com.Tx$plot)

com.Tx = com.Tx[order(com.Tx$site_code,com.Tx$block,com.Tx$plot),]

DataTx = data.frame(com.Tx[,c(772:774)],com.Tx[,-c(772:774)])

Tx.summary = Data.tx %>%
  group_by(site_code,block,plot) %>%
  summarize(year=mean(year),trt=trt[1]) %>%
  ungroup() #sometime ungroup is not needed


DataTx = data.frame(Tx.summary,DataTx[,-c(1:3)])


###############
#For Traits.tx

#Add every Taxon to each plot and create megaCol 
trait.all.taxon = Traits.tx %>%
  mutate(megaCol=paste(site_code,block,plot,sep="/")) %>% 
  select(megaCol,Taxon) %>% 
  expand(megaCol,Taxon)

# Create megaCol 
trait.megacol = Traits.tx %>%
  mutate(megaCol=paste(site_code,block,plot,sep="/")) %>% 
  select(megaCol,Taxon,max_cover)

# join a into D.wide so that each plot as all Taxon and absent Taxon are given max_cover = NA
trait.j =  full_join(trait.all.taxon,trait.megacol)
nrow(trait.j)
nrow(trait.all.taxon)
#Turn NAs into 0
trait.j$max_cover[is.na(trait.j$max_cover)] = 0

#Transform to wide format
com.trait = spread(trait.j,key=Taxon,value=max_cover)
com.trait = as.data.frame(com.trait)

com.trait <- com.trait %>%
  mutate(site_code=strsplit(megaCol,split="/") %>% sapply(function(x) x[1])) %>%
  mutate(block=strsplit(megaCol,split="/") %>% sapply(function(x) x[2])) %>%
  mutate(plot=strsplit(megaCol,split="/") %>% sapply(function(x) x[3]))

com.trait$block = as.numeric(com.trait$block)
com.trait$plot = as.numeric(com.trait$plot)

com.trait = com.trait[order(com.trait$site_code,com.trait$block,com.trait$plot),]

# Summarize all predictors by site and by plots (to match community matrix)
trait.summary = Traits.tx %>%
group_by(site_code,block,plot) %>%
  summarize(year_trt = mean(year_trt),site_richness=mean(site_richness),SLA = mean(SLA),SLA_v2 = mean(SLA_v2),leaf_pct_N=mean(leaf_pct_N),leaf_pct_C=mean(leaf_pct_C),leaf_pct_P=mean(leaf_pct_P),
            leaf_pct_K=mean(leaf_pct_K),N = mean(N), P=mean(P), K=mean(K), Exclosure=mean(Exclose),MAT=mean(MAT),MAP=mean(MAP),MAP_VAR=mean(MAP_VAR),TEMP_VAR=mean(TEMP_VAR),soil_C=mean(pct_C),soil_N=mean(pct_N),soil_P=mean(ppm_P),soil_K=mean(ppm_K),trt=trt.y[1],year=mean(year)) %>%
  ungroup() #sometime ungroup is not needed

TraitTx = data.frame(trait.summary,com.trait[,-c(244:246)])



#### Compare three datasets for number of rows

DataT0$megaCol[which(!DataT0$megaCol %in% DataTx$megaCol)] # 14 plots are present at T0 but not at Tx
DataTx$megaCol[which(!DataTx$megaCol %in% DataT0$megaCol)] # 10 plots are present at Tx but not at T0
DataT0$megaCol[which(!DataT0$megaCol %in% TraitTx$megaCol)] #74 plots are present in T0 but not in Trait data 
DataTx$megaCol[which(!DataTx$megaCol %in% TraitTx$megaCol)] #60 sites are present at Tx but not in trait data

#Many plots are present in T0 but not T1 and vice versa - filter those out! 
sel.TraitTx = TraitTx$megaCol
sel.Data0 = DataT0$megaCol

DataT0 = DataT0[which(DataT0$megaCol %in% sel.TraitTx),]
TraitTx = TraitTx[which(TraitTx$megaCol %in% sel.Data0),]
DataTx = DataTx[which(DataTx$megaCol %in% TraitTx$megaCol),]

#save into .RData 
save(DataT0,DataTx,TraitTx,file=paste0(to.output,"Wide.RData"))




