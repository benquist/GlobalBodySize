#..........................................#
#...........Nutrient Network Project.......#
#...............Leaf Treat Study...........#
#....................SEM_v2...................#
#..........................................#

#................................................................................#
#... Authors script: Eric                                                        #
#... Date of creation: January 2020                                             #
#... Contact: eric.harvey@umontreal.ca                                               #                                                                      
#................................................................................#


## SEE THE README FILE FOR MORE DETAILS AND JUSTIFICATIONS ON THE RE-RUN OF THE ANALYSIS

#########################################################################
################# DATA STRUCTURE
#########################################################################

##################
#Clear any variables from the R environment 
##################
rm(list=ls())

##################
#Directory paths 
##################
to.data <- "./data/"
to.script <- "./scripts/"
to.output <- "./output/"
to.figs <- "./figs/"
to.R <- "./R/"


##################
#Load library 
##################
library(vegan)
library(plyr)

##################
#Load data 
##################
load(paste0(to.output,"Wide.Rdata"))
DataT0 = droplevels(DataT0)
DataTx = droplevels(DataTx)
TraitTx = droplevels(TraitTx)

#Extract all species names for later use
sp0 = c(colnames(DataT0[,-c(1:6)]),colnames(DataTx[,-c(1:6)]),colnames(TraitTx[,-c(1:26)]))
sp = unique(sp0) 
dom.sp = colnames(TraitTx[,-c(1:26)])

#Remove rows with NAs to avoid further problems
# DataT0 = na.omit(DataT0)
# DataT1 = na.omit(DataT1)
# which(is.na(DataT1[,c(4,5,6,7,8)]))

#Verify if some empty rows or NAs in community matrix
which(rowSums(TraitTx[,colnames(TraitTx) %in% sp])==0)
which(rowSums(DataT0[,colnames(DataT0) %in% sp])==0)
which(rowSums(DataTx[,colnames(DataTx) %in% sp])==0)
which(is.na((TraitTx[,colnames(TraitTx) %in% sp])))
which(is.na((DataT0[,colnames(DataT0) %in% sp])))
which(is.na((DataTx[,colnames(DataTx) %in% sp])))

#Remove two empty rows in DataT1 
to.rm = TraitTx$megaCol[which(rowSums(TraitTx[,colnames(TraitTx) %in% sp])==0)]
DataTx = DataTx[-which(DataTx$megaCol %in% to.rm),]
TraitTx = TraitTx[-which(TraitTx$megaCol %in% to.rm),]
DataT0 = DataT0[-which(DataT0$megaCol %in% to.rm),]

##################
#Extract species turnover metrics
##################


#Prepare data (Create community matrices nrow by nspecies)
  #Create a column in each data to identify that it's either T0 or T1
  DataT0$Time = rep("T0",nrow(DataT0))
  DataTx$Time = rep("Tx",nrow(DataTx))
  
  #Merge both data frame so that all species are present in both T0 and T1 data
  merge.dat =  rbind.fill(DataT0, DataTx)
  
  #re-separate them (now will have the same number of columns)
  T0.dat = subset(merge.dat,Time=="T0")
  Tx.dat = subset(merge.dat,Time=="Tx")
  
  #Extract community matrices (nsites by nspecies)
  mat.T0 = T0.dat[,colnames(T0.dat) %in% sp]
  mat.T0[is.na(mat.T0)] = 0
  mat.Tx = Tx.dat[,colnames(Tx.dat) %in% sp]
  mat.Tx[is.na(mat.Tx)] = 0
  Mat.traitx = TraitTx[,-c(1:25)]
  Mat.Tx = DataTx[,colnames(DataTx) %in% sp]  
  

#colnames(mat.T0) %in% dom.sp instead use colnames(mat.T0) %in% colnames(TraitTx[i,-c(1:24)])
#Temporal turnover
Temp.turn = 0
for(i in 1:nrow(mat.Tx)){ 
    d = rbind(mat.T0[i,which(colnames(mat.T0) %in% colnames(Mat.traitx[i,]))],mat.Tx[i,which(colnames(mat.Tx) %in% colnames(Mat.traitx[i,]))])
    d = d[,colSums(d)>0]
    Temp.turn[i] =  vegdist(decostand(d,"hell"),"bray")}
summary(Temp.turn)

#Among-plots turnover per site 
# Space.turn1 = vector('numeric')
# Space.turn2 = vector('numeric')
# for(i in 1:nlevels(DataTx$site_code)) {
#   site = levels(DataTx$site_code)[i]
#   x = Mat.Tx[DataTx$site_code==site,which(colnames(Mat.Tx) %in% dom.sp)]
#   x = x[,colSums(x)>0]
#   Bray = vegdist(decostand(x,"hell"),"bray")
#   mds = metaMDS(Bray,autotransform=F)
#   mds1 = scores(mds)[,1]
#   mds2 = scores(mds)[,2]
#   Space.turn1 =  c(Space.turn1,mds1)
#   Space.turn2 =  c(Space.turn2,mds2)
#   }

#can save into .RData 
save(Temp.turn,file=paste0(to.output,"Species_turnover.RData"))
}


#########################################################################
################# STRUCTURAL EQUATION MODELING 
#########################################################################
library(lavaan)
library(lavaan.survey)
library(AICcmodavg)
library(semPlot)
load(paste0(to.output,"Species_turnover.RData"))



#Extract predictors of interest (SLA_v2 is the corrected one)
colnames(TraitTx[,!colnames(TraitTx) %in% sp])
pred = c("site_code","block","year_trt","site_richness","SLA","SLA_v2","leaf_pct_N","leaf_pct_C","leaf_pct_P","leaf_pct_K","N",
         "P","K","MAT","MAP","MAP_VAR","TEMP_VAR","soil_C","soil_N","soil_P","soil_K","Exclosure","trt")

#Data frame for SEM
x = data.frame(TraitTx[,pred],Space.turn1,Space.turn2,Temp.turn)

#set experimental design (block nested within site)
design <- svydesign(ids=~1, strata=~site_code/block, data=x)
#design <- svydesign(ids=~1, strata=~site_code/block, prob=~1, data=x)
#design <- svydesign(ids=~site_code+block, prob=~1, data=x)


#x = na.omit(x)
x$SLA_v2 = x$SLA_v2/10000
x$SLA = x$SLA/10000

# 
Verify co-linearity among predictors and frequency distribution of each predictor
library(psych)
pdf(paste0(to.figs,'Cor_matrix.pdf'),width=15,height = 10)
pairs.panels(x,smooth=F,density=T,ellipses=F,lm=T,digits=3,scale=T, cor = T, rug=T)
dev.off()
detach("package:psych", unload=TRUE)

##################
#Simplified model version (no abiotic variables)
##################

####
# This version of the script present only initial models and final meta-model necessary for the author correction
# For a full version of all 23 models see initial script submitted with the original publication
###

#Model 1 (Initial meta-model)
mod1 <- '   
Temp.turn ~  N + P + K 
leaf_pct_N ~ N +  Temp.turn
leaf_pct_P ~ P + Temp.turn
leaf_pct_K ~ K + Temp.turn
leaf_pct_C ~ Temp.turn
SLA_v2 ~ N + P + K + Temp.turn
'
mod1.fit = sem(mod1,data=x,fixed.x=T) #run the SEM
survey.fit1 <- lavaan.survey(mod1.fit,design)
survey.fit1
summary(survey.fit1, stand=T, rsq=T) #visualize path coefficients
mod1.fit #visualize fitting resultss
modindices(survey.fit1, sort.=T) #modification indices

#Model 3 prune all unsignificants

mod3 <- '   
Temp.turn ~  P 
leaf_pct_N ~ N + Temp.turn
leaf_pct_P ~ P 
leaf_pct_K ~ K + N
leaf_pct_C ~ Temp.turn
SLA_v2 ~ Temp.turn
'

mod3.fit = sem(mod3,data=x,fixed.x=T) #run the SEM
survey.fit3 <- lavaan.survey(mod3.fit,design)
survey.fit3 
summary(survey.fit3, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit3, sort.=T) #modification indices


####
# Results here are qualitatively the same as the initial publication
# One difference is that SLVA_V2 is significantly associated with Temp.turn
###

#####
#Extract parameter estimates for meta-model (sur Supp. Mat.)
semPaths(survey.fit3,what="stand",layout="tree",edge.label.cex = 1,intercepts=F,residuals=F,exoCov=F)
semCors(survey.fit3)
write.csv(parameterEstimates(survey.fit3,standardized=T),paste0(to.output,'Meta_model.csv'))



##################
#Complex model version (with abiotic variables)
##################

## mod4 is the first metamodel presented in the supplementary material

mod4 <- '   
Temp.turn ~  P + MAT + MAP + TEMP_VAR + MAP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N
leaf_pct_P ~ P + soil_P 
leaf_pct_K ~ K + N + soil_K 
SLA_v2 ~ Temp.turn + soil_N + soil_P + soil_K + MAT + MAP + TEMP_VAR + MAP_VAR 
'

mod4.fit = sem(mod4,data=x,fixed.x=T) #run the SEM
mod4.fit
survey.fit4 <- lavaan.survey(mod4.fit,design)
survey.fit4 
summary(survey.fit4, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit4, sort.=T) #modification indices


#no modification indices higher than 2 - prune all not significant paths at p<0.05
mod23 <- '   
Temp.turn ~  MAT + TEMP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P + MAP
leaf_pct_P ~ P + MAP + MAT + TEMP_VAR + soil_K + MAP_VAR
leaf_pct_K ~ K + soil_K + MAP + soil_P + MAT + Temp.turn + TEMP_VAR
SLA_v2 ~  Temp.turn + soil_P + soil_K + MAT + MAP
'

mod23.fit = sem(mod23,data=x,fixed.x=T) #run the SEM
survey.fit23 <- lavaan.survey(mod23.fit,design)
survey.fit23
summary(survey.fit23, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit23, sort.=T) #modification indices
resid(survey.fit23)

###
# The new model 23 with the new data does not fit so well to the data
# MOD indices seem to propose that this is because there is a strong association of SLZ_v2 with MAP_VAR
###

mod23.5 <- '   
Temp.turn ~  MAT + TEMP_VAR 
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P + MAP
leaf_pct_P ~ P + MAP + MAT + TEMP_VAR + soil_K + MAP_VAR
leaf_pct_K ~ K + soil_K + MAP + soil_P + MAT + Temp.turn 
SLA_v2 ~  Temp.turn + soil_P + MAP + MAP_VAR
'

mod23.5.fit = sem(mod23.5,data=x,fixed.x=T) #run the SEM
survey.fit23.5 <- lavaan.survey(mod23.5.fit,design)
survey.fit23.5
summary(survey.fit23.5, stand=T, rsq=T) #visualize path coefficients
modindices(survey.fit23.5, sort.=T) #modification indices
resid(survey.fit23.5)

###
# Now the fit is very good! 
#
###


################################
#Aposteriori addition of variable (year_trt)  - as in the original publication we proceed to the addition of year_trt a posteriori as this 
# was suggested by the reviewers during revision process.

mod24 <- '   
Temp.turn ~  MAT + TEMP_VAR + year_trt
leaf_pct_N ~ N + Temp.turn + soil_N + MAT + MAP_VAR + soil_K + soil_P + MAP + year_trt
leaf_pct_P ~ P + MAP + MAT + TEMP_VAR + soil_K + MAP_VAR 
leaf_pct_K ~ K + soil_K + MAP + soil_P + MAT + Temp.turn 
SLA_v2 ~  Temp.turn + soil_P + MAP + MAP_VAR + year_trt
'

mod24.fit = sem(mod24,data=x,fixed.x=T) #run the SEM
survey.fit24 <- lavaan.survey(mod24.fit,design)
survey.fit24
summary(survey.fit24, stand=T, rsq=T) #visualize path coefficients
smodindices(survey.fit24, sort.=T) #modification indices
resid(survey.fit24)


#####
#Extract parameter estimates 
semPaths(survey.fit24,what="stand",layout="tree",edge.label.cex = 1,intercepts=F,residuals=F,exoCov=F)
semCors(survey.fit4)
write.csv(parameterEstimates(survey.fit24,standardized=T),paste0(to.output,'SEM.csv'))



##################
#END
##################



