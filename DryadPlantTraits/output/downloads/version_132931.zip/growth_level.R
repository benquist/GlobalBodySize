### Code written by Stef Weijers (stef.weijers@uni-bonn.de) 

plant_growth<-read.csv('Plant growth data.csv')


library(dplyr)
plant_growth %>% group_by(subsite) %>% summarise(statistic = shapiro.test(shoot_length)$statistic, 
                                                    p.value = shapiro.test(shoot_length)$p.value)


TukeyHSD(aov(shoot_length~subsite, data=plant_growth))

colnames(plant_growth)<-c("site","site.1","Site","shrub_num","year","shoot_length","pi","pi_full","latitude","longitude","elevation","speciescode","species")

library(ggplot2)
ggplot(plant_growth, aes(x=Site, y=shoot_length, fill=Site)) + 
  scale_y_continuous(expression("Shoot length (mm)"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Greens', direction = -1)+
  annotate("text", x=1, y=200, label= "a") + 
  annotate("text", x =2, y=200, label = "a")+
  annotate("text", x =3, y=200, label = "b")+
  annotate("text", x =4, y=200, label = "c")


plant_growth %>% group_by(Site) %>% summarise(mean = mean(shoot_length), 
                                                 sd = sd(shoot_length))
