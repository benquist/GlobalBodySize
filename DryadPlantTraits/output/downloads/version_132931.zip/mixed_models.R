### Code written by Stef Weijers (stef.weijers@uni-bonn.de) 

# Libraries
library(dplyr)
library(plyr)
library(tidyr)
library(nlme)
library(MuMIn)
library(broom)
library(AICcmodavg)
library(tibble)
library(RCurl) 

### load data
plant_growth<-read.csv('Plant growth data.csv')
head(plant_growth)

### merge plant growth data with climate data (see 'climate_data.R' for clim_Norderney)
data<-merge(plant_growth, clim_Norderney, by.x = 'year', by.y = 'year')

# Generic function
unfactorize <- function(df){
  for(i in which(sapply(df, class) == "factor")) df[[i]] = as.character(df[[i]])
  return(df)
}
data$xyear <- paste0("x", unfactorize(data$year))

# Standardization of shoot length
data<- data %>% group_by(shrub_num) %>% mutate_at(c('shoot_length'), funs(nshoot_length = scale(shoot_length)))

### clean and subset data
data[data=="NaN"] <- NA
data<-na.omit(data)

dataABC<-subset(data, subsite=='A' | subsite=='B' | subsite=='C')

# Mixed model analyses ----
mixed_model <- function(data, nshoot_length) { 
  
  m1n <- lme(nshoot_length ~ nprev_summer_P, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m2n <- lme(nshoot_length ~ nprev_autumn_P, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))  
  m3n <- lme(nshoot_length ~ nwinter_P, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))  
  m4n <- lme(nshoot_length ~ nspring_P, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))  
  m5n <- lme(nshoot_length ~ nsummer_P, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m5an <- lme(nshoot_length ~ nautumn_P, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  
  m6n <- lme(nshoot_length ~ nprev_summer_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m7n <- lme(nshoot_length ~ nprev_autumn_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m8n <- lme(nshoot_length ~ nwinter_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m9n <- lme(nshoot_length ~ nspring_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m10n <- lme(nshoot_length ~ nsummer_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m10an <- lme(nshoot_length ~ nautumn_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  m11n <- lme(nshoot_length ~ nprev_summer_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m12n <- lme(nshoot_length ~ nprev_autumn_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m13n <- lme(nshoot_length ~ nwinter_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m14n <- lme(nshoot_length ~ nspring_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m15n <- lme(nshoot_length ~ nsummer_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m15an <- lme(nshoot_length ~ nautumn_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  m16n <- lme(nshoot_length ~ nprev_summer_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m17n <- lme(nshoot_length ~ nprev_autumn_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m18n <- lme(nshoot_length ~ nwinter_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m19n <- lme(nshoot_length ~ nspring_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m20n <- lme(nshoot_length ~ nsummer_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m20an <- lme(nshoot_length ~ nautumn_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  m21n <- lme(nshoot_length ~ nprev_summer_sun, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m22n <- lme(nshoot_length ~ nprev_autumn_sun, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m23n <- lme(nshoot_length ~ nwinter_sun, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m24n <- lme(nshoot_length ~ nspring_sun, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m25n <- lme(nshoot_length ~ nsummer_sun, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m25an <- lme(nshoot_length ~ nautumn_sun, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  mNULLn <- lme(nshoot_length ~ 1, random=~1|xyear, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  modelsum <- function(x) { 
    if(length(x$varFix) == 4) {
      modelsum <- cbind.data.frame(summary(x)$tTable[1,1],summary(x)$tTable[1,2],summary(x)$tTable[2,1],summary(x)$tTable[2,2])
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    } else {
      modelsum <- cbind.data.frame("NA", "NA", "NA", "NA")
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    }
  }
  
  models <- rbind(
    as.data.frame(c(model = "prev_summer_P", glance(m1n), modelsum(m1n), as.data.frame(r.squaredGLMM(m1n)))), 
    as.data.frame(c(model = "prev_autumn_P", glance(m2n), modelsum(m2n), as.data.frame(r.squaredGLMM(m2n)))), 
    as.data.frame(c(model = "winter_P", glance(m3n), modelsum(m3n), as.data.frame(r.squaredGLMM(m3n)))), 
    as.data.frame(c(model = "spring_P", glance(m4n), modelsum(m4n), as.data.frame(r.squaredGLMM(m4n)))),
    as.data.frame(c(model = "summer_P", glance(m5n), modelsum(m5n), as.data.frame(r.squaredGLMM(m5n)))),
    as.data.frame(c(model = "autumn_P", glance(m5an), modelsum(m5an), as.data.frame(r.squaredGLMM(m5an)))),
    
    as.data.frame(c(model = "prev_summer_T", glance(m6n), modelsum(m6n), as.data.frame(r.squaredGLMM(m6n)))),
    as.data.frame(c(model = "prev_autumn_T", glance(m7n), modelsum(m7n), as.data.frame(r.squaredGLMM(m7n)))),
    as.data.frame(c(model = "winter_T", glance(m8n), modelsum(m8n), as.data.frame(r.squaredGLMM(m8n)))),
    as.data.frame(c(model = "spring_T", glance(m9n), modelsum(m9n), as.data.frame(r.squaredGLMM(m9n)))),
    as.data.frame(c(model = "summer_T", glance(m10n), modelsum(m10n), as.data.frame(r.squaredGLMM(m10n)))),
    as.data.frame(c(model = "autumn_T", glance(m10an), modelsum(m10an), as.data.frame(r.squaredGLMM(m10an)))),

    as.data.frame(c(model = "prev_summer_surfT", glance(m11n), modelsum(m11n), as.data.frame(r.squaredGLMM(m11n)))),
    as.data.frame(c(model = "prev_autumn_surfT", glance(m12n), modelsum(m12n), as.data.frame(r.squaredGLMM(m12n)))),
    as.data.frame(c(model = "winter_surfT", glance(m13n), modelsum(m13n), as.data.frame(r.squaredGLMM(m13n)))),
    as.data.frame(c(model = "spring_surfT", glance(m14n), modelsum(m14n), as.data.frame(r.squaredGLMM(m14n)))),
    as.data.frame(c(model = "summer_surfT", glance(m15n), modelsum(m15n), as.data.frame(r.squaredGLMM(m15n)))),
    as.data.frame(c(model = "autumn_surfT", glance(m15an), modelsum(m15an), as.data.frame(r.squaredGLMM(m15an)))),
    
    as.data.frame(c(model = "prev_summer_scPDSI", glance(m16n), modelsum(m16n), as.data.frame(r.squaredGLMM(m16n)))),
    as.data.frame(c(model = "prev_autumn_scPDSI", glance(m17n), modelsum(m17n), as.data.frame(r.squaredGLMM(m17n)))),
    as.data.frame(c(model = "winter_scPDSI", glance(m18n), modelsum(m18n), as.data.frame(r.squaredGLMM(m18n)))),
    as.data.frame(c(model = "spring_scPDSI", glance(m19n), modelsum(m19n), as.data.frame(r.squaredGLMM(m19n)))),
    as.data.frame(c(model = "summer_scPDSI", glance(m20n), modelsum(m20n), as.data.frame(r.squaredGLMM(m20n)))),
    as.data.frame(c(model = "autumn_scPDSI", glance(m20an), modelsum(m20an), as.data.frame(r.squaredGLMM(m20an)))),
    
    as.data.frame(c(model = "prev_summer_sun", glance(m21n), modelsum(m21n), as.data.frame(r.squaredGLMM(m21n)))),
    as.data.frame(c(model = "prev_autumn_sun", glance(m22n), modelsum(m22n), as.data.frame(r.squaredGLMM(m22n)))),
    as.data.frame(c(model = "winter_sun", glance(m23n), modelsum(m23n), as.data.frame(r.squaredGLMM(m23n)))),
    as.data.frame(c(model = "spring_sun", glance(m24n), modelsum(m24n), as.data.frame(r.squaredGLMM(m24n)))),
    as.data.frame(c(model = "summer_sun", glance(m25n), modelsum(m25n), as.data.frame(r.squaredGLMM(m25n)))),
    as.data.frame(c(model = "autumn_sun", glance(m25an), modelsum(m25an), as.data.frame(r.squaredGLMM(m25an)))),
    
    as.data.frame(c(model = "null", glance(mNULLn), modelsum(mNULLn), as.data.frame(r.squaredGLMM(mNULLn)))))
  
  ranking <- arrange(models, AIC)
  ranking
}

mixed_modelREML <- function(data, nshoot_length) { 
  
  m1n <- lme(nshoot_length ~ nprev_summer_P, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m2n <- lme(nshoot_length ~ nprev_autumn_P, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))  
  m3n <- lme(nshoot_length ~ nwinter_P, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))  
  m4n <- lme(nshoot_length ~ nspring_P, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))  
  m5n <- lme(nshoot_length ~ nsummer_P, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m5an <- lme(nshoot_length ~ nautumn_P, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  
  m6n <- lme(nshoot_length ~ nprev_summer_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m7n <- lme(nshoot_length ~ nprev_autumn_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m8n <- lme(nshoot_length ~ nwinter_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m9n <- lme(nshoot_length ~ nspring_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m10n <- lme(nshoot_length ~ nsummer_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m10an <- lme(nshoot_length ~ nautumn_meanT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  m11n <- lme(nshoot_length ~ nprev_summer_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m12n <- lme(nshoot_length ~ nprev_autumn_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m13n <- lme(nshoot_length ~ nwinter_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m14n <- lme(nshoot_length ~ nspring_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m15n <- lme(nshoot_length ~ nsummer_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m15an <- lme(nshoot_length ~ nautumn_minSurfT, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  m16n <- lme(nshoot_length ~ nprev_summer_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m17n <- lme(nshoot_length ~ nprev_autumn_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m18n <- lme(nshoot_length ~ nwinter_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m19n <- lme(nshoot_length ~ nspring_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m20n <- lme(nshoot_length ~ nsummer_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m20an <- lme(nshoot_length ~ nautumn_scPDSI, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  m21n <- lme(nshoot_length ~ nprev_summer_sun, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m22n <- lme(nshoot_length ~ nprev_autumn_sun, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m23n <- lme(nshoot_length ~ nwinter_sun, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m24n <- lme(nshoot_length ~ nspring_sun, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m25n <- lme(nshoot_length ~ nsummer_sun, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m25an <- lme(nshoot_length ~ nautumn_sun, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  mNULLn <- lme(nshoot_length ~ 1, random=~1|xyear, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  modelsum <- function(x) { 
    if(length(x$varFix) == 4) {
      modelsum <- cbind.data.frame(summary(x)$tTable[1,1],summary(x)$tTable[1,2],summary(x)$tTable[2,1],summary(x)$tTable[2,2])
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    } else {
      modelsum <- cbind.data.frame("NA", "NA", "NA", "NA")
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    }
  }
  
  models <- rbind(
    as.data.frame(c(model = "prev_summer_P", glance(m1n), modelsum(m1n), as.data.frame(r.squaredGLMM(m1n)))), 
    as.data.frame(c(model = "prev_autumn_P", glance(m2n), modelsum(m2n), as.data.frame(r.squaredGLMM(m2n)))), 
    as.data.frame(c(model = "winter_P", glance(m3n), modelsum(m3n), as.data.frame(r.squaredGLMM(m3n)))), 
    as.data.frame(c(model = "spring_P", glance(m4n), modelsum(m4n), as.data.frame(r.squaredGLMM(m4n)))),
    as.data.frame(c(model = "summer_P", glance(m5n), modelsum(m5n), as.data.frame(r.squaredGLMM(m5n)))),
    as.data.frame(c(model = "autumn_P", glance(m5an), modelsum(m5an), as.data.frame(r.squaredGLMM(m5an)))),
    
    as.data.frame(c(model = "prev_summer_T", glance(m6n), modelsum(m6n), as.data.frame(r.squaredGLMM(m6n)))),
    as.data.frame(c(model = "prev_autumn_T", glance(m7n), modelsum(m7n), as.data.frame(r.squaredGLMM(m7n)))),
    as.data.frame(c(model = "winter_T", glance(m8n), modelsum(m8n), as.data.frame(r.squaredGLMM(m8n)))),
    as.data.frame(c(model = "spring_T", glance(m9n), modelsum(m9n), as.data.frame(r.squaredGLMM(m9n)))),
    as.data.frame(c(model = "summer_T", glance(m10n), modelsum(m10n), as.data.frame(r.squaredGLMM(m10n)))),
    as.data.frame(c(model = "autumn_T", glance(m10an), modelsum(m10an), as.data.frame(r.squaredGLMM(m10an)))),
    
    as.data.frame(c(model = "prev_summer_surfT", glance(m11n), modelsum(m11n), as.data.frame(r.squaredGLMM(m11n)))),
    as.data.frame(c(model = "prev_autumn_surfT", glance(m12n), modelsum(m12n), as.data.frame(r.squaredGLMM(m12n)))),
    as.data.frame(c(model = "winter_surfT", glance(m13n), modelsum(m13n), as.data.frame(r.squaredGLMM(m13n)))),
    as.data.frame(c(model = "spring_surfT", glance(m14n), modelsum(m14n), as.data.frame(r.squaredGLMM(m14n)))),
    as.data.frame(c(model = "summer_surfT", glance(m15n), modelsum(m15n), as.data.frame(r.squaredGLMM(m15n)))),
    as.data.frame(c(model = "autumn_surfT", glance(m15an), modelsum(m15an), as.data.frame(r.squaredGLMM(m15an)))),
    
    as.data.frame(c(model = "prev_summer_scPDSI", glance(m16n), modelsum(m16n), as.data.frame(r.squaredGLMM(m16n)))),
    as.data.frame(c(model = "prev_autumn_scPDSI", glance(m17n), modelsum(m17n), as.data.frame(r.squaredGLMM(m17n)))),
    as.data.frame(c(model = "winter_scPDSI", glance(m18n), modelsum(m18n), as.data.frame(r.squaredGLMM(m18n)))),
    as.data.frame(c(model = "spring_scPDSI", glance(m19n), modelsum(m19n), as.data.frame(r.squaredGLMM(m19n)))),
    as.data.frame(c(model = "summer_scPDSI", glance(m20n), modelsum(m20n), as.data.frame(r.squaredGLMM(m20n)))),
    as.data.frame(c(model = "autumn_scPDSI", glance(m20an), modelsum(m20an), as.data.frame(r.squaredGLMM(m20an)))),
    
    as.data.frame(c(model = "prev_summer_sun", glance(m21n), modelsum(m21n), as.data.frame(r.squaredGLMM(m21n)))),
    as.data.frame(c(model = "prev_autumn_sun", glance(m22n), modelsum(m22n), as.data.frame(r.squaredGLMM(m22n)))),
    as.data.frame(c(model = "winter_sun", glance(m23n), modelsum(m23n), as.data.frame(r.squaredGLMM(m23n)))),
    as.data.frame(c(model = "spring_sun", glance(m24n), modelsum(m24n), as.data.frame(r.squaredGLMM(m24n)))),
    as.data.frame(c(model = "summer_sun", glance(m25n), modelsum(m25n), as.data.frame(r.squaredGLMM(m25n)))),
    as.data.frame(c(model = "autumn_sun", glance(m25an), modelsum(m25an), as.data.frame(r.squaredGLMM(m25an)))),
    
    as.data.frame(c(model = "null", glance(mNULLn), modelsum(mNULLn), as.data.frame(r.squaredGLMM(mNULLn)))))
  
  ranking <- arrange(models, AIC)
  ranking
}

### model comparison was done with the 'mixed_model' function (maximum likelihood)
### below an example of the analysis, here for each site with restricted maximum likelihood for slope estimates and pseudo-R2 calc.
### the comparison was repeated across Spiekeroog ('Site') and excluding site D, i.e. with 'dataABC'
### See Hein et al. (2021) https://doi.org/10.1007/s11258-020-01107-z 

mixedmodels <- data%>% 
  # group by subsite
  group_by(subsite) %>% 
  # run models on all shrub series
  do(fit = mixed_modelREML(., nshoot_length))


mixedmodels2 <- mixedmodels$fit %>% 
  enframe() %>% 
  unnest()

subsitesnames <- cbind.data.frame(seq(1,4), mixedmodels$subsite)
names(subsitesnames) <- c("name", "subsite")
mixedmodels <- merge(mixedmodels2, subsitesnames) %>% select(name, subsite, everything()) %>% arrange(subsite, AIC) 



# Mixed model analyses across sites with (sub)site as additional random effect (Supplement)   
mixed_model_random_subsite <- function(data, nshoot_length) { 
  
  m1n <- lme(nshoot_length ~ nprev_summer_P, random=(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m2n <- lme(nshoot_length ~ nprev_autumn_P, random=(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))  
  m3n <- lme(nshoot_length ~ nwinter_P, random=(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))  
  m4n <- lme(nshoot_length ~ nspring_P, random=(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))  
  m5n <- lme(nshoot_length ~ nsummer_P, random=(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m5an <- lme(nshoot_length ~ nautumn_P, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  
  m6n <- lme(nshoot_length ~ nprev_summer_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m7n <- lme(nshoot_length ~ nprev_autumn_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m8n <- lme(nshoot_length ~ nwinter_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m9n <- lme(nshoot_length ~ nspring_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m10n <- lme(nshoot_length ~ nsummer_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m10an <- lme(nshoot_length ~ nautumn_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  m11n <- lme(nshoot_length ~ nprev_summer_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m12n <- lme(nshoot_length ~ nprev_autumn_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m13n <- lme(nshoot_length ~ nwinter_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m14n <- lme(nshoot_length ~ nspring_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m15n <- lme(nshoot_length ~ nsummer_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m15an <- lme(nshoot_length ~ nautumn_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  m16n <- lme(nshoot_length ~ nprev_summer_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m17n <- lme(nshoot_length ~ nprev_autumn_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m18n <- lme(nshoot_length ~ nwinter_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m19n <- lme(nshoot_length ~ nspring_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m20n <- lme(nshoot_length ~ nsummer_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m20an <- lme(nshoot_length ~ nautumn_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  m21n <- lme(nshoot_length ~ nprev_summer_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m22n <- lme(nshoot_length ~ nprev_autumn_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m23n <- lme(nshoot_length ~ nwinter_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m24n <- lme(nshoot_length ~ nspring_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m25n <- lme(nshoot_length ~ nsummer_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m25an <- lme(nshoot_length ~ nautumn_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  mNULLn <- lme(nshoot_length ~ 1, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  modelsum <- function(x) { 
    if(length(x$varFix) == 4) {
      modelsum <- cbind.data.frame(summary(x)$tTable[1,1],summary(x)$tTable[1,2],summary(x)$tTable[2,1],summary(x)$tTable[2,2])
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    } else {
      modelsum <- cbind.data.frame("NA", "NA", "NA", "NA")
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    }
  }
  
  models <- rbind(
    as.data.frame(c(model = "prev_summer_P", glance(m1n), modelsum(m1n), as.data.frame(r.squaredGLMM(m1n)))), 
    as.data.frame(c(model = "prev_autumn_P", glance(m2n), modelsum(m2n), as.data.frame(r.squaredGLMM(m2n)))), 
    as.data.frame(c(model = "winter_P", glance(m3n), modelsum(m3n), as.data.frame(r.squaredGLMM(m3n)))), 
    as.data.frame(c(model = "spring_P", glance(m4n), modelsum(m4n), as.data.frame(r.squaredGLMM(m4n)))),
    as.data.frame(c(model = "summer_P", glance(m5n), modelsum(m5n), as.data.frame(r.squaredGLMM(m5n)))),
    as.data.frame(c(model = "autumn_P", glance(m5an), modelsum(m5an), as.data.frame(r.squaredGLMM(m5an)))),
    
    as.data.frame(c(model = "prev_summer_T", glance(m6n), modelsum(m6n), as.data.frame(r.squaredGLMM(m6n)))),
    as.data.frame(c(model = "prev_autumn_T", glance(m7n), modelsum(m7n), as.data.frame(r.squaredGLMM(m7n)))),
    as.data.frame(c(model = "winter_T", glance(m8n), modelsum(m8n), as.data.frame(r.squaredGLMM(m8n)))),
    as.data.frame(c(model = "spring_T", glance(m9n), modelsum(m9n), as.data.frame(r.squaredGLMM(m9n)))),
    as.data.frame(c(model = "summer_T", glance(m10n), modelsum(m10n), as.data.frame(r.squaredGLMM(m10n)))),
    as.data.frame(c(model = "autumn_T", glance(m10an), modelsum(m10an), as.data.frame(r.squaredGLMM(m10an)))),
    
    as.data.frame(c(model = "prev_summer_surfT", glance(m11n), modelsum(m11n), as.data.frame(r.squaredGLMM(m11n)))),
    as.data.frame(c(model = "prev_autumn_surfT", glance(m12n), modelsum(m12n), as.data.frame(r.squaredGLMM(m12n)))),
    as.data.frame(c(model = "winter_surfT", glance(m13n), modelsum(m13n), as.data.frame(r.squaredGLMM(m13n)))),
    as.data.frame(c(model = "spring_surfT", glance(m14n), modelsum(m14n), as.data.frame(r.squaredGLMM(m14n)))),
    as.data.frame(c(model = "summer_surfT", glance(m15n), modelsum(m15n), as.data.frame(r.squaredGLMM(m15n)))),
    as.data.frame(c(model = "autumn_surfT", glance(m15an), modelsum(m15an), as.data.frame(r.squaredGLMM(m15an)))),
    
    as.data.frame(c(model = "prev_summer_scPDSI", glance(m16n), modelsum(m16n), as.data.frame(r.squaredGLMM(m16n)))),
    as.data.frame(c(model = "prev_autumn_scPDSI", glance(m17n), modelsum(m17n), as.data.frame(r.squaredGLMM(m17n)))),
    as.data.frame(c(model = "winter_scPDSI", glance(m18n), modelsum(m18n), as.data.frame(r.squaredGLMM(m18n)))),
    as.data.frame(c(model = "spring_scPDSI", glance(m19n), modelsum(m19n), as.data.frame(r.squaredGLMM(m19n)))),
    as.data.frame(c(model = "summer_scPDSI", glance(m20n), modelsum(m20n), as.data.frame(r.squaredGLMM(m20n)))),
    as.data.frame(c(model = "autumn_scPDSI", glance(m20an), modelsum(m20an), as.data.frame(r.squaredGLMM(m20an)))),
    
    as.data.frame(c(model = "prev_summer_sun", glance(m21n), modelsum(m21n), as.data.frame(r.squaredGLMM(m21n)))),
    as.data.frame(c(model = "prev_autumn_sun", glance(m22n), modelsum(m22n), as.data.frame(r.squaredGLMM(m22n)))),
    as.data.frame(c(model = "winter_sun", glance(m23n), modelsum(m23n), as.data.frame(r.squaredGLMM(m23n)))),
    as.data.frame(c(model = "spring_sun", glance(m24n), modelsum(m24n), as.data.frame(r.squaredGLMM(m24n)))),
    as.data.frame(c(model = "summer_sun", glance(m25n), modelsum(m25n), as.data.frame(r.squaredGLMM(m25n)))),
    as.data.frame(c(model = "autumn_sun", glance(m25an), modelsum(m25an), as.data.frame(r.squaredGLMM(m25an)))),
    
    as.data.frame(c(model = "null", glance(mNULLn), modelsum(mNULLn), as.data.frame(r.squaredGLMM(mNULLn)))))
  
  ranking <- arrange(models, AIC)
  ranking
}

mixed_model_random_subsite_REML <- function(data, nshoot_length) { 
  
  m1n <- lme(nshoot_length ~ nprev_summer_P, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m2n <- lme(nshoot_length ~ nprev_autumn_P, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))  
  m3n <- lme(nshoot_length ~ nwinter_P, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))  
  m4n <- lme(nshoot_length ~ nspring_P, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))  
  m5n <- lme(nshoot_length ~ nsummer_P, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m5an <- lme(nshoot_length ~ nautumn_P, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  
  m6n <- lme(nshoot_length ~ nprev_summer_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m7n <- lme(nshoot_length ~ nprev_autumn_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m8n <- lme(nshoot_length ~ nwinter_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m9n <- lme(nshoot_length ~ nspring_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m10n <- lme(nshoot_length ~ nsummer_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m10an <- lme(nshoot_length ~ nautumn_meanT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  m11n <- lme(nshoot_length ~ nprev_summer_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m12n <- lme(nshoot_length ~ nprev_autumn_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m13n <- lme(nshoot_length ~ nwinter_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m14n <- lme(nshoot_length ~ nspring_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m15n <- lme(nshoot_length ~ nsummer_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m15an <- lme(nshoot_length ~ nautumn_minSurfT, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  m16n <- lme(nshoot_length ~ nprev_summer_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m17n <- lme(nshoot_length ~ nprev_autumn_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m18n <- lme(nshoot_length ~ nwinter_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m19n <- lme(nshoot_length ~ nspring_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m20n <- lme(nshoot_length ~ nsummer_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m20an <- lme(nshoot_length ~ nautumn_scPDSI, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  m21n <- lme(nshoot_length ~ nprev_summer_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m22n <- lme(nshoot_length ~ nprev_autumn_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m23n <- lme(nshoot_length ~ nwinter_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m24n <- lme(nshoot_length ~ nspring_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m25n <- lme(nshoot_length ~ nsummer_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m25an <- lme(nshoot_length ~ nautumn_sun, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  mNULLn <- lme(nshoot_length ~ 1, random=list(~1|year, ~1|subsite), cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  modelsum <- function(x) { 
    if(length(x$varFix) == 4) {
      modelsum <- cbind.data.frame(summary(x)$tTable[1,1],summary(x)$tTable[1,2],summary(x)$tTable[2,1],summary(x)$tTable[2,2])
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    } else {
      modelsum <- cbind.data.frame("NA", "NA", "NA", "NA")
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    }
  }
  
  models <- rbind(
    as.data.frame(c(model = "prev_summer_P", glance(m1n), modelsum(m1n), as.data.frame(r.squaredGLMM(m1n)))), 
    as.data.frame(c(model = "prev_autumn_P", glance(m2n), modelsum(m2n), as.data.frame(r.squaredGLMM(m2n)))), 
    as.data.frame(c(model = "winter_P", glance(m3n), modelsum(m3n), as.data.frame(r.squaredGLMM(m3n)))), 
    as.data.frame(c(model = "spring_P", glance(m4n), modelsum(m4n), as.data.frame(r.squaredGLMM(m4n)))),
    as.data.frame(c(model = "summer_P", glance(m5n), modelsum(m5n), as.data.frame(r.squaredGLMM(m5n)))),
    as.data.frame(c(model = "autumn_P", glance(m5an), modelsum(m5an), as.data.frame(r.squaredGLMM(m5an)))),
    
    as.data.frame(c(model = "prev_summer_T", glance(m6n), modelsum(m6n), as.data.frame(r.squaredGLMM(m6n)))),
    as.data.frame(c(model = "prev_autumn_T", glance(m7n), modelsum(m7n), as.data.frame(r.squaredGLMM(m7n)))),
    as.data.frame(c(model = "winter_T", glance(m8n), modelsum(m8n), as.data.frame(r.squaredGLMM(m8n)))),
    as.data.frame(c(model = "spring_T", glance(m9n), modelsum(m9n), as.data.frame(r.squaredGLMM(m9n)))),
    as.data.frame(c(model = "summer_T", glance(m10n), modelsum(m10n), as.data.frame(r.squaredGLMM(m10n)))),
    as.data.frame(c(model = "autumn_T", glance(m10an), modelsum(m10an), as.data.frame(r.squaredGLMM(m10an)))),
    
    as.data.frame(c(model = "prev_summer_surfT", glance(m11n), modelsum(m11n), as.data.frame(r.squaredGLMM(m11n)))),
    as.data.frame(c(model = "prev_autumn_surfT", glance(m12n), modelsum(m12n), as.data.frame(r.squaredGLMM(m12n)))),
    as.data.frame(c(model = "winter_surfT", glance(m13n), modelsum(m13n), as.data.frame(r.squaredGLMM(m13n)))),
    as.data.frame(c(model = "spring_surfT", glance(m14n), modelsum(m14n), as.data.frame(r.squaredGLMM(m14n)))),
    as.data.frame(c(model = "summer_surfT", glance(m15n), modelsum(m15n), as.data.frame(r.squaredGLMM(m15n)))),
    as.data.frame(c(model = "autumn_surfT", glance(m15an), modelsum(m15an), as.data.frame(r.squaredGLMM(m15an)))),
    
    as.data.frame(c(model = "prev_summer_scPDSI", glance(m16n), modelsum(m16n), as.data.frame(r.squaredGLMM(m16n)))),
    as.data.frame(c(model = "prev_autumn_scPDSI", glance(m17n), modelsum(m17n), as.data.frame(r.squaredGLMM(m17n)))),
    as.data.frame(c(model = "winter_scPDSI", glance(m18n), modelsum(m18n), as.data.frame(r.squaredGLMM(m18n)))),
    as.data.frame(c(model = "spring_scPDSI", glance(m19n), modelsum(m19n), as.data.frame(r.squaredGLMM(m19n)))),
    as.data.frame(c(model = "summer_scPDSI", glance(m20n), modelsum(m20n), as.data.frame(r.squaredGLMM(m20n)))),
    as.data.frame(c(model = "autumn_scPDSI", glance(m20an), modelsum(m20an), as.data.frame(r.squaredGLMM(m20an)))),
    
    as.data.frame(c(model = "prev_summer_sun", glance(m21n), modelsum(m21n), as.data.frame(r.squaredGLMM(m21n)))),
    as.data.frame(c(model = "prev_autumn_sun", glance(m22n), modelsum(m22n), as.data.frame(r.squaredGLMM(m22n)))),
    as.data.frame(c(model = "winter_sun", glance(m23n), modelsum(m23n), as.data.frame(r.squaredGLMM(m23n)))),
    as.data.frame(c(model = "spring_sun", glance(m24n), modelsum(m24n), as.data.frame(r.squaredGLMM(m24n)))),
    as.data.frame(c(model = "summer_sun", glance(m25n), modelsum(m25n), as.data.frame(r.squaredGLMM(m25n)))),
    as.data.frame(c(model = "autumn_sun", glance(m25an), modelsum(m25an), as.data.frame(r.squaredGLMM(m25an)))),
    
    as.data.frame(c(model = "null", glance(mNULLn), modelsum(mNULLn), as.data.frame(r.squaredGLMM(mNULLn)))))
  
  ranking <- arrange(models, AIC)
  ranking
}

mixedmodels3 <- data %>% 
  group_by(site) %>% 
  do(fit = mixed_model_random_subsite(., nshoot_length))

mixedmodels4 <- mixedmodels3$fit %>% 
  enframe() %>% 
  unnest()

mixedmodels5 <- data %>% 
  group_by(site) %>% 
  do(fit = mixed_model_random_subsite_REML(., nshoot_length))

mixedmodels6 <- mixedmodels5$fit %>% 
  enframe() %>% 
  unnest()

write.csv(mixedmodels4, file = 'mixedmodels_add_random_subsite_ML.csv') 
write.csv(mixedmodels6, file = 'mixedmodels_add_random_subsite_REML.csv') 

# Mixed model analyses across sites with (sub)site as random effect instead of 'year'   
mixed_model_random_subsite <- function(data, nshoot_length) { 
  
  m1n <- lme(nshoot_length ~ nprev_summer_P, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m2n <- lme(nshoot_length ~ nprev_autumn_P, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))  
  m3n <- lme(nshoot_length ~ nwinter_P, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))  
  m4n <- lme(nshoot_length ~ nspring_P, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))  
  m5n <- lme(nshoot_length ~ nsummer_P, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m5an <- lme(nshoot_length ~ nautumn_P, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  
  m6n <- lme(nshoot_length ~ nprev_summer_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m7n <- lme(nshoot_length ~ nprev_autumn_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m8n <- lme(nshoot_length ~ nwinter_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m9n <- lme(nshoot_length ~ nspring_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m10n <- lme(nshoot_length ~ nsummer_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m10an <- lme(nshoot_length ~ nautumn_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  m11n <- lme(nshoot_length ~ nprev_summer_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m12n <- lme(nshoot_length ~ nprev_autumn_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m13n <- lme(nshoot_length ~ nwinter_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m14n <- lme(nshoot_length ~ nspring_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m15n <- lme(nshoot_length ~ nsummer_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m15an <- lme(nshoot_length ~ nautumn_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  m16n <- lme(nshoot_length ~ nprev_summer_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m17n <- lme(nshoot_length ~ nprev_autumn_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m18n <- lme(nshoot_length ~ nwinter_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m19n <- lme(nshoot_length ~ nspring_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m20n <- lme(nshoot_length ~ nsummer_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m20an <- lme(nshoot_length ~ nautumn_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  m21n <- lme(nshoot_length ~ nprev_summer_sun, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m22n <- lme(nshoot_length ~ nprev_autumn_sun, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m23n <- lme(nshoot_length ~ nwinter_sun, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m24n <- lme(nshoot_length ~ nspring_sun, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000)) 
  m25n <- lme(nshoot_length ~ nsummer_sun, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  m25an <- lme(nshoot_length ~ nautumn_sun, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  mNULLn <- lme(nshoot_length ~ 1, random=~1|subsite, cor=corAR1(), data = data, method = "ML", control=list(maxIter=1000))
  
  modelsum <- function(x) { 
    if(length(x$varFix) == 4) {
      modelsum <- cbind.data.frame(summary(x)$tTable[1,1],summary(x)$tTable[1,2],summary(x)$tTable[2,1],summary(x)$tTable[2,2])
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    } else {
      modelsum <- cbind.data.frame("NA", "NA", "NA", "NA")
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    }
  }
  
  models <- rbind(
    as.data.frame(c(model = "prev_summer_P", glance(m1n), modelsum(m1n), as.data.frame(r.squaredGLMM(m1n)))), 
    as.data.frame(c(model = "prev_autumn_P", glance(m2n), modelsum(m2n), as.data.frame(r.squaredGLMM(m2n)))), 
    as.data.frame(c(model = "winter_P", glance(m3n), modelsum(m3n), as.data.frame(r.squaredGLMM(m3n)))), 
    as.data.frame(c(model = "spring_P", glance(m4n), modelsum(m4n), as.data.frame(r.squaredGLMM(m4n)))),
    as.data.frame(c(model = "summer_P", glance(m5n), modelsum(m5n), as.data.frame(r.squaredGLMM(m5n)))),
    as.data.frame(c(model = "autumn_P", glance(m5an), modelsum(m5an), as.data.frame(r.squaredGLMM(m5an)))),
    
    as.data.frame(c(model = "prev_summer_T", glance(m6n), modelsum(m6n), as.data.frame(r.squaredGLMM(m6n)))),
    as.data.frame(c(model = "prev_autumn_T", glance(m7n), modelsum(m7n), as.data.frame(r.squaredGLMM(m7n)))),
    as.data.frame(c(model = "winter_T", glance(m8n), modelsum(m8n), as.data.frame(r.squaredGLMM(m8n)))),
    as.data.frame(c(model = "spring_T", glance(m9n), modelsum(m9n), as.data.frame(r.squaredGLMM(m9n)))),
    as.data.frame(c(model = "summer_T", glance(m10n), modelsum(m10n), as.data.frame(r.squaredGLMM(m10n)))),
    as.data.frame(c(model = "autumn_T", glance(m10an), modelsum(m10an), as.data.frame(r.squaredGLMM(m10an)))),
    
    as.data.frame(c(model = "prev_summer_surfT", glance(m11n), modelsum(m11n), as.data.frame(r.squaredGLMM(m11n)))),
    as.data.frame(c(model = "prev_autumn_surfT", glance(m12n), modelsum(m12n), as.data.frame(r.squaredGLMM(m12n)))),
    as.data.frame(c(model = "winter_surfT", glance(m13n), modelsum(m13n), as.data.frame(r.squaredGLMM(m13n)))),
    as.data.frame(c(model = "spring_surfT", glance(m14n), modelsum(m14n), as.data.frame(r.squaredGLMM(m14n)))),
    as.data.frame(c(model = "summer_surfT", glance(m15n), modelsum(m15n), as.data.frame(r.squaredGLMM(m15n)))),
    as.data.frame(c(model = "autumn_surfT", glance(m15an), modelsum(m15an), as.data.frame(r.squaredGLMM(m15an)))),
    
    as.data.frame(c(model = "prev_summer_scPDSI", glance(m16n), modelsum(m16n), as.data.frame(r.squaredGLMM(m16n)))),
    as.data.frame(c(model = "prev_autumn_scPDSI", glance(m17n), modelsum(m17n), as.data.frame(r.squaredGLMM(m17n)))),
    as.data.frame(c(model = "winter_scPDSI", glance(m18n), modelsum(m18n), as.data.frame(r.squaredGLMM(m18n)))),
    as.data.frame(c(model = "spring_scPDSI", glance(m19n), modelsum(m19n), as.data.frame(r.squaredGLMM(m19n)))),
    as.data.frame(c(model = "summer_scPDSI", glance(m20n), modelsum(m20n), as.data.frame(r.squaredGLMM(m20n)))),
    as.data.frame(c(model = "autumn_scPDSI", glance(m20an), modelsum(m20an), as.data.frame(r.squaredGLMM(m20an)))),
    
    as.data.frame(c(model = "prev_summer_sun", glance(m21n), modelsum(m21n), as.data.frame(r.squaredGLMM(m21n)))),
    as.data.frame(c(model = "prev_autumn_sun", glance(m22n), modelsum(m22n), as.data.frame(r.squaredGLMM(m22n)))),
    as.data.frame(c(model = "winter_sun", glance(m23n), modelsum(m23n), as.data.frame(r.squaredGLMM(m23n)))),
    as.data.frame(c(model = "spring_sun", glance(m24n), modelsum(m24n), as.data.frame(r.squaredGLMM(m24n)))),
    as.data.frame(c(model = "summer_sun", glance(m25n), modelsum(m25n), as.data.frame(r.squaredGLMM(m25n)))),
    as.data.frame(c(model = "autumn_sun", glance(m25an), modelsum(m25an), as.data.frame(r.squaredGLMM(m25an)))),
    
    as.data.frame(c(model = "null", glance(mNULLn), modelsum(mNULLn), as.data.frame(r.squaredGLMM(mNULLn)))))
  
  ranking <- arrange(models, AIC)
  ranking
}

mixed_model_random_subsite_REML <- function(data, nshoot_length) { 
  
  m1n <- lme(nshoot_length ~ nprev_summer_P, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m2n <- lme(nshoot_length ~ nprev_autumn_P, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))  
  m3n <- lme(nshoot_length ~ nwinter_P, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))  
  m4n <- lme(nshoot_length ~ nspring_P, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))  
  m5n <- lme(nshoot_length ~ nsummer_P, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m5an <- lme(nshoot_length ~ nautumn_P, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  
  m6n <- lme(nshoot_length ~ nprev_summer_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m7n <- lme(nshoot_length ~ nprev_autumn_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m8n <- lme(nshoot_length ~ nwinter_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m9n <- lme(nshoot_length ~ nspring_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m10n <- lme(nshoot_length ~ nsummer_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m10an <- lme(nshoot_length ~ nautumn_meanT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  m11n <- lme(nshoot_length ~ nprev_summer_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m12n <- lme(nshoot_length ~ nprev_autumn_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m13n <- lme(nshoot_length ~ nwinter_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m14n <- lme(nshoot_length ~ nspring_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m15n <- lme(nshoot_length ~ nsummer_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m15an <- lme(nshoot_length ~ nautumn_minSurfT, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  m16n <- lme(nshoot_length ~ nprev_summer_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m17n <- lme(nshoot_length ~ nprev_autumn_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m18n <- lme(nshoot_length ~ nwinter_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m19n <- lme(nshoot_length ~ nspring_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m20n <- lme(nshoot_length ~ nsummer_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m20an <- lme(nshoot_length ~ nautumn_scPDSI, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  m21n <- lme(nshoot_length ~ nprev_summer_sun, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m22n <- lme(nshoot_length ~ nprev_autumn_sun, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m23n <- lme(nshoot_length ~ nwinter_sun, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m24n <- lme(nshoot_length ~ nspring_sun, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000)) 
  m25n <- lme(nshoot_length ~ nsummer_sun, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  m25an <- lme(nshoot_length ~ nautumn_sun, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  mNULLn <- lme(nshoot_length ~ 1, random=~1|subsite, cor=corAR1(), data = data, method = "REML", control=list(maxIter=1000))
  
  modelsum <- function(x) { 
    if(length(x$varFix) == 4) {
      modelsum <- cbind.data.frame(summary(x)$tTable[1,1],summary(x)$tTable[1,2],summary(x)$tTable[2,1],summary(x)$tTable[2,2])
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    } else {
      modelsum <- cbind.data.frame("NA", "NA", "NA", "NA")
      names(modelsum) <- c("Intercept", "Intercept_SE", "Slope", "Slope_SE")
      modelsum
    }
  }
  
  models <- rbind(
    as.data.frame(c(model = "prev_summer_P", glance(m1n), modelsum(m1n), as.data.frame(r.squaredGLMM(m1n)))), 
    as.data.frame(c(model = "prev_autumn_P", glance(m2n), modelsum(m2n), as.data.frame(r.squaredGLMM(m2n)))), 
    as.data.frame(c(model = "winter_P", glance(m3n), modelsum(m3n), as.data.frame(r.squaredGLMM(m3n)))), 
    as.data.frame(c(model = "spring_P", glance(m4n), modelsum(m4n), as.data.frame(r.squaredGLMM(m4n)))),
    as.data.frame(c(model = "summer_P", glance(m5n), modelsum(m5n), as.data.frame(r.squaredGLMM(m5n)))),
    as.data.frame(c(model = "autumn_P", glance(m5an), modelsum(m5an), as.data.frame(r.squaredGLMM(m5an)))),
    
    as.data.frame(c(model = "prev_summer_T", glance(m6n), modelsum(m6n), as.data.frame(r.squaredGLMM(m6n)))),
    as.data.frame(c(model = "prev_autumn_T", glance(m7n), modelsum(m7n), as.data.frame(r.squaredGLMM(m7n)))),
    as.data.frame(c(model = "winter_T", glance(m8n), modelsum(m8n), as.data.frame(r.squaredGLMM(m8n)))),
    as.data.frame(c(model = "spring_T", glance(m9n), modelsum(m9n), as.data.frame(r.squaredGLMM(m9n)))),
    as.data.frame(c(model = "summer_T", glance(m10n), modelsum(m10n), as.data.frame(r.squaredGLMM(m10n)))),
    as.data.frame(c(model = "autumn_T", glance(m10an), modelsum(m10an), as.data.frame(r.squaredGLMM(m10an)))),
    
    as.data.frame(c(model = "prev_summer_surfT", glance(m11n), modelsum(m11n), as.data.frame(r.squaredGLMM(m11n)))),
    as.data.frame(c(model = "prev_autumn_surfT", glance(m12n), modelsum(m12n), as.data.frame(r.squaredGLMM(m12n)))),
    as.data.frame(c(model = "winter_surfT", glance(m13n), modelsum(m13n), as.data.frame(r.squaredGLMM(m13n)))),
    as.data.frame(c(model = "spring_surfT", glance(m14n), modelsum(m14n), as.data.frame(r.squaredGLMM(m14n)))),
    as.data.frame(c(model = "summer_surfT", glance(m15n), modelsum(m15n), as.data.frame(r.squaredGLMM(m15n)))),
    as.data.frame(c(model = "autumn_surfT", glance(m15an), modelsum(m15an), as.data.frame(r.squaredGLMM(m15an)))),
    
    as.data.frame(c(model = "prev_summer_scPDSI", glance(m16n), modelsum(m16n), as.data.frame(r.squaredGLMM(m16n)))),
    as.data.frame(c(model = "prev_autumn_scPDSI", glance(m17n), modelsum(m17n), as.data.frame(r.squaredGLMM(m17n)))),
    as.data.frame(c(model = "winter_scPDSI", glance(m18n), modelsum(m18n), as.data.frame(r.squaredGLMM(m18n)))),
    as.data.frame(c(model = "spring_scPDSI", glance(m19n), modelsum(m19n), as.data.frame(r.squaredGLMM(m19n)))),
    as.data.frame(c(model = "summer_scPDSI", glance(m20n), modelsum(m20n), as.data.frame(r.squaredGLMM(m20n)))),
    as.data.frame(c(model = "autumn_scPDSI", glance(m20an), modelsum(m20an), as.data.frame(r.squaredGLMM(m20an)))),
    
    as.data.frame(c(model = "prev_summer_sun", glance(m21n), modelsum(m21n), as.data.frame(r.squaredGLMM(m21n)))),
    as.data.frame(c(model = "prev_autumn_sun", glance(m22n), modelsum(m22n), as.data.frame(r.squaredGLMM(m22n)))),
    as.data.frame(c(model = "winter_sun", glance(m23n), modelsum(m23n), as.data.frame(r.squaredGLMM(m23n)))),
    as.data.frame(c(model = "spring_sun", glance(m24n), modelsum(m24n), as.data.frame(r.squaredGLMM(m24n)))),
    as.data.frame(c(model = "summer_sun", glance(m25n), modelsum(m25n), as.data.frame(r.squaredGLMM(m25n)))),
    as.data.frame(c(model = "autumn_sun", glance(m25an), modelsum(m25an), as.data.frame(r.squaredGLMM(m25an)))),
    
    as.data.frame(c(model = "null", glance(mNULLn), modelsum(mNULLn), as.data.frame(r.squaredGLMM(mNULLn)))))
  
  ranking <- arrange(models, AIC)
  ranking
}

mixedmodels3 <- data %>% 
  group_by(site) %>% 
  do(fit = mixed_model_random_subsite(., nshoot_length))

mixedmodels4 <- mixedmodels3$fit %>% 
  enframe() %>% 
  unnest()

mixedmodels5 <- data %>% 
  group_by(site) %>% 
  do(fit = mixed_model_random_subsite_REML(., nshoot_length))

mixedmodels6 <- mixedmodels5$fit %>% 
  enframe() %>% 
  unnest()

write.csv(mixedmodels4, file = 'mixedmodels_random_subsite_ML.csv') 
write.csv(mixedmodels6, file = 'mixedmodels_random_subsite_REML.csv') 



