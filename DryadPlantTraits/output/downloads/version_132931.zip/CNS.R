### Code written by Stef Weijers (stef.weijers@uni-bonn.de) 

CNS<-read.csv('CNS.csv')
CNS$site<-'Spiekeroog'
CNS$site_code<-'SP'
CNS$subsite<-substring(CNS$Sample, 1, 1)
CNS$CNratio<-CNS$C/CNS$N

library(dplyr)

CNS %>% group_by(subsite) %>% summarise(statistic = shapiro.test(N)$statistic, 
                                        p.value = shapiro.test(N)$p.value)

CNS %>% group_by(subsite) %>% summarise(statistic = shapiro.test(C)$statistic, 
                                        p.value = shapiro.test(C)$p.value)

CNS %>% group_by(subsite) %>% summarise(statistic = shapiro.test(S)$statistic, 
                                        p.value = shapiro.test(S)$p.value)

CNS2<- mutate(CNS, subsite = factor(subsite, levels=unique(subsite)))

library(FSA)
dunnTest(CNS2$N,
         g = CNS2$subsite, method = 'bh')

dunnTest(CNS2$C,
         g = CNS2$subsite, method = 'bh')

dunnTest(CNS2$CNratio,
         g = CNS2$subsite, method = 'bh')


library(ggplot2)
a<-ggplot(CNS, aes(x=subsite, y=CNratio, fill=subsite)) + 
  scale_y_continuous(expression("C:N"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')+
  annotate("text", x=1, y=84, label= "a") + 
  annotate("text", x =2, y=84, label = "b")+
  annotate("text", x =3, y=84, label = "b")+
  annotate("text", x =4, y=84, label = "b")+
  xlab("Site") 

b<-ggplot(CNS, aes(x=subsite, y=C, fill=subsite)) + 
  scale_y_continuous(expression("Carbon content (%)"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Blues')+
  annotate("text", x=1, y=56.5, label= "a") + 
  annotate("text", x =2, y=56.5, label = "ac")+
  annotate("text", x =3, y=56.5, label = "b")+
  annotate("text", x =4, y=56.5, label = "c")+
  xlab("Site") 

c<-ggplot(CNS, aes(x=subsite, y=N, fill=subsite)) + 
  scale_y_continuous(expression("Nitrogen content (%)"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Reds')+
  annotate("text", x=1, y=1.6, label= "a") + 
  annotate("text", x =2, y=1.6, label = "b")+
  annotate("text", x =3, y=1.6, label = "b")+
  annotate("text", x =4, y=1.6, label = "b")+
  xlab("Site") 

library(cowplot)
plot_grid(a, b, c, nrow=1, labels = c("(a)", "(b)", "(c)"),
          vjust=1, hjust = 0.05, align = 'hv')
