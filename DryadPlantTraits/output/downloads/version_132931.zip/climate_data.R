### Code written by Stef Weijers (stef.weijers@uni-bonn.de) 

clim_Norderney<-read.csv('clim_Norderney2.csv')

clim_Norderney$prev_summer_minSurfT<-rowMeans(cbind(clim_Norderney$p_minSurfT_Jun,
                                                    clim_Norderney$p_minSurfT_Jul, clim_Norderney$p_minSurfT_Aug))
clim_Norderney$prev_autumn_minSurfT<-rowMeans(cbind(clim_Norderney$p_minSurfT_Sep,
                                                    clim_Norderney$p_minSurfT_Oct, clim_Norderney$p_minSurfT_Nov))
clim_Norderney$winter_minSurfT<-rowMeans(cbind(clim_Norderney$p_minSurfT_Dec,
                                               clim_Norderney$minSurfT_Jan, clim_Norderney$minSurfT_Feb))
clim_Norderney$spring_minSurfT<-rowMeans(cbind(clim_Norderney$minSurfT_Mar,
                                               clim_Norderney$minSurfT_Apr, clim_Norderney$minSurfT_May))
clim_Norderney$summer_minSurfT<-rowMeans(cbind(clim_Norderney$minSurfT_Jun,
                                               clim_Norderney$minSurfT_Jul, clim_Norderney$minSurfT_Aug))
clim_Norderney$autumn_minSurfT<-rowMeans(cbind(clim_Norderney$minSurfT_Sep,
                                               clim_Norderney$minSurfT_Oct, clim_Norderney$minSurfT_Nov))


clim_Norderney$prev_summer_meanT<-rowMeans(cbind(clim_Norderney$p_meanT_Jun,
                                                    clim_Norderney$p_meanT_Jul, clim_Norderney$p_meanT_Aug))
clim_Norderney$prev_autumn_meanT<-rowMeans(cbind(clim_Norderney$p_meanT_Sep,
                                                    clim_Norderney$p_meanT_Oct, clim_Norderney$p_meanT_Nov))
clim_Norderney$winter_meanT<-rowMeans(cbind(clim_Norderney$p_meanT_Dec,
                                               clim_Norderney$meanT_Jan, clim_Norderney$meanT_Feb))
clim_Norderney$spring_meanT<-rowMeans(cbind(clim_Norderney$meanT_Mar,
                                               clim_Norderney$meanT_Apr, clim_Norderney$meanT_May))
clim_Norderney$summer_meanT<-rowMeans(cbind(clim_Norderney$meanT_Jun,
                                               clim_Norderney$meanT_Jul, clim_Norderney$meanT_Aug))
clim_Norderney$autumn_meanT<-rowMeans(cbind(clim_Norderney$meanT_Sep,
                                            clim_Norderney$meanT_Oct, clim_Norderney$meanT_Nov))

clim_Norderney$prev_summer_P<-rowSums(cbind(clim_Norderney$p_P_Jun,
                                                 clim_Norderney$p_P_Jul, clim_Norderney$p_P_Aug))
clim_Norderney$prev_autumn_P<-rowSums(cbind(clim_Norderney$p_P_Sep,
                                                 clim_Norderney$p_P_Oct, clim_Norderney$p_P_Nov))
clim_Norderney$winter_P<-rowSums(cbind(clim_Norderney$p_P_Dec,
                                            clim_Norderney$P_Jan, clim_Norderney$P_Feb))
clim_Norderney$spring_P<-rowSums(cbind(clim_Norderney$P_Mar,
                                            clim_Norderney$P_Apr, clim_Norderney$P_May))
clim_Norderney$summer_P<-rowSums(cbind(clim_Norderney$P_Jun,
                                            clim_Norderney$P_Jul, clim_Norderney$P_Aug))
clim_Norderney$autumn_P<-rowSums(cbind(clim_Norderney$P_Sep,
                                       clim_Norderney$P_Oct, clim_Norderney$P_Nov))

clim_Norderney$prev_summer_sun<-rowSums(cbind(clim_Norderney$p_sun_Jun,
                                             clim_Norderney$p_sun_Jul, clim_Norderney$p_sun_Aug))
clim_Norderney$prev_autumn_sun<-rowSums(cbind(clim_Norderney$p_sun_Sep,
                                             clim_Norderney$p_sun_Oct, clim_Norderney$p_sun_Nov))
clim_Norderney$winter_sun<-rowSums(cbind(clim_Norderney$p_sun_Dec,
                                        clim_Norderney$sun_Jan, clim_Norderney$sun_Feb))
clim_Norderney$spring_sun<-rowSums(cbind(clim_Norderney$sun_Mar,
                                        clim_Norderney$sun_Apr, clim_Norderney$sun_May))
clim_Norderney$summer_sun<-rowSums(cbind(clim_Norderney$sun_Jun,
                                        clim_Norderney$sun_Jul, clim_Norderney$sun_Aug))
clim_Norderney$autumn_sun<-rowSums(cbind(clim_Norderney$sun_Sep,
                                         clim_Norderney$sun_Oct, clim_Norderney$sun_Nov))


clim_Norderney$prev_summer_scPDSI<-rowMeans(cbind(clim_Norderney$pJun_scPDSI,
                                             clim_Norderney$pJul_scPDSI, clim_Norderney$pAug_scPDSI))
clim_Norderney$prev_autumn_scPDSI<-rowMeans(cbind(clim_Norderney$pSep_scPDSI,
                                             clim_Norderney$pOct_scPDSI, clim_Norderney$pNov_scPDSI))
clim_Norderney$winter_scPDSI<-rowMeans(cbind(clim_Norderney$pDec_scPDSI,
                                        clim_Norderney$Jan_scPDSI, clim_Norderney$Feb_scPDSI))
clim_Norderney$spring_scPDSI<-rowMeans(cbind(clim_Norderney$Mar_scPDSI,
                                        clim_Norderney$Apr_scPDSI, clim_Norderney$May_scPDSI))
clim_Norderney$summer_scPDSI<-rowMeans(cbind(clim_Norderney$Jun_scPDSI,
                                        clim_Norderney$Jul_scPDSI, clim_Norderney$Aug_scPDSI))
clim_Norderney$autumn_scPDSI<-rowMeans(cbind(clim_Norderney$Sep_scPDSI,
                                             clim_Norderney$Oct_scPDSI, clim_Norderney$Nov_scPDSI))


clim_Norderney$nprev_summer_minSurfT <- scale(clim_Norderney$prev_summer_minSurfT)
clim_Norderney$nprev_autumn_minSurfT <-scale(clim_Norderney$prev_autumn_minSurfT)
clim_Norderney$nwinter_minSurfT <-scale(clim_Norderney$winter_minSurfT)
clim_Norderney$nspring_minSurfT <-scale(clim_Norderney$spring_minSurfT)
clim_Norderney$nsummer_minSurfT <-scale(clim_Norderney$summer_minSurfT)
clim_Norderney$nautumn_minSurfT <-scale(clim_Norderney$autumn_minSurfT)

clim_Norderney$nprev_summer_meanT <- scale(clim_Norderney$prev_summer_meanT)
clim_Norderney$nprev_autumn_meanT <-scale(clim_Norderney$prev_autumn_meanT)
clim_Norderney$nwinter_meanT <-scale(clim_Norderney$winter_meanT)
clim_Norderney$nspring_meanT <-scale(clim_Norderney$spring_meanT)
clim_Norderney$nsummer_meanT <-scale(clim_Norderney$summer_meanT)
clim_Norderney$nautumn_meanT <-scale(clim_Norderney$autumn_meanT)

clim_Norderney$nprev_summer_P <- scale(clim_Norderney$prev_summer_P)
clim_Norderney$nprev_autumn_P <-scale(clim_Norderney$prev_autumn_P)
clim_Norderney$nwinter_P <-scale(clim_Norderney$winter_P)
clim_Norderney$nspring_P <-scale(clim_Norderney$spring_P)
clim_Norderney$nsummer_P <-scale(clim_Norderney$summer_P)
clim_Norderney$nautumn_P <-scale(clim_Norderney$autumn_P)

clim_Norderney$nprev_summer_sun <- scale(clim_Norderney$prev_summer_sun)
clim_Norderney$nprev_autumn_sun <-scale(clim_Norderney$prev_autumn_sun)
clim_Norderney$nwinter_sun <-scale(clim_Norderney$winter_sun)
clim_Norderney$nspring_sun <-scale(clim_Norderney$spring_sun)
clim_Norderney$nsummer_sun <-scale(clim_Norderney$summer_sun)
clim_Norderney$nautumn_sun <-scale(clim_Norderney$autumn_sun)

clim_Norderney$nprev_summer_scPDSI <- scale(clim_Norderney$prev_summer_scPDSI)
clim_Norderney$nprev_autumn_scPDSI <-scale(clim_Norderney$prev_autumn_scPDSI)
clim_Norderney$nwinter_scPDSI <-scale(clim_Norderney$winter_scPDSI)
clim_Norderney$nspring_scPDSI <-scale(clim_Norderney$spring_scPDSI)
clim_Norderney$nsummer_scPDSI <-scale(clim_Norderney$summer_scPDSI)
clim_Norderney$nautumn_scPDSI <-scale(clim_Norderney$autumn_scPDSI)

