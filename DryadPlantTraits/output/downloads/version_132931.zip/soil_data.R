soil_data<-read.csv('Soil data combined.csv')

soil_data_10<-subset(soil_data, Soil_Depth == 10 )
soil_data_30<-subset(soil_data, Soil_Depth == 30 )

library(dplyr)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(pH_H2O)$statistic, 
                                              p.value = shapiro.test(pH_H2O)$p.value)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(pH_CaCl)$statistic, 
                                                 p.value = shapiro.test(pH_CaCl)$p.value)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Conductivity)$statistic, 
                                              p.value = shapiro.test(Conductivity)$p.value)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(MoistFactor)$statistic, 
                                              p.value = shapiro.test(MoistFactor)$p.value)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Chloride_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Chloride_.mg.l.)$p.value)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Nitrate_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Nitrate_.mg.l.)$p.value)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Phosphat_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Phosphat_.mg.l.)$p.value)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Sulfate_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Sulfate_.mg.l.)$p.value)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Salinity.pct)$statistic, 
                                              p.value = shapiro.test(Salinity.pct)$p.value)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Moisture.pct)$statistic, 
                                              p.value = shapiro.test(Moisture.pct)$p.value)
soil_data_10 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Carbonate)$statistic, 
                                              p.value = shapiro.test(Carbonate)$p.value)

soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(pH_H2O)$statistic, 
                                              p.value = shapiro.test(pH_H2O)$p.value)
soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(pH_CaCl)$statistic, 
                                              p.value = shapiro.test(pH_CaCl)$p.value)
soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Conductivity)$statistic, 
                                              p.value = shapiro.test(Conductivity)$p.value)
soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(MoistFactor)$statistic, 
                                              p.value = shapiro.test(MoistFactor)$p.value)
soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Chloride_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Chloride_.mg.l.)$p.value)
soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Nitrate_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Nitrate_.mg.l.)$p.value)
soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Phosphat_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Phosphat_.mg.l.)$p.value)
soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Sulfate_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Sulfate_.mg.l.)$p.value)
soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Salinity.pct)$statistic, 
                                              p.value = shapiro.test(Salinity.pct)$p.value)
soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Moisture.pct)$statistic, 
                                              p.value = shapiro.test(Moisture.pct)$p.value)
soil_data_30 %>% group_by(Site) %>% summarise(statistic = shapiro.test(Carbonate)$statistic, 
                                              p.value = shapiro.test(Carbonate)$p.value)

soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(pH_H2O)$statistic, 
                                              p.value = shapiro.test(pH_H2O)$p.value)
soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(pH_CaCl)$statistic, 
                                              p.value = shapiro.test(pH_CaCl)$p.value)
soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(Conductivity)$statistic, 
                                              p.value = shapiro.test(Conductivity)$p.value)
soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(MoistFactor)$statistic, 
                                              p.value = shapiro.test(MoistFactor)$p.value)
soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(Chloride_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Chloride_.mg.l.)$p.value)
soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(Nitrate_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Nitrate_.mg.l.)$p.value)
soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(Phosphat_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Phosphat_.mg.l.)$p.value)
soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(Sulfate_.mg.l.)$statistic, 
                                              p.value = shapiro.test(Sulfate_.mg.l.)$p.value)
soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(Salinity.pct)$statistic, 
                                              p.value = shapiro.test(Salinity.pct)$p.value)
soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(Moisture.pct)$statistic, 
                                              p.value = shapiro.test(Moisture.pct)$p.value)
soil_data %>% group_by(Site) %>% summarise(statistic = shapiro.test(Carbonate)$statistic, 
                                              p.value = shapiro.test(Carbonate)$p.value)

library(lattice)
library(FSA)
citation('FSA')
citation('dunn.test')
histogram(~ pH_H2O | Site, data=soil_data, layout=c(1,4))
kruskal.test(pH_H2O ~ Site, data = soil_data)
dunnTest(soil_data$pH_H2O, g = soil_data$Site, method = 'bh')

histogram(~ pH_CaCl | Site, data=soil_data, layout=c(1,4))
kruskal.test(pH_CaCl ~ Site, data = soil_data)
dunnTest(soil_data$pH_CaCl, g = soil_data$Site, method = 'bh')

histogram(~ Conductivity | Site, data=soil_data, layout=c(1,4))
kruskal.test(Conductivity ~ Site, data = soil_data)
dunnTest(soil_data$Conductivity, g = soil_data$Site, method = 'bh')

histogram(~ MoistFactor | Site, data=soil_data, layout=c(1,4))
kruskal.test(MoistFactor ~ Site, data = soil_data)
TukeyHSD(aov(soil_data$MoistFactor~Site, data=soil_data))

histogram(~ Chloride_.mg.l. | Site, data=soil_data, layout=c(1,4))
kruskal.test(Chloride_.mg.l. ~ Site, data = soil_data)
TukeyHSD(aov(soil_data$Chloride_.mg.l.~Site, data=soil_data))

histogram(~ Nitrate_.mg.l. | Site, data=soil_data, layout=c(1,4))
kruskal.test(Nitrate_.mg.l. ~ Site, data = soil_data)
TukeyHSD(aov(soil_data$Nitrate_.mg.l.~Site, data=soil_data))

histogram(~ Sulfate_.mg.l. | Site, data=soil_data, layout=c(1,4))
kruskal.test(Sulfate_.mg.l. ~ Site, data = soil_data)
TukeyHSD(aov(soil_data$Sulfate_.mg.l.~Site, data=soil_data))

histogram(~ Phosphat_.mg.l. | Site, data=soil_data, layout=c(1,4))
kruskal.test(Phosphat_.mg.l. ~ Site, data = soil_data)
TukeyHSD(aov(soil_data$Phosphat_.mg.l.~Site, data=soil_data))

histogram(~ Salinity.pct | Site, data=soil_data, layout=c(1,4))
kruskal.test(Salinity.pct ~ Site, data = soil_data)
TukeyHSD(aov(soil_data$Salinity.pct~Site, data=soil_data))

histogram(~ Moisture.pct | Site, data=soil_data, layout=c(1,4))
kruskal.test(Moisture.pct ~ Site, data = soil_data)
TukeyHSD(aov(soil_data$Moisture.pct~Site, data=soil_data))

histogram(~ Carbonate | Site, data=soil_data, layout=c(1,4))
kruskal.test(Carbonate ~ Site, data = soil_data)
TukeyHSD(aov(soil_data$Carbonate~Site, data=soil_data))

### now for different soil layers
histogram(~ pH_H2O | Site, data=soil_data_10, layout=c(1,4))
kruskal.test(pH_H2O ~ Site, data = soil_data_10)
dunnTest(soil_data_10$pH_H2O, g = soil_data_10$Site, method = 'bh')

histogram(~ pH_CaCl | Site, data=soil_data_10, layout=c(1,4))
kruskal.test(pH_CaCl ~ Site, data = soil_data_10)
TukeyHSD(aov(soil_data_10$pH_CaCl~Site, data=soil_data_10))

histogram(~ Conductivity | Site, data=soil_data_10, layout=c(1,4))
kruskal.test(Conductivity ~ Site, data = soil_data_10)
dunnTest(soil_data_10$Conductivity, g = soil_data_10$Site, method = 'bh')

histogram(~ Moisture.pct | Site, data=soil_data_10, layout=c(1,4))
kruskal.test(Moisture.pct ~ Site, data = soil_data_10)
TukeyHSD(aov(soil_data_10$Moisture.pct~Site, data=soil_data_10))

histogram(~ Chloride_.mg.l. | Site, data=soil_data_10, layout=c(1,4))
kruskal.test(Chloride_.mg.l. ~ Site, data = soil_data_10)
TukeyHSD(aov(soil_data_10$Chloride_.mg.l.~Site, data=soil_data_10))

histogram(~ Nitrate_.mg.l. | Site, data=soil_data_10, layout=c(1,4))
kruskal.test(Nitrate_.mg.l. ~ Site, data = soil_data_10)
TukeyHSD(aov(soil_data_10$Nitrate_.mg.l.~Site, data=soil_data_10))

histogram(~ Phosphat_.mg.l. | Site, data=soil_data_10, layout=c(1,4))
kruskal.test(Phosphat_.mg.l. ~ Site, data = soil_data_10)
TukeyHSD(aov(soil_data_10$Phosphat_.mg.l.~Site, data=soil_data_10))

histogram(~ Sulfate_.mg.l. | Site, data=soil_data_10, layout=c(1,4))
kruskal.test(Sulfate_.mg.l. ~ Site, data = soil_data_10)
TukeyHSD(aov(soil_data_10$Sulfate_.mg.l.~Site, data=soil_data_10))

histogram(~ Carbonate | Site, data=soil_data_10, layout=c(1,4))
kruskal.test(Carbonate ~ Site, data = soil_data_10)
TukeyHSD(aov(soil_data_10$Carbonate~Site, data=soil_data_10))

###-30cm
histogram(~ pH_H2O | Site, data=soil_data_30, layout=c(1,4))
kruskal.test(pH_H2O ~ Site, data = soil_data_30)
dunnTest(soil_data_30$pH_H2O, g = soil_data_30$Site, method = 'bh')

histogram(~ pH_CaCl | Site, data=soil_data_30, layout=c(1,4))
kruskal.test(pH_CaCl ~ Site, data = soil_data_30)
dunnTest(soil_data_30$pH_CaCl, g = soil_data_30$Site, method = 'bh')

histogram(~ Conductivity | Site, data=soil_data_30, layout=c(1,4))
kruskal.test(Conductivity ~ Site, data = soil_data_30)
dunnTest(soil_data_30$Conductivity, g = soil_data_30$Site, method = 'bh')

histogram(~ Moisture.pct | Site, data=soil_data_30, layout=c(1,4))
kruskal.test(Moisture.pct ~ Site, data = soil_data_30)
TukeyHSD(aov(soil_data_30$Moisture.pct~Site, data=soil_data_30))


histogram(~ Chloride_.mg.l. | Site, data=soil_data_30, layout=c(1,4))
kruskal.test(Chloride_.mg.l. ~ Site, data = soil_data_30)
TukeyHSD(aov(soil_data_30$Chloride_.mg.l.~Site, data=soil_data_30))

histogram(~ Nitrate_.mg.l. | Site, data=soil_data_30, layout=c(1,4))
kruskal.test(Nitrate_.mg.l. ~ Site, data = soil_data_30)
TukeyHSD(aov(soil_data_30$Nitrate_.mg.l.~Site, data=soil_data_30))

histogram(~ Phosphat_.mg.l. | Site, data=soil_data_30, layout=c(1,4))
kruskal.test(Phosphat_.mg.l. ~ Site, data = soil_data_30)
TukeyHSD(aov(soil_data_30$Phosphat_.mg.l.~Site, data=soil_data_30))

histogram(~ Sulfate_.mg.l. | Site, data=soil_data_30, layout=c(1,4))
kruskal.test(Sulfate_.mg.l. ~ Site, data = soil_data_30)
TukeyHSD(aov(soil_data_30$Sulfate_.mg.l.~Site, data=soil_data_30))

histogram(~ Carbonate | Site, data=soil_data_30, layout=c(1,4))
kruskal.test(Carbonate ~ Site, data = soil_data_30)
TukeyHSD(aov(soil_data_30$Carbonate~Site, data=soil_data_30))

library(ggplot2)
i<-ggplot(soil_data, aes(x=Site, y=pH_H2O, fill=Site)) + 
  scale_y_continuous(expression("pH H"[2]*"O combined"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')+
  annotate("text", x=1, y=6.25, label= "a") + 
  annotate("text", x =2, y=6.25, label = "b")+
  annotate("text", x =3, y=6.25, label = "b")+
  annotate("text", x =4, y=6.25, label = "b")

j<-ggplot(soil_data, aes(x=Site, y=pH_CaCl, fill=Site)) + 
  scale_y_continuous(expression("pH CaCl combined"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')+
  annotate("text", x=1, y=5, label= "a") + 
  annotate("text", x =2, y=5, label = "b")+
  annotate("text", x =3, y=5, label = "b")+
  annotate("text", x =4, y=5, label = "b")

k<-ggplot(soil_data, aes(x=Site, y=Conductivity, fill=Site)) + 
  scale_y_continuous(expression("Conductivity (�S/cm) combined"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')+
  annotate("text", x=1, y=19.5, label= "a") + 
  annotate("text", x =2, y=19.5, label = "b")+
  annotate("text", x =3, y=19.5, label = "b")+
  annotate("text", x =4, y=19.5, label = "b")

### Double as there is also Moisture %
ggplot(soil_data, aes(x=Site, y=MoistFactor, fill=Site)) + 
  scale_y_continuous(expression("Moist factor"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')

ggplot(soil_data, aes(x=Site, y=Chloride_.mg.l., fill=Site)) + 
  scale_y_continuous(expression("Chloride (mg/l)"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')

### B-A & D-B: p<0.01
ggplot(soil_data, aes(x=Site, y=Nitrate_.mg.l., fill=Site)) + 
  scale_y_continuous(expression("Nitrate (mg/l)"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')

ggplot(soil_data, aes(x=Site, y=Phosphat_.mg.l., fill=Site)) + 
  scale_y_continuous(expression("Phosphate (mg/l)"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')


### A-C p=0.091
ggplot(soil_data, aes(x=Site, y=Sulfate_.mg.l., fill=Site)) + 
  scale_y_continuous(expression("Sulphate (mg/l)"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')

ggplot(soil_data, aes(x=Site, y=Salinity.pct, fill=Site)) + 
  scale_y_continuous(expression("Salinity (%)"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')

l<-ggplot(soil_data, aes(x=Site, y=Moisture.pct, fill=Site)) + 
  scale_y_continuous(expression("Moisture (%) combined"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')

ggplot(soil_data, aes(x=Site, y=Carbonate, fill=Site)) + 
  scale_y_continuous(expression("Carbonate (%)"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')

a<-ggplot(soil_data_10, aes(x=Site, y=pH_H2O, fill=Site)) + 
  scale_y_continuous(expression("pH H"[2]*"O 10 cm"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')+
  annotate("text", x=1, y=6.25, label= "a") + 
  annotate("text", x =2, y=6.25, label = "b")+
  annotate("text", x =3, y=6.25, label = "b")+
  annotate("text", x =4, y=6.25, label = "b")

b<-ggplot(soil_data_10, aes(x=Site, y=pH_CaCl, fill=Site)) + 
  scale_y_continuous(expression("pH CaCl 10 cm"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')+
  annotate("text", x=1, y=5, label= "a") + 
  annotate("text", x =2, y=5, label = "b")+
  annotate("text", x =3, y=5, label = "b")+
  annotate("text", x =4, y=5, label = "b")

c<-ggplot(soil_data_10, aes(x=Site, y=Conductivity, fill=Site)) + 
  scale_y_continuous(expression("Conductivity (�S/cm) 10 cm"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')+
  annotate("text", x=1, y=19.5, label= "a") + 
  annotate("text", x =2, y=19.5, label = "b")+
  annotate("text", x =3, y=19.5, label = "ab")+
  annotate("text", x =4, y=19.5, label = "ab")

d<-ggplot(soil_data_10, aes(x=Site, y=Moisture.pct, fill=Site)) + 
  scale_y_continuous(expression("Moisture (%) 10 cm"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')

e<-ggplot(soil_data_30, aes(x=Site, y=pH_H2O, fill=Site)) + 
  scale_y_continuous(expression("pH H"[2]*"O 30 cm"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')+
  annotate("text", x=1, y=6.25, label= "a") + 
  annotate("text", x =2, y=6.25, label = "ab")+
  annotate("text", x =3, y=6.25, label = "b")+
  annotate("text", x =4, y=6.25, label = "b")

f<-ggplot(soil_data_30, aes(x=Site, y=pH_CaCl, fill=Site)) + 
  scale_y_continuous(expression("pH CaCl 30 cm"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')+
  annotate("text", x=1, y=5, label= "a") + 
  annotate("text", x =2, y=5, label = "b")+
  annotate("text", x =3, y=5, label = "b")+
  annotate("text", x =4, y=5, label = "b")

g<-ggplot(soil_data_30, aes(x=Site, y=Conductivity, fill=Site)) + 
  scale_y_continuous(expression("Conductivity (�S/cm) 30 cm"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')+
  annotate("text", x=1, y=19.5, label= "a") + 
  annotate("text", x =2, y=19.5, label = "ab")+
  annotate("text", x =3, y=19.5, label = "b")+
  annotate("text", x =4, y=19.5, label = "b")

h<-ggplot(soil_data_30, aes(x=Site, y=Moisture.pct, fill=Site)) + 
  scale_y_continuous(expression("Moisture (%) 30 cm"))+
  geom_boxplot(notch=F, outlier.colour="black", outlier.shape=20,
               outlier.size=0.1)+theme_bw()+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank())+
  scale_fill_brewer(palette = 'Purples')

library(cowplot)
plot_grid(a,b,c,d,e,f,g,h,i,j,k,l, nrow=3, ncol = 4, labels = c("(a)", "(b)", "(c)", '(d)', '(e)',
                                                            '(f)', '(g)', '(h)','(i)','(j)','(k)','(l)', vjust=6.5),
          align = 'hv')
          
