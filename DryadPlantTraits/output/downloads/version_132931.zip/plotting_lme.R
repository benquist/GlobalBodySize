### Code written by Stef Weijers (stef.weijers@uni-bonn.de) 

library(nlme)
library(effects)
library(ggplot2)

### for 'data' see mixed_models.R
dataA<-subset(data, subsite=='A')
dataB<-subset(data, subsite=='B')
dataC<-subset(data, subsite=='C')
dataD<-subset(data, subsite=='D')

### plotting predictor effects with effects library
### final effect plots
###

###For Spiekeroog

lme1<-lme(nshoot_length ~ nautumn_minSurfT, random=~1|xyear, cor=corAR1(),
          data = data, method = "REML", control=list(maxIter=1000))
lm1_dat<-as.data.frame(predictorEffects(lme1))
lm1_dat <- do.call(rbind.data.frame, lm1_dat)
lm1_dat$factor<-'autumn min. Ts'
colnames(lm1_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

lme2<-lme(nshoot_length ~ nautumn_meanT, random=~1|xyear, cor=corAR1(),
          data = data, method = "REML", control=list(maxIter=1000))
lm2_dat<-as.data.frame(predictorEffects(lme2))
lm2_dat <- do.call(rbind.data.frame, lm2_dat)
lm2_dat$factor<-'autumn Ta'
colnames(lm2_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

effects_spiekeroog<-rbind(lm1_dat, lm2_dat)
effects_spiekeroog$Site<-'Spiekeroog'

### for site A
lme3<-lme(nshoot_length ~ nautumn_minSurfT, random=~1|xyear, cor=corAR1(),
          data = dataA, method = "REML", control=list(maxIter=1000))
lm3_dat<-as.data.frame(predictorEffects(lme3))
lm3_dat <- do.call(rbind.data.frame, lm3_dat)
lm3_dat$factor<-'autumn min. Ts'
colnames(lm3_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

lme4<-lme(nshoot_length ~ nprev_summer_minSurfT, random=~1|xyear, cor=corAR1(),
          data = dataA, method = "REML", control=list(maxIter=1000))
lm4_dat<-as.data.frame(predictorEffects(lme4))
lm4_dat <- do.call(rbind.data.frame, lm4_dat)
lm4_dat$factor<-'p. summer min. Ts'
colnames(lm4_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

lme5<-lme(nshoot_length ~ nautumn_meanT, random=~1|xyear, cor=corAR1(),
          data = dataA, method = "REML", control=list(maxIter=1000))
lm5_dat<-as.data.frame(predictorEffects(lme5))
lm5_dat <- do.call(rbind.data.frame, lm5_dat)
lm5_dat$factor<-'autumn Ta'
colnames(lm5_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

effects_siteA<-rbind(lm3_dat, lm4_dat, lm5_dat)
effects_siteA$Site<-'A'

### for site B
lme6<-lme(nshoot_length ~ nautumn_minSurfT, random=~1|xyear, cor=corAR1(),
          data = dataB, method = "REML", control=list(maxIter=1000))
lm6_dat<-as.data.frame(predictorEffects(lme6))
lm6_dat <- do.call(rbind.data.frame, lm6_dat)
lm6_dat$factor<-'autumn min. Ts'
colnames(lm6_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

lme7<-lme(nshoot_length ~ nautumn_meanT, random=~1|xyear, cor=corAR1(),
          data = dataB, method = "REML", control=list(maxIter=1000))
lm7_dat<-as.data.frame(predictorEffects(lme7))
lm7_dat <- do.call(rbind.data.frame, lm7_dat)
lm7_dat$factor<-'autumn Ta'
colnames(lm7_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

lme8<-lme(nshoot_length ~ nsummer_P, random=~1|xyear, cor=corAR1(),
          data = dataB, method = "REML", control=list(maxIter=1000))
lm8_dat<-as.data.frame(predictorEffects(lme8))
lm8_dat <- do.call(rbind.data.frame, lm8_dat)
lm8_dat$factor<-'summer P'
colnames(lm8_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

effects_siteB<-rbind(lm6_dat, lm7_dat, lm8_dat)
effects_siteB$Site<-'B'

### for site C
lme9<-lme(nshoot_length ~ nautumn_minSurfT, random=~1|xyear, cor=corAR1(),
          data = dataC, method = "REML", control=list(maxIter=1000))
lm9_dat<-as.data.frame(predictorEffects(lme9))
lm9_dat <- do.call(rbind.data.frame, lm9_dat)
lm9_dat$factor<-'autumn min. Ts'
colnames(lm9_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

lme10<-lme(nshoot_length ~ nautumn_meanT, random=~1|xyear, cor=corAR1(),
          data = dataC, method = "REML", control=list(maxIter=1000))
lm10_dat<-as.data.frame(predictorEffects(lme10))
lm10_dat <- do.call(rbind.data.frame, lm10_dat)
lm10_dat$factor<-'autumn Ta'
colnames(lm10_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

lme11<-lme(nshoot_length ~ nsummer_P, random=~1|xyear, cor=corAR1(),
          data = dataC, method = "REML", control=list(maxIter=1000))
lm11_dat<-as.data.frame(predictorEffects(lme11))
lm11_dat <- do.call(rbind.data.frame, lm11_dat)
lm11_dat$factor<-'summer P'
colnames(lm11_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

lme12<-lme(nshoot_length ~ nprev_summer_minSurfT, random=~1|xyear, cor=corAR1(),
           data = dataC, method = "REML", control=list(maxIter=1000))
lm12_dat<-as.data.frame(predictorEffects(lme12))
lm12_dat <- do.call(rbind.data.frame, lm12_dat)
lm12_dat$factor<-'p. summer min. Ts'
colnames(lm12_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

effects_siteC<-rbind(lm9_dat, lm10_dat, lm11_dat, lm12_dat)
effects_siteC$Site<-'C'

### for sites A+B+C
lme13<-lme(nshoot_length ~ nautumn_minSurfT, random=~1|xyear, cor=corAR1(),
          data = dataABC, method = "REML", control=list(maxIter=1000))
lm13_dat<-as.data.frame(predictorEffects(lme13))
lm13_dat <- do.call(rbind.data.frame, lm13_dat)
lm13_dat$factor<-'autumn min. Ts'
colnames(lm13_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

lme14<-lme(nshoot_length ~ nautumn_meanT, random=~1|xyear, cor=corAR1(),
           data = dataABC, method = "REML", control=list(maxIter=1000))
lm14_dat<-as.data.frame(predictorEffects(lme14))
lm14_dat <- do.call(rbind.data.frame, lm14_dat)
lm14_dat$factor<-'autumn Ta'
colnames(lm14_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

lme15<-lme(nshoot_length ~ nprev_summer_minSurfT, random=~1|xyear, cor=corAR1(),
           data = dataABC, method = "REML", control=list(maxIter=1000))
lm15_dat<-as.data.frame(predictorEffects(lme15))
lm15_dat <- do.call(rbind.data.frame, lm15_dat)
lm15_dat$factor<-'p. summer min. Ts'
colnames(lm15_dat)<-c('value', 'fit', 'se', 'lower', 'upper', 'factor')

effects_sitesABC<-rbind(lm13_dat, lm14_dat, lm15_dat)
effects_sitesABC$Site<-'A+B+C'


###All combined + final plot (Figure 2)
effects_all<-rbind(effects_siteA, effects_siteB, effects_siteC, effects_sitesABC, effects_spiekeroog)
effects_all$Site_f = factor(effects_all$Site, levels=c('A','B','C', 'Spiekeroog', 'A+B+C'))

ggplot(effects_all, aes(x=value, y=fit)) +
  geom_ribbon(aes(ymin=lower, ymax=upper),
              alpha=0.2) +
  geom_line() +
  facet_grid(factor ~ Site_f, scales = 'fixed')+
  aes(fill=factor)+
  scale_fill_manual(values=c("red", "red", "red", 'blue' ))+
  xlab('predictor (std.)')+
  ylab('shoot length (std.)')+
  theme_light()+
  theme(legend.position = "none")
