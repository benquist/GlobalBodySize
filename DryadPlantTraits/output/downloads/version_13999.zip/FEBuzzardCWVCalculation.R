#=============================================================================================#
# Calculates community weighted variance (CWV) Modified from Tyeen Taylor
#=============================================================================================#

my.traits =read.table(file="FEBuzzardSpTraits.csv",sep=",",header=T,as.is=T)
cwm =read.table(file="FEBuzzard_CWM.csv",sep=",",header=T,as.is=T)


#-----Calculates CWM
# first  set columns in dataframe

my.traits[, c(6,17)] <- sapply(my.traits[, c(6,17)], as.numeric)



#------Creates an empty data frame with 9 columns and number of rows matching number of sites.
sitenum=length(unique(my.traits$plot))
dataset=as.data.frame(matrix(ncol=9,nrow=sitenum))
colnames(dataset)[1:9]=c("site", "age", "abund", "CWV_SLA", "CWV_LDMC", "CWV_d13C", "CWV_d15N", 
                         "CWV_CN", "CWV_LPC")


#------Identity function. I.e., it changes nothing in the vectors where it will be applied,
#      but "aggregate" requires a function to be applied.
idfun=function(a){a*1}

#------Creates a data frame with vector elements (a little "monster", like a matrix
#                                                 whose each element is a vector with a
#                                                 variable number of elements inside)

sla <- c("plot", "age", "Abund.n", "SLA")
newdata.sla <- my.traits[sla]
trait<- na.omit(newdata.sla)

A=aggregate(as.data.frame(trait$Abund.n),by=list(trait$plot, trait$age),idfun)
colnames(A)[1:2]=c("site","age")
#sla 
v=aggregate(as.data.frame(trait$SLA),by=list(trait$plot),idfun)
colnames(v)[1]=c("site")
groupa=merge(A,v,by=c("site"))

# CWM SLA
nrr=nrow(groupa)
for (i in 1:nrr) {
  dataset [i,"CWV_SLA"] = sum((as.data.frame(groupa[i,"trait$Abund.n"])/sum(as.data.frame(
                            groupa[i,"trait$Abund.n"])))*(as.data.frame(groupa[i,"trait$SLA"])
                             -cwm[i,"CWM_SLA"])^2, na.rm=T)}


#d13c

d13c <- c("plot", "Abund.n", "d13C")
newdata.d13c <- my.traits[d13c]
trait<- na.omit(newdata.d13c)

A=aggregate(as.data.frame(trait$Abund.n),by=list(trait$plot),idfun)
colnames(A)[1]=c("site")

v.d13C=aggregate(as.data.frame(trait$d13C),by=list(trait$plot),idfun)
colnames(v.d13C)[1]=c("site")
groupb=merge(A,v.d13C,by=c("site"))

#CWM d13c
for (i in 1:nrr) {
  dataset [i,"CWV_d13C"] = sum((as.data.frame(groupb[i,"trait$Abund.n"])/sum(as.data.frame(
                            groupb[i,"trait$Abund.n"])))*(as.data.frame(groupb[i,"trait$d13C"])
                            -cwm[i,"CWM_d13C"])^2, na.rm=T)}


#d15n

d15n <- c("plot", "Abund.n", "d15N")
newdata.d15n <- my.traits[d15n]
trait<- na.omit(newdata.d15n)

A=aggregate(as.data.frame(trait$Abund.n),by=list(trait$plot),idfun)
colnames(A)[1]=c("site")

v.d15N=aggregate(as.data.frame(trait$d15N),by=list(trait$plot),idfun)
colnames(v.d15N)[1]=c("site")
groupc=merge(A,v.d15N,by=c("site"))

#cwm d15n
for (i in 1:nrr) {
  dataset [i,"CWV_d15N"] = sum((as.data.frame(groupc[i,"trait$Abund.n"])/sum(
                          as.data.frame(groupc[i,"trait$Abund.n"])))*(as.data.frame(groupc
                          [i,"trait$d15N"])-cwm[i,"CWM_d15N"])^2, na.rm=T)}



#ldmc

ldmc <- c("plot", "Abund.n", "LDMC")
newdata.ldmc <- my.traits[ldmc]
trait<- na.omit(newdata.ldmc)

A=aggregate(as.data.frame(trait$Abund.n),by=list(trait$plot),idfun)
colnames(A)[1]=c("site")

v.ldmc=aggregate(as.data.frame(trait$LDMC),by=list(trait$plot),idfun)
colnames(v.ldmc)[1]=c("site")
groupd=merge(A,v.ldmc,by=c("site"))

#cwm ldmc
for (i in 1:nrr) {
  dataset [i,"CWV_LDMC"] = sum((as.data.frame(groupd[i,"trait$Abund.n"])/sum(as.data.frame(
                            groupd[i,"trait$Abund.n"])))*(as.data.frame(groupd[i,"trait$LDMC"])
                            -cwm[i,"CWM_LDMC"])^2, na.rm=T)}


#cn

cnx <- c("plot", "Abund.n", "CN")
newdata.cn <- my.traits[cnx]
trait<- na.omit(newdata.cn)

A=aggregate(as.data.frame(trait$Abund.n),by=list(trait$plot),idfun)
colnames(A)[1]=c("site")

v.cn=aggregate(as.data.frame(trait$CN),by=list(trait$plot),idfun)
colnames(v.cn)[1]=c("site")
groupe=merge(A,v.cn,by=c("site"))

#cwv CN
for (i in 1:nrr) {
  dataset [i,"CWV_CN"] = sum((as.data.frame(groupe[i,"trait$Abund.n"])/sum(as.data.frame(
    groupe[i,"trait$Abund.n"])))*(as.data.frame(groupe[i,"trait$CN"])
                                  -cwm[i,"CWM_CN"])^2, na.rm=T)}


#lpc

lpc <- c("plot", "Abund.n", "LPC")
newdata.lpc <- my.traits[lpc]
trait<- na.omit(newdata.lpc)

A=aggregate(as.data.frame(trait$Abund.n),by=list(trait$plot),idfun)
colnames(A)[1]=c("site")

v.lpc=aggregate(as.data.frame(trait$LPC),by=list(trait$plot),idfun)
colnames(v.lpc)[1]=c("site")
groupf=merge(A,v.lpc,by=c("site"))

#lpc
for (i in 1:nrr) {
  dataset [i,"CWV_LPC"] = sum((as.data.frame(groupf[i,"trait$Abund.n"])/sum(as.data.frame(
                          groupf[i,"trait$Abund.n"])))*(as.data.frame(groupf[i,"trait$LPC"])
                          -cwm[i,"CWM_LPC"])^2, na.rm=T)}



#site names
dataset$site=groupf$site
dataset$age=groupa$age

A=aggregate(as.data.frame(my.traits$Abund.n),by=list(my.traits$plot),idfun)
colnames(A)[1]=c("site")

for (i in 1:nrr) {
  dataset[i,"abund"] = sum(as.data.frame(A[i,"my.traits$Abund.n"]))}



#Export to CSV
write.table(dataset, "FEBuzzard_CWV.csv", row.names=FALSE, sep=",")
