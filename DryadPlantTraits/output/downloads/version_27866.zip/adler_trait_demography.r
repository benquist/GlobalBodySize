# this script runs all the analyses, and produces all the tables and figures,
# for Adler et al. 2014 PNAS "Functional traits explain variation in plant life history strategies"

# start with empty slate
rm(list=ls())

# load libraries
library(ape)
library(nlme)
library(DirichletReg)
library(gtools) 

# 1. Import data ------------------------------------------------------------------------------

# import demography data
allD=read.csv("adler_demography.csv")
allD$species=as.character(allD$species)

# import TRY trait data (request these data from http://www.try-db.org)
tryD=read.csv("adler_TRY_data.csv")
allD=merge(allD,tryD)

# import phylogenetic data
pD=read.nexus("adler_phylogeny.nex")
pD$tip.label=gsub("_"," ",pD$tip.label) # replace underscore in spp name with space

# reorder allD species to match order of tree
allD=allD[match(pD$tip.label,allD$species),]
if(identical(allD$species, pD$tip.label)==F) stop("trait spp do not match phylo. species")


# 2. Dirichlet regressions ------------------------------------------------------------------


# look at distributions of traits
X11()
par(mfrow=c(5,2),tcl=-0.2)
hist(allD$SLA);  hist(log(allD$SLA))
hist(allD$SeedMass) ;  hist(log(allD$SeedMass))
hist(allD$WoodDens) ;  hist(log(allD$WoodDens))
hist(allD$LeafLife)  ;  hist(log(allD$LeafLife))
hist(allD$leafN)  ;  hist(log(allD$leafN)) 
# need to log transform all of them except Wood Density

# prevent infinity under logit transform of elasticities
lower=0.0000001; upper=0.99999999; 
allD$SurvivalE[allD$SurvivalE<lower]=lower; allD$SurvivalE[allD$SurvivalE>upper]=upper;
allD$GrowthTotE[allD$GrowthTotE<lower]=lower; allD$GrowthTotE[allD$GrowthTotE>upper]=upper;
allD$RecruitE[allD$RecruitE<lower]=lower; allD$RecruitE[allD$RecruitE>upper]=upper;

#rescale
tmp=rowSums(cbind(allD$SurvivalE,allD$GrowthTotE,allD$RecruitE))
allD$SurvivalE=allD$SurvivalE/tmp
allD$GrowthTotE=allD$GrowthTotE/tmp
allD$RecruitE=allD$RecruitE/tmp

# ternary plot of all points
EdatAll=DR_data(allD[,c("SurvivalE","GrowthTotE","RecruitE")])
plot(EdatAll,dim.labels=c("S","G","F"),
    a2d = list(colored =F, c.grid = F))

# define function to do dirichlet regression and make figure
doDReg=function(traitname,log.transform=T,xLabel,myLty){
  k=which(names(allD)==traitname)
  tmpD=subset(allD,!is.na(allD[,k]))
  Edat=DR_data(tmpD[,c("SurvivalE","GrowthTotE","RecruitE")])
  trait=tmpD[,k]
  if(log.transform==T) trait=log(trait)
  tmpD$trait=trait
  out=DirichReg(Edat~trait,tmpD)
  print(summary(out))

  if(log.transform==T) xLabel=paste("log(",xLabel,")",sep="")
  
  myCol=c("dodgerblue3","darkseagreen3","coral2")
  plot(rep(trait, 3), as.numeric(Edat), pch = 21, col="gray10",bg = rep(myCol, each = dim(tmpD)[1]), 
    xlab = xLabel, ylab = "",ylim = 0:1)
  mtext(side=2,"Elasticity",outer=T,line=0,cex=1.1)
  Xnew <- data.frame(trait = seq(min(trait), max(trait),
   length.out = dim(tmpD)[1]))
  Zscores=out$coeff/out$se
  for (i in 1:3) lines(cbind(Xnew, predict(out, Xnew)[, i]), 
    col = myCol[i], lty=myLty[i],lwd = 2) 
  
  return(out)
}

# start regressions here

#pdf("dirichlet_elast.pdf",width=7,height=6)
png("Fig1_dirichlet_elast.png",width=8,height=4.9,units="in",res=1200)
  par(mfrow=c(2,3),tcl=-0.2,mgp=c(2,0.5,0),mar=c(3,3,1,1),oma=c(1,2,0,0),
      cex=0.8,cex.lab=1.3,cex.axis=1.2)
  
  myCol=c("dodgerblue3","darkseagreen3","coral2")
  
  outSM=doDReg("SeedMass",log.transform=T,"Seed mass",myLty=c("solid","dotted","dotted"))
  
  outWD=doDReg("WoodDens",log.transform=F,"Wood density",myLty=c("dashed","dotted","dotted"))
  
  outLL=doDReg("LeafLife",log.transform=T,"Leaf life span",myLty=c("dashed","dotted","dotted"))
  
  outSLA=doDReg("SLA",log.transform=T,"SLA",myLty=c("dotted","dotted","solid"))
  
  outN=doDReg("leafN",log.transform=T,"Leaf N",myLty=c("dotted","dotted","solid"))
  
  plot(x=1,y=1,xlab="",ylab="",type="n",xaxt="n",yaxt="n",bty="n")
  
  legend("topleft",c("Survival","Growth","Fecundity"),pch=21,text.col="black",
      col="gray10",pt.bg=myCol,bty="n",cex=1.5)

dev.off()


# re-do leaf lifespan without P. nigra
png("FigS2_dirichlet_elast_LL_noPnigra.png",width=5,height=4,units="in",res=600)
  par(tcl=-0.2,mgp=c(2,0.5,0),mar=c(3,3,1,1),oma=c(1,2,0,0),
      cex=0.8,cex.lab=1.3,cex.axis=1.2)
  origAllD=allD
  allD=subset(allD,species!="Pinus nigra")
  outLL2=doDReg("LeafLife",log.transform=T,"Leaf life span",myLty=c("solid","dashed","dashed"))
  allD=origAllD
  legend("right",c("Survival","Growth","Fecundity"),pch=21,text.col="black",
      col="gray10",pt.bg=myCol,bty="n",cex=1.5)
dev.off()

# define function to save output
getSummary=function(model,trait){
  out=data.frame("Trait"=rep(trait,6),"Stage"=c("S","S","G","G","F","F"),
    "Parameter"=rep(c("Intercept","Slope"),3))
  out$coef=model$coeff
  out$se=model$se
  out$Z=out$coef/out$se
  out$p=2*(pnorm(-abs(out$Z)))
  out[,c("coef","se","Z","p")]=round(out[,c("coef","se","Z","p")],3)
  return(out)  
}

# write output to file
tmp=rbind(getSummary(outSM,"SeedMass"),
          getSummary(outWD,"WoodDens"),
          getSummary(outLL,"LeafLife"),
          getSummary(outSLA,"SLA"),
          getSummary(outN,"leafN")
  )
write.csv(tmp,"dirichlet_reg_summary.csv",row.names=F)

# do regressions with growth form as covariate

# function to do dirichlet regression with growth form covariate
doDReg.GF=function(traitname,log.transform=T){
  k=which(names(allD)==traitname)
  tmpD=subset(allD,!is.na(allD[,k]))
  Edat=DR_data(tmpD[,c("SurvivalE","GrowthTotE","RecruitE")])
  trait=tmpD[,k]
  if(log.transform==T) trait=log(trait)
  tmpD$trait=trait
  out=DirichReg(Edat~trait+growthForm,tmpD)
  print(table(tmpD$growthForm))
  print(summary(out))
  return(out)
}

outSMgf=doDReg.GF("SeedMass",log.transform=T)
outWDgf=doDReg.GF("WoodDens",log.transform=F)
outLLgf=doDReg.GF("LeafLife",log.transform=T)
outSLAgf=doDReg.GF("SLA",log.transform=T)
outNgf=doDReg.GF("leafN",log.transform=T)

#without P nigra
origAllD=allD
allD=subset(allD,species!="Pinus nigra")
outLLgf2=doDReg.GF("LeafLife",log.transform=T)
allD=origAllD

# define function to save output
getSummaryGF=function(model,trait){
  n=length(model$coeff)
  out=data.frame("Trait"=rep(trait,n),"Stage"=c(rep("S",n/3),rep("G",n/3),rep("F",n/3)),
    "Parameter"=model$coefnames)
  out$coef=model$coeff
  out$se=model$se
  out$Z=out$coef/out$se
  out$p=2*(pnorm(-abs(out$Z)))
  out[,c("coef","se","Z","p")]=round(out[,c("coef","se","Z","p")],3)
  return(out)  
}
# save output to file
tmp=rbind(getSummaryGF(outSMgf,"SeedMass"),
          getSummaryGF(outWDgf,"WoodDens"),
          getSummaryGF(outLLgf,"LeafLife"),
          getSummaryGF(outSLAgf,"SLA"),
          getSummaryGF(outNgf,"leafN"))

write.csv(tmp,"dirichlet_reg_summary_GF.csv",row.names=F)

# do regressions with ecoregion as covariate

doDReg.ER=function(traitname,log.transform=T){
  k=which(names(allD)==traitname)
  tmpD=subset(allD,!is.na(allD[,k]))
  Edat=DR_data(tmpD[,c("SurvivalE","GrowthTotE","RecruitE")])
  trait=tmpD[,k]
  if(log.transform==T) trait=log(trait)
  tmpD$trait=trait
  out=DirichReg(Edat~trait+ecoregion2,tmpD)
  print(table(tmpD$ecoregion2))
  print(summary(out))
  return(out)
}

outSMer=doDReg.ER("SeedMass",log.transform=T)
outSLAer=doDReg.ER("SLA",log.transform=T)
outLLer=doDReg.ER("LeafLife",log.transform=T) 
#outWDer=doDReg.ER("WoodDens",log.transform=F)  # did not converge, singleton ecoregions
origAllD=allD
allD=subset(allD,ecoregion2!="Desert")
outWDer=doDReg.ER("WoodDens",log.transform=F) # redo without the one desert species
allD=origAllD
outNer=doDReg.ER("leafN",log.transform=T)

# save output
tmp=rbind(getSummaryGF(outSMer,"SeedMass"),
          getSummaryGF(outWDer,"WoodDens"),
          getSummaryGF(outLLer,"LeafLife"),
          getSummaryGF(outSLAer,"SLA"),
          getSummaryGF(outNer,"leafN"))
write.csv(tmp,"dirichlet_reg_summary_ER.csv",row.names=F)

# print leaf life span results WITH P nigra
sink(file="Dirich_Elast_woPnigra.txt")
summary(outLL2)
summary(outLLgf2)
sink()

# try seed mass and SLA together
drop=which(is.na(allD$SeedMass) | is.na(allD$SLA))
tmpD=allD[-drop,]
Edat=DR_data(tmpD[,c("SurvivalE","GrowthTotE","RecruitE")])
out1=DirichReg(Edat~log(SeedMass),tmpD)
out2=DirichReg(Edat~log(SLA),tmpD)
out3=DirichReg(Edat~log(SeedMass)+log(SLA),tmpD)


# 3. PGLS regressions--Elasticities --------------------------------------------------------


# logit transformation of scaled elasticities
allD$logitSurvE=logit(allD$SurvivalE)
allD$logitRecrE=logit(allD$RecruitE)
allD$logitGrowE=logit(allD$GrowthTotE)

# look at elasticity correlations
pairs(allD[,c("SurvivalE","GrowthTotE","RecruitE")])

# function to do phylogenetic gls
pgls.wrapper=function(response,trait,GF=F){
  drop=which(is.na(trait))
  tmpD=data.frame(species=allD$species[-drop],response=response[-drop],
        trait=trait[-drop], GF=allD$growthForm[-drop])
  row.names(tmpD)=tmpD$species
  tmp.pD=drop.tip(pD,drop)
  bm=corBrownian(phy=tmp.pD) # Brownian motion correlation matrix
  if(GF==F){
    out=gls(response~trait,data=tmpD,correlation=bm)
  }else{
    out=gls(response~trait+GF,data=tmpD,correlation=bm)
  }
  return(out)
} 
 
# function to do phylogenetic gls with O-U correlation
pgls.wrapper.ou=function(response,trait,alpha){
  drop=which(is.na(trait))
  tmpD=data.frame(species=allD$species[-drop],response=response[-drop],
        trait=trait[-drop], GF=allD$growthForm[-drop])
  row.names(tmpD)=tmpD$species
  tmp.pD=drop.tip(pD,drop)
  ou=corMartins(alpha,phy=tmp.pD,fixed=T) 
  out=gls(response~trait,data=tmpD,correlation=ou)
  return(out)
} 

# start regressions

lgs=list() # list to store model objects
 
#SEED MASS
out=pgls.wrapper(allD$logitSurvE,log(allD$SeedMass))
lgs$SM.Surv=out

out=pgls.wrapper(allD$logitGrowE,log(allD$SeedMass))
lgs$SM.Grow=out

out=pgls.wrapper(allD$logitRecrE,log(allD$SeedMass))
lgs$SM.Recr=out


#WoodDens
out=pgls.wrapper(allD$logitSurvE,allD$WoodDens)
lgs$WD.Surv=out

out=pgls.wrapper(allD$logitGrowE,allD$WoodDens)
lgs$WD.Grow=out

out=pgls.wrapper(allD$logitRecrE,allD$WoodDens)
lgs$WD.Recr=out


#LeafLife
out=pgls.wrapper(allD$logitSurvE,log(allD$LeafLife))
lgs$LL.Surv=out

out=pgls.wrapper(allD$logitGrowE,log(allD$LeafLife))
lgs$LL.Grow=out

out=pgls.wrapper(allD$logitRecrE,log(allD$LeafLife))
lgs$LL.Recr=out

# no P nigra
#origAllD=allD; origPD=pD
#pD=drop.tip(pD,"Pinus nigra")
#allD=subset(allD,species!="Pinus nigra")
#LL.Surv2=pgls.wrapper(allD$logitSurvE,log(allD$LeafLife))
#LL.Grow2=pgls.wrapper(allD$logitGrowE,log(allD$LeafLife))
#LL.Recr2=pgls.wrapper(allD$logitRecrE,log(allD$LeafLife))
#allD=origAllD; pD=origPD

#SLA
out=pgls.wrapper(allD$logitSurvE,log(allD$SLA))
lgs$SLA.Surv=out

out=pgls.wrapper(allD$logitGrowE,log(allD$SLA))
lgs$SLA.Grow=out

out=pgls.wrapper(allD$logitRecrE,log(allD$SLA))
lgs$SLA.Recr=out

#Leaf  N
out=pgls.wrapper(allD$logitSurvE,log(allD$leafN))
lgs$LN.Surv=out

out=pgls.wrapper(allD$logitGrowE,log(allD$leafN))
lgs$LN.Grow=out

out=pgls.wrapper(allD$logitRecrE,log(allD$leafN))
lgs$LN.Recr=out

# look at some R2 values using simple linear models
# focus on trait0elasticity relationships significant in Dirichlet regressions
print(summary(lm(allD$logitSurvE~log(allD$SeedMass)))) # R2=0.24
print(summary(lm(allD$logitSurvE~log(allD$LeafLife)))) # R2=0.29
print(summary(lm(allD$logitSurvE~allD$WoodDens))) # R2=0.08
print(summary(lm(allD$logitSurvE~log(allD$SLA)))) # R2=0.11
print(summary(lm(allD$logitRecrE~log(allD$SLA)))) # R2=0.05
print(summary(lm(allD$logitRecrE~log(allD$leafN)))) # R2=0.06
              
  
##table summarizing coefficients and p-values from glms                  
coefs=matrix(NA,length(lgs),5)
for(i in 1:length(lgs))
{
  coefs[i,1]=summary(lgs[[i]])$dims$N
  coefs[i,2:3]=as.numeric(coef(summary(lgs[[i]])))
  coefs[i,4]=as.numeric(summary(lgs[[i]])$tTable[2,3])
  coefs[i,5]=as.numeric(summary(lgs[[i]])$tTable[2,4])
}
coefs=as.data.frame(coefs)
names(coefs)=c("N","Intercept", "TraitParameter","Trait-t-value","pvalue")
row.names(coefs)=names(lgs)
write.csv(coefs, "pgls_elasticities.csv")
 
# add growthForm to models-------
GFlgs=list()

#SEED MASS
out=pgls.wrapper(allD$logitSurvE,log(allD$SeedMass),GF=T)
GFlgs$SM.Surv=out

out=pgls.wrapper(allD$logitGrowE,log(allD$SeedMass),GF=T)
GFlgs$SM.Grow=out

out=pgls.wrapper(allD$logitRecrE,log(allD$SeedMass),GF=T)
GFlgs$SM.Recr=out

#WoodDens
out=pgls.wrapper(allD$logitSurvE,allD$WoodDens,GF=T)
GFlgs$WD.Surv=out

out=pgls.wrapper(allD$logitGrowE,allD$WoodDens,GF=T)
GFlgs$WD.Grow=out

out=pgls.wrapper(allD$logitRecrE,allD$WoodDens,GF=T)
GFlgs$WD.Recr=out

#LeafLife            
out=pgls.wrapper(allD$logitSurvE,log(allD$LeafLife),GF=T)
GFlgs$LL.Surv=out

out=pgls.wrapper(allD$logitGrowE,log(allD$LeafLife),GF=T)
GFlgs$LL.Grow=out

out=pgls.wrapper(allD$logitRecrE,log(allD$LeafLife),GF=T)
GFlgs$LL.Recr=out
            

#SLA
out=pgls.wrapper(allD$logitSurvE,log(allD$SLA),GF=T)
GFlgs$SLA.Surv=out

out=pgls.wrapper(allD$logitGrowE,log(allD$SLA),GF=T)
GFlgs$SLA.Grow=out

out=pgls.wrapper(allD$logitRecrE,log(allD$SLA),GF=T)
GFlgs$SLA.Recr=out


#Leaf  N
out=pgls.wrapper(allD$logitSurvE,log(allD$leafN),GF=T)
GFlgs$LN.Surv=out

out=pgls.wrapper(allD$logitGrowE,log(allD$leafN),GF=T)
GFlgs$LN.Grow=out

out=pgls.wrapper(allD$logitRecrE,log(allD$leafN),GF=T)
GFlgs$LN.Recr=out


##table summarizing coefficients and p-values from glms                  
coefsGF=matrix(NA,length(GFlgs),5)
for(i in 1:length(GFlgs))
{
  coefsGF[i,1]=summary(GFlgs[[i]])$dims$N
  coefsGF[i,2:3]=as.numeric(coef(summary(GFlgs[[i]]))[1:2])
  coefsGF[i,4]=as.numeric(summary(GFlgs[[i]])$tTable[2,3])
  coefsGF[i,5]=as.numeric(summary(GFlgs[[i]])$tTable[2,4])
}
coefsGF=as.data.frame(coefsGF)
names(coefsGF)=c("N","Intercept", "TraitParameter","Trait-t-value","pvalue")
row.names(coefsGF)=names(GFlgs)
write.csv(coefsGF, "pgls_elasticities_GF.csv")
 

# add ecoregion to models ---------- 

# function to do phylogenetic gls
pgls.wrapper.ecoReg=function(response,trait){
  drop=which(is.na(trait))
  tmpD=data.frame(species=allD$species[-drop],response=response[-drop],
        trait=trait[-drop], ecoReg=allD$ecoregion2[-drop])
  row.names(tmpD)=tmpD$species
  tmp.pD=drop.tip(pD,drop)
  bm=corBrownian(phy=tmp.pD) # Brownian motion correlation matrix
  out=gls(response~trait+ecoReg,data=tmpD,correlation=bm)
  return(out)
} 

ERlgs=list()

#SEED MASS
out=pgls.wrapper.ecoReg(allD$logitSurvE,log(allD$SeedMass))
ERlgs$SM.Surv=out

out=pgls.wrapper.ecoReg(allD$logitGrowE,log(allD$SeedMass))
ERlgs$SM.Grow=out

out=pgls.wrapper.ecoReg(allD$logitRecrE,log(allD$SeedMass))
ERlgs$SM.Recr=out

#WoodDens
out=pgls.wrapper.ecoReg(allD$logitSurvE,allD$WoodDens)
ERlgs$WD.Surv=out

out=pgls.wrapper.ecoReg(allD$logitGrowE,allD$WoodDens)
ERlgs$WD.Grow=out

out=pgls.wrapper.ecoReg(allD$logitRecrE,allD$WoodDens)
ERlgs$WD.Recr=out

#LeafLife
 
out=pgls.wrapper.ecoReg(allD$logitSurvE,log(allD$LeafLife))
ERlgs$LL.Surv=out

out=pgls.wrapper.ecoReg(allD$logitGrowE,log(allD$LeafLife))
ERlgs$LL.Grow=out

out=pgls.wrapper.ecoReg(allD$logitRecrE,log(allD$LeafLife))
ERlgs$LL.Recr=out
              
#SLA
out=pgls.wrapper.ecoReg(allD$logitSurvE,log(allD$SLA))
ERlgs$SLA.Surv=out

out=pgls.wrapper.ecoReg(allD$logitGrowE,log(allD$SLA))
ERlgs$SLA.Grow=out

out=pgls.wrapper.ecoReg(allD$logitRecrE,log(allD$SLA))
ERlgs$SLA.Recr=out

#Leaf  N
out=pgls.wrapper.ecoReg(allD$logitSurvE,log(allD$leafN))
ERlgs$LN.Surv=out

out=pgls.wrapper.ecoReg(allD$logitGrowE,log(allD$leafN))
ERlgs$LN.Grow=out

out=pgls.wrapper.ecoReg(allD$logitRecrE,log(allD$leafN))
ERlgs$LN.Recr=out


##table summarizing coefficients and p-values from glms                  
coefsER=matrix(NA,length(ERlgs),5)
for(i in 1:length(ERlgs))
{
  coefsER[i,1]=summary(ERlgs[[i]])$dims$N
  coefsER[i,2:3]=as.numeric(coef(summary(ERlgs[[i]]))[1:2])
  coefsER[i,4]=as.numeric(summary(ERlgs[[i]])$tTable[2,3])
  coefsER[i,5]=as.numeric(summary(ERlgs[[i]])$tTable[2,4])
}
coefsER=as.data.frame(coefsER)
names(coefsER)=c("N","Intercept", "TraitParameter","Trait-t-value","pvalue")
row.names(coefsER)=names(ERlgs)
write.csv(coefsER, "pgls_elasticities_ER.csv")

# write full regression summary outputs
for(i in 1:length(GFlgs)){
  if(i==1){
    out=as.data.frame(summary(GFlgs[[i]])$tTable)
    out$Parameter=row.names(out)
    out$trait=names(GFlgs)[i]
  }else{
    tmp=as.data.frame(summary(GFlgs[[i]])$tTable)
    tmp$trait=names(GFlgs)[i]
    tmp$Parameter=row.names(tmp)
    out=rbind(out,tmp)
  } 
}
out=out[,c(6,5,1:4)]
write.csv(out,"pgls_elastGF_reg_summaries.csv",row.names=F)

# write full regression summary outputs
for(i in 1:length(ERlgs)){
  if(i==1){
    out=as.data.frame(summary(ERlgs[[i]])$tTable)
    out$Parameter=row.names(out)
    out$trait=names(ERlgs)[i]
  }else{
    tmp=as.data.frame(summary(ERlgs[[i]])$tTable)
    tmp$trait=names(ERlgs)[i]
    tmp$Parameter=row.names(tmp)
    out=rbind(out,tmp)
  } 
}
out=out[,c(6,5,1:4)]
write.csv(out,"pgls_elastER_reg_summaries.csv",row.names=F)

# try seed mass and SLA together
drop=which(is.na(allD$SeedMass) | is.na(allD$SLA))
tmpD=allD[-drop,]
row.names(tmpD)=tmpD$species
tmp.pD=drop.tip(pD,drop)
bm=corBrownian(phy=tmp.pD) # Brownian motion correlation matrix
out1=gls(logitSurvE~log(SeedMass),data=tmpD,correlation=bm)
out2=gls(logitSurvE~log(SLA),data=tmpD,correlation=bm)
out3=gls(logitSurvE~log(SeedMass)+log(SLA),data=tmpD,correlation=bm)

# and seed mass and SLA with simple linear models
summary(lm(logitSurvE~log(SLA),data=tmpD))
summary(lm(logitSurvE~log(SeedMass),data=tmpD))
summary(lm(logitSurvE~log(SeedMass)+log(SLA),data=tmpD))

lgsE=lgs # rename list containing elasticity PGLS models

# 4. PGLS regressions--vital rates ----------------------------------------------------

#look at distributions of vital rates
par(mfrow=c(3,2),mgp=c(2,0.5,0),tcl=-0.2)
hist(allD$SurvivalV);  hist(logit(allD$SurvivalV))     # logit looks good
hist(allD$GrowthTotV) ;  hist(log(allD$GrowthTotV+0.001)) #log not so bad
hist(allD$RecruitV) ;  hist(log(allD$RecruitV+0.001))    #log pretty good 

# set up transformed RecruitV variable
tmp=min(allD$RecruitV[allD$RecruitV>0])
allD$logRecV=log(allD$RecruitV+tmp/2) # remove 0's (~8 records)
 
# set up transformed GrowthTotV variable
tmp=min(allD$GrowthTotV[allD$GrowthTotV>0])
allD$logGroTotV=log(allD$GrowthTotV+tmp/2)

# set up transformed SurvivalV variable
allD$logitSurvV=logit(allD$SurvivalV)

# define function to do phylogenetic gls
pgls.wrapper=function(response,trait,GF=F){
  drop=which(is.na(trait))
  tmpD=data.frame(species=allD$species[-drop],response=response[-drop],
        trait=trait[-drop], GF=allD$growthForm[-drop])
  row.names(tmpD)=tmpD$species
  tmp.pD=drop.tip(pD,drop)
  bm=corBrownian(phy=tmp.pD) # Brownian motion correlation matrix
  if(GF==F){
    out=gls(response~trait,data=tmpD,correlation=bm)
  }else{
    out=gls(response~trait+GF,data=tmpD,correlation=bm)
  }
  return(out)
} 

# function to do phylogenetic gls with ecoregion
pgls.wrapper.er=function(response,trait){
  drop=which(is.na(trait))
  tmpD=data.frame(species=allD$species[-drop],response=response[-drop],
        trait=trait[-drop], ER=allD$ecoregion2[-drop])
  row.names(tmpD)=tmpD$species
  tmp.pD=drop.tip(pD,drop)
  bm=corBrownian(phy=tmp.pD) # Brownian motion correlation matrix
  out=gls(response~trait+ER,data=tmpD,correlation=bm)
  return(out)
} 

# Raw vital rate regressions
 
lgs=lgsGF=lgsER=list()
 
#SEED MASS
out=pgls.wrapper(allD$logitSurvV,log(allD$SeedMass))
lgs$SM.SurvV=out

out=pgls.wrapper(allD$logGroTotV,log(allD$SeedMass))
lgs$SM.GrowV=out

out=pgls.wrapper(allD$logRecV,log(allD$SeedMass))
lgs$SM.RecruitV=out
 
out=pgls.wrapper(allD$logitSurvV,log(allD$SeedMass),GF=T)
lgsGF$SM.SurvV=out

out=pgls.wrapper(allD$logGroTotV,log(allD$SeedMass),GF=T)
lgsGF$SM.GrowV=out

out=pgls.wrapper(allD$logRecV,log(allD$SeedMass),GF=T)
lgsGF$SM.RecruitV=out

out=pgls.wrapper.er(allD$logitSurvV,log(allD$SeedMass))
lgsER$SM.SurvV=out

out=pgls.wrapper.er(allD$logGroTotV,log(allD$SeedMass))
lgsER$SM.GrowV=out

out=pgls.wrapper.er(allD$logRecV,log(allD$SeedMass))
lgsER$SM.RecruitV=out

#WoodDens
out=pgls.wrapper(allD$logitSurvV,allD$WoodDens)
lgs$WD.SurvV=out

out=pgls.wrapper(allD$logGroTotV,allD$WoodDens)
lgs$WD.GrowV=out

out=pgls.wrapper(allD$logRecV,allD$WoodDens)
lgs$WD.RecruitV=out
 
out=pgls.wrapper(allD$logitSurvV,allD$WoodDens,GF=T)
lgsGF$WD.SurvV=out

out=pgls.wrapper(allD$logGroTotV,allD$WoodDens,GF=T)
lgsGF$WD.GrowV=out

out=pgls.wrapper(allD$logRecV,allD$WoodDens,GF=T)
lgsGF$WD.RecruitV=out

out=pgls.wrapper.er(allD$logitSurvV,allD$WoodDens)
lgsER$WD.SurvV=out

out=pgls.wrapper.er(allD$logGroTotV,allD$WoodDens)
lgsER$WD.GrowV=out

out=pgls.wrapper.er(allD$logRecV,allD$WoodDens)
lgsER$WD.RecruitV=out

#LeafLife
out=pgls.wrapper(allD$logitSurvV,log(allD$LeafLife))
lgs$LL.SurvV=out

out=pgls.wrapper(allD$logGroTotV,log(allD$LeafLife))
lgs$LL.GrowV=out

out=pgls.wrapper(allD$logRecV,log(allD$LeafLife))
lgs$LL.RecruitV=out
 
out=pgls.wrapper(allD$logitSurvV,log(allD$LeafLife),GF=T)
lgsGF$LL.SurvV=out

out=pgls.wrapper(allD$logGroTotV,log(allD$LeafLife),GF=T)
lgsGF$LL.GrowV=out

out=pgls.wrapper(allD$logRecV,log(allD$LeafLife),GF=T)
lgsGF$LL.RecruitV=out

out=pgls.wrapper.er(allD$logitSurvV,log(allD$LeafLife))
lgsER$LL.SurvV=out

out=pgls.wrapper.er(allD$logGroTotV,log(allD$LeafLife))
lgsER$LL.GrowV=out

out=pgls.wrapper.er(allD$logRecV,log(allD$LeafLife))
lgsER$LL.RecruitV=out

#SLA
out=pgls.wrapper(allD$logitSurvV,log(allD$SLA))
lgs$SLA.SurvV=out

out=pgls.wrapper(allD$logGroTotV,log(allD$SLA))
lgs$SLA.GrowV=out

out=pgls.wrapper(allD$logRecV,log(allD$SLA))
lgs$SLA.RecruitV=out
 
out=pgls.wrapper(allD$logitSurvV,log(allD$SLA),GF=T)
lgsGF$SLA.SurvV=out

out=pgls.wrapper(allD$logGroTotV,log(allD$SLA),GF=T)
lgsGF$SLA.GrowV=out

out=pgls.wrapper(allD$logRecV,log(allD$SLA),GF=T)
lgsGF$SLA.RecruitV=out

out=pgls.wrapper.er(allD$logitSurvV,log(allD$SLA))
lgsER$SLA.SurvV=out

out=pgls.wrapper.er(allD$logGroTotV,log(allD$SLA))
lgsER$SLA.GrowV=out

out=pgls.wrapper.er(allD$logRecV,log(allD$SLA))
lgsER$SLA.RecruitV=out
 
#Leaf N
out=pgls.wrapper(allD$logitSurvV,log(allD$leafN))
lgs$LN.SurvV=out

out=pgls.wrapper(allD$logGroTotV,log(allD$leafN))
lgs$LN.GrowV=out

out=pgls.wrapper(allD$logRecV,log(allD$leafN))
lgs$LN.RecruitV=out
 
out=pgls.wrapper(allD$logitSurvV,log(allD$leafN),GF=T)
lgsGF$LN.SurvV=out

out=pgls.wrapper(allD$logGroTotV,log(allD$leafN),GF=T)
lgsGF$LN.GrowV=out

out=pgls.wrapper(allD$logRecV,log(allD$leafN),GF=T)
lgsGF$LN.RecruitV=out

out=pgls.wrapper.er(allD$logitSurvV,log(allD$leafN))
lgsER$LN.SurvV=out

out=pgls.wrapper.er(allD$logGroTotV,log(allD$leafN))
lgsER$LN.GrowV=out

out=pgls.wrapper.er(allD$logRecV,log(allD$leafN))
lgsER$LN.RecruitV=out



##table summarizing coefficients and p-values from glms                  
coefsVR=matrix(NA,length(lgs),5)
for(i in 1:length(lgs))
{
  coefsVR[i,1]=summary(lgs[[i]])$dims$N
  coefsVR[i,2:3]=as.numeric(coef(summary(lgs[[i]])))
  coefsVR[i,4]=as.numeric(summary(lgs[[i]])$tTable[2,3])
  coefsVR[i,5]=as.numeric(summary(lgs[[i]])$tTable[2,4])
}
coefsVR=as.data.frame(coefsVR)
names(coefsVR)=c("N","Intercept", "TraitParameter","Trait-t-value","pvalue")
row.names(coefsVR)=names(lgs)
write.csv(coefsVR, "pgls_vitalRates.csv")
 
##table summarizing coefficients and p-values from glms that include growthForm                  
coefsGF=matrix(NA,length(lgsGF),5)
for(i in 1:length(lgsGF))
{
  coefsGF[i,1]=summary(lgsGF[[i]])$dims$N
  coefsGF[i,2:3]=as.numeric(coef(summary(lgsGF[[i]]))[1:2])
  coefsGF[i,4]=as.numeric(summary(lgsGF[[i]])$tTable[2,3])
  coefsGF[i,5]=as.numeric(summary(lgsGF[[i]])$tTable[2,4])
}
coefsGF=as.data.frame(coefsGF)
names(coefsGF)=c("N","Intercept", "TraitParameter","Trait-t-value","pvalue")
row.names(coefsGF)=names(lgsGF)
write.csv(coefsGF, "pgls_vitalRates_GrForm.csv")

##table summarizing coefficients and p-values from glms that include ecoregion                  
coefsER=matrix(NA,length(lgsER),5)
for(i in 1:length(lgsER))
{
  coefsER[i,1]=summary(lgsER[[i]])$dims$N
  coefsER[i,2:3]=as.numeric(coef(summary(lgsER[[i]]))[1:2])
  coefsER[i,4]=as.numeric(summary(lgsER[[i]])$tTable[2,3])
  coefsER[i,5]=as.numeric(summary(lgsER[[i]])$tTable[2,4])
}
coefsER=as.data.frame(coefsER)
names(coefsER)=c("N","Intercept", "TraitParameter","Trait-t-value","pvalue")
row.names(coefsER)=names(lgsER)
write.csv(coefsER, "pgls_vitalRates_ER.csv")

# write full regression summary outputs
for(i in 1:length(lgsER)){
  if(i==1){
    out=as.data.frame(summary(lgsER[[i]])$tTable)
    out$Parameter=row.names(out)
    out$trait=names(lgsER)[i]
  }else{
    tmp=as.data.frame(summary(lgsER[[i]])$tTable)
    tmp$trait=names(lgsER)[i]
    tmp$Parameter=row.names(tmp)
    out=rbind(out,tmp)
  } 
}
out=out[,c(6,5,1:4)]
write.csv(out,"pgls_vitalRateER_reg_summaries.csv",row.names=F)

# write full regression summary outputs
for(i in 1:length(lgsGF)){
  if(i==1){
    out=as.data.frame(summary(lgsGF[[i]])$tTable)
    out$Parameter=row.names(out)
    out$trait=names(lgsGF)[i]
  }else{
    tmp=as.data.frame(summary(lgsGF[[i]])$tTable)
    tmp$trait=names(lgsGF)[i]
    tmp$Parameter=row.names(tmp)
    out=rbind(out,tmp)
  } 
}
out=out[,c(6,5,1:4)]
write.csv(out,"pgls_vitalRateGF_reg_summaries.csv",row.names=F)

lgsV=lgs # rename list containing vital rate PGLS models


# 5. Make tables --------------------------------------------------------------------------

# function to convert p values to symbols
p2symbol=function(p){
  if(p<0.001){
    tmp="***"
  }else if(p<0.01){
    tmp="**"
  }else if(p<0.05){
    tmp="*"
  }else if(p<0.1){
    tmp="+"
  }else{
    tmp="ns"
  }
  return(tmp)
}

# Elasticities and traits

# Dirichlet regression
tabD=read.csv("dirichlet_reg_summary.csv")
tabD=subset(tabD,Parameter=="Slope")
tabD=tabD[,c("Stage","Trait","Z","p")]
tmp=read.csv("dirichlet_reg_summary_GF.csv")
tmp=subset(tmp,Parameter=="trait")
tabD=cbind(tabD,tmp[,c("Z","p")])
tmp=read.csv("dirichlet_reg_summary_ER.csv")
tmp=subset(tmp,Parameter=="trait")
tmp=tmp[,c("Z","p")] 
tabD=cbind(tabD,tmp)

# add PGLS
tmp=read.csv("pgls_elasticities.csv")
tabD=cbind(tmp$N,tabD,round(tmp[,c(5:6)],3))
tmp=read.csv("pgls_elasticities_GF.csv")
tabD=cbind(tabD,round(tmp[,c(5:6)],3))
tmp=read.csv("pgls_elasticities_ER.csv")
tabD=cbind(tabD,round(tmp[,c(5:6)],3))

# convert p values to symbols
names(tabD)[1]="N"
colList=grep("p",names(tabD))
for(i in colList){
  myP=tabD[,i]
  tabD[,i]="char"
  for(j in 1:dim(tabD)[1]){
    if(!is.na(myP[j])){
      tabD[j,i]=p2symbol(myP[j])
    }else{
      tabD[j,i]=NA
    }
  }
}
write.csv(tabD,"Table1_Elast&TraitStats.csv",row.names=F)

# vital rates and traits 

tabD=read.csv("pgls_vitalRates.csv")
tabD=tabD[,-c(3:4)]  
tmp=read.csv("pgls_vitalRates_GrForm.csv")
tmp=tmp[,c(5:6)]
tabD=cbind(tabD,tmp)
tmp=read.csv("pgls_vitalRates_ER.csv")
tmp=tmp[,c(5:6)]
tabD=cbind(tabD,tmp)
tabD[,c(3:NCOL(tabD))]=round(tabD[,c(3:NCOL(tabD))],3)

# convert p values to symbols
colList=grep("p",names(tabD))
for(i in colList){
  myP=tabD[,i]
  tabD[,i]="char"
  for(j in 1:dim(tabD)[1]){
    if(!is.na(myP[j])){
      tabD[j,i]=p2symbol(myP[j])
    }else{
      tabD[j,i]=NA
    }
  }
}

write.csv(tabD,"Table2_VitalRates&TraitStats.csv",row.names=F)


# 6. Additional figures --------------------------------------------------------------------

myLegend=c("Herb. perennial", "Palm", "Shrub","Succulent","Tree")

# set up symbols and colors
colorKey=data.frame(growthForm=sort(unique(allD$growthForm)),
      colors=c("dodgerblue3","cyan","orange","limegreen","red3"),symbols=1:5,symbols2=21:25)
colorKey$colors=as.character(colorKey$colors)
allD=merge(allD,colorKey,all.x=T)

#function to plot logistic regression lines
plotLGS=function(x,model,myLine="solid"){
  xx=seq(min(x,na.rm=T),max(x,na.rm=T),0.1)
  yy=inv.logit(coef(model)[1]+coef(model)[2]*xx)
  lines(xx,yy,lty=myLine,lwd=1.5)
}

# function to plot linear regression lines
plotLine=function(x,model,myLine="solid"){
  xx=seq(min(x,na.rm=T),max(x,na.rm=T),0.1)
  yy=coef(model)[1]+coef(model)[2]*xx
  lines(xx,yy,lty=myLine,lwd=1.5)
}

#Survival elasticity figure 

png("FigS1_ElasticitiesPGLS.png",height=10,width=7.5,units="in",res=450)
  par(mfrow=c(5,3),mgp=c(2,0.5,0),tcl=-0.2,mar=c(3,3.5,1,1),oma=c(1,0.5,0,0),cex.axis=1,cex.lab=1.3)
  
  # seed mass
  
  plot(log(allD$SeedMass),allD$SurvivalE,xlab="",ylab=expression(italic(E[survival])),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="SM.Surv"),5])<0.05){
    plotLGS(log(allD$SeedMass),lgsE$SM.Surv)
  }
  
  plot(log(allD$SeedMass),allD$GrowthTotE,xlab="log(Seed mass)",ylab=expression(italic(E[growth])),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="SM.Grow"),5])<0.05){
    plotLGS(log(allD$SeedMass),lgsE$SM.Grow)
  }
  
  plot(log(allD$SeedMass),allD$RecruitE,xlab="",ylab=expression(italic(E[fecundity])),ylim=c(0,1),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="SM.Recr"),5])<0.05){
    plotLGS(log(allD$SeedMass),lgsE$SM.Recr)
  }
  
  # Wood Density
  
  plot(allD$WoodDens,allD$SurvivalE,xlab="",ylab=expression(italic(E[survival])),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="WD.Surv"),5])<0.05){
    plotLGS(allD$WoodDens,lgsE$WD.Surv,myLine="solid") # not sign. with growthForm in model
  } 
  
  plot(allD$WoodDens,allD$GrowthTotE,xlab="Wood density",ylab=expression(italic(E[growth])),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="WD.Grow"),5])<0.05){
    plotLGS(allD$WoodDens,lgsE$WD.Grow,"solid")
  }
  
  plot(allD$WoodDens,allD$RecruitE,xlab="",ylab=expression(italic(E[fecundity])),ylim=c(0,1),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="WD.Recr"),5])<0.05){
    plotLGS(allD$WoodDens,lgsE$WD.Recr,"solid")
  }
  
  # leaf lifespan
  
  plot(log(allD$LeafLife),allD$SurvivalE,xlab="",ylab=expression(italic(E[survival])),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="LL.Surv"),5])<0.05){
    plotLGS(log(allD$LeafLife),lgsE$LL.Surv)
  } 
  
  plot(log(allD$LeafLife),allD$GrowthTotE,xlab="log(Leaf lifespan)",ylab=expression(italic(E[growth])),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="LL.Grow"),5])<0.05){
    plotLGS(log(allD$LeafLife),lgsE$LL.Grow)
  }
  
  plot(log(allD$LeafLife),allD$RecruitE,xlab="",ylab=expression(italic(E[fecundity])),ylim=c(0,1),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  
 legend("topright",myLegend, pch=colorKey$symbols2,
        col="gray10",pt.bg=colorKey$colors,text.col="black",bg="transparent",bty="n",cex=1)  
  if(abs(coefs[which(rownames(coefs)=="LL.Recr"),5])<0.05){
    plotLGS(log(allD$LeafLife),lgsE$LL.Recr)
  }
  
  # SLA
  
  plot(log(allD$SLA),allD$SurvivalE,xlab="",ylab=expression(italic(E[survival])),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="SLA.Surv"),5])<0.05){
    plotLGS(log(allD$SLA),lgsE$SLA.Surv)
  } 
  
  plot(log(allD$SLA),allD$GrowthTotE,xlab="log(SLA)",ylab=expression(italic(E[growth])),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="SLA.Grow"),5])<0.05){
    plotLGS(log(allD$SLA),lgsE$SLA.Grow,"dashed")
  }
  
  plot(log(allD$SLA),allD$RecruitE,xlab="",ylab=expression(italic(E[fecundity])),ylim=c(0,1),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="SLA.Recr"),5])<0.05){
    plotLGS(log(allD$SLA),lgsE$SLA.Recr)
  }
  
  # leaf N
  
  plot(log(allD$leafN),allD$SurvivalE,xlab="",ylab=expression(italic(E[survival])),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="LN.Surv"),5])<0.05){
    plotLGS(log(allD$leafN),lgsE$LN.Surv)
  } 
  
  plot(log(allD$leafN),allD$GrowthTotE,xlab="log(Leaf N)",ylab=expression(italic(E[growth])),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="LN.Grow"),5])<0.05){
    plotLGS(log(allD$leafN),lgsE$LN.Grow)
  }
  
  plot(log(allD$leafN),allD$RecruitE,xlab="",ylab=expression(italic(E[fecundity])),ylim=c(0,1),col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefs[which(rownames(coefs)=="LN.Recr"),5])<0.05){
    plotLGS(log(allD$leafN),lgsE$LN.Recr,"solid")
  }

dev.off()


# Vital rates figure 

png("FigS3_VitalRates.png",height=10,width=7.5,units="in",res=450)
  par(mfrow=c(5,3),mgp=c(2,0.5,0),tcl=-0.2,mar=c(3,3,1,1),oma=c(1,1,0,0),cex.axis=1,cex.lab=1.3)
  
  # seed mass
  plot(log(allD$SeedMass),allD$SurvivalV,xlab="",ylab="Survival",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="SM.SurvV"),5])<0.05){
    plotLGS(log(allD$SeedMass),lgsV$SM.SurvV)
  } 
  plot(log(allD$SeedMass),log(allD$GrowthTotV),xlab="log(Seed mass)",ylab="log(Growth)",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="SM.GrowV"),5])<0.05){
    plotLine(log(allD$SeedMass),lgsV$SM.GrowV)
  } 
  plot(log(allD$SeedMass),allD$logRecV,xlab="",ylab="log(Fecundity)",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="SM.RecruitV"),5])<0.05){
    plotLine(log(allD$SeedMass),lgsV$SM.RecruitV)
  } 
  
  # wood density
  plot(allD$WoodDens,allD$SurvivalV,xlab="",ylab="Survival",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="WD.SurvV"),5])<0.05){
    plotLGS(allD$WoodDens,lgsV$WD.SurvV)
  } 
  plot(allD$WoodDens,log(allD$GrowthTotV),xlab="Wood density",ylab="log(Growth)",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="WD.GrowV"),5])<0.05){
    plotLine(allD$WoodDens,lgsV$WD.GrowV)
  } 
  plot(allD$WoodDens,allD$logRecV,xlab="",ylab="log(Fecundity)",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="WD.RecruitV"),5])<0.05){
    plotLine(allD$WoodDens,lgsV$WD.RecruitV)
  } 
  
  # leaf lifespan
  plot(log(allD$LeafLife),allD$SurvivalV,xlab="",ylab="Survival",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="LL.SurvV"),5])<0.05){
    plotLGS(log(allD$LeafLife),lgsV$LL.SurvV)
  } 
  legend("bottomright",myLegend, pch=colorKey$symbols2,
      col="gray10",pt.bg=colorKey$colors,text.col="black", bg="transparent",bty="n",cex=1) 
  
  plot(log(allD$LeafLife),log(allD$GrowthTotV),xlab="log(Leaf lifespan)",ylab="log(Growth)",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="LL.GrowV"),5])<0.05){
    plotLine(log(allD$LeafLife),lgsV$LL.GrowV,"dashed")
  } 
  plot(log(allD$LeafLife),allD$logRecV,xlab="",ylab="log(Fecundity)",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="LL.RecruitV"),5])<0.05){
    plotLine(log(allD$LeafLife),lgsV$LL.RecruitV)
  } 
  
  # SLA
  plot(log(allD$SLA),allD$SurvivalV,xlab="",ylab="Survival",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="SLA.SurvV"),5])<0.05){
    plotLGS(log(allD$SLA),lgsV$SLA.SurvV,"dashed")
  } 
  plot(log(allD$SLA),log(allD$GrowthTotV),xlab="log(SLA)",ylab="log(Growth)",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="SLA.GrowV"),5])<0.05){
    plotLine(log(allD$SLA),lgsV$SLA.GrowV)
  } 
  plot(log(allD$SLA),allD$logRecV,xlab="",ylab="log(Fecundity)",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="SLA.RecruitV"),5])<0.05){
    plotLine(log(allD$SLA),lgsV$SLA.RecruitV)
  }  
  
  # leaf N
  plot(log(allD$leafN),allD$SurvivalV,xlab="",ylab="Survival",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="LN.SurvV"),5])<0.05){
    plotLGS(log(allD$leafN),lgsV$LN.SurvV)
  } 
  plot(log(allD$leafN),log(allD$GrowthTotV),xlab="log(Leaf N)",ylab="log(Growth)",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="LN.GrowV"),5])<0.05){
    plotLine(log(allD$leafN),lgsV$LN.GrowV)
  } 
  plot(log(allD$leafN),allD$logRecV,xlab="",ylab="log(Fecundity)",col="gray10",bg=allD$colors,pch=allD$symbols2)  
  if(abs(coefsVR[which(rownames(coefsVR)=="LN.RecruitV"),5])<0.05){
    plotLine(log(allD$leafN),lgsV$LN.RecruitV)
  }  

dev.off()


# new Fig.2: Bar plot of standardized effect sizes for elasticities and vital rates

Edat=read.csv("Table1_Elast&TraitStats.csv")
Edat=Edat[,c(1:5,10,11)]
Vdat=read.csv("Table2_VitalRates&TraitStats.csv")
Vdat=Vdat[,c(1:4)]

myCol=c("dodgerblue3","wheat","red3")

png("Fig2_effect_sizes.png",height=4.5,width=7.5,units="in",res=1200)

par(mfrow=c(2,3),tcl=-0.2,mgp=c(3,0.5,0),mar=c(2,2,1.75,1),oma=c(0,3,0,0),cex=0.85)

myLabels=c("a","b","c","d","e")

for(i in 1:5){
  x=(1+3*(i-1)):(1+3*(i-1)+2)
  tmp=cbind(Edat[x,4],Edat[x,6],Vdat[x,3])
  tcrit=qt(0.975,Edat$N[x[1]])
  print(tcrit)
  barplot(t(tmp),beside=T,names.arg=c("S","G","F"),ylim=c(-4.5,8),col=myCol)
  abline(h=0,lty="solid")
  abline(h=tcrit,lty="dashed")
  abline(h=-tcrit,lty="dashed")
  mtext(myLabels[i],side=3,adj=0,font=2, line=0.5,cex=1.1)
}

legend("top",c("Elasticity (Dirichlet)","Elasticity (PGLS)","Vital rate (PGLS)"),
        fill=myCol,bty="n",cex=1)

mtext("Standardized trait effect",side=2,outer=T,line=1,cex=1.1)

dev.off()

