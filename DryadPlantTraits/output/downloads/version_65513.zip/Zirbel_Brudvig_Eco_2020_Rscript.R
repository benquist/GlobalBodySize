#Rscript for: Zirbel, C.R. and Brudvig, L.A. (2020)
#Trait-environment interactions affect plant establishment success during restoration
#Ecology
#Dryad DOI: 
#Created by: Chad Zirbel
#R v. 3.6.1
#10/30/2019

#load required packages
library(reshape2)
library(ggplot2)
library(car)
library(lme4)
library(glmmTMB)
library(MuMIn)
library(effects)
library(cowplot)
library(visreg)

#load data files
light<-read.csv("light_data_Zirbel_Brudvig_2020_dryad.csv")
herbivory<-read.csv("herbivory_Zirbel_Brudvig_2020_dryad.csv")
seed_mix<-read.csv("sown_density_Zirbel_Brudvig_2020_dryad.csv")
count<-read.csv("seedling_count_Zirbel_Brudvig_2020_dryad.csv")
traits<-read.csv("trait_data_Zirbel_Brudvig_2020_dryad.csv")
leaf_area<-read.csv("leaf_area_Zirbel_Brudvig_2020_dryad.csv")
seed_mass<-read.csv("seed_mass_Zirbel_Brudvig_2020_dryad.csv")
soil_moist<-read.csv("soil_moisture_Zirbel_Brudvig_2020_dryad.csv")
leaf_CN<-read.csv("leaf_CN_Zirbel_Brudvig_2020_dryad.csv")

####Cleaning environmental data ----------------------------------------------------
#soil data
# soil<-merge(soil_tex,soil_nut,by=c("site","split","transect_id"),all=T)
# whc<-whc[,names(whc)%in%c("transect_id","soil_whc"),]
# soil<-merge(soil,whc,by="transect_id",all=T)

##herbivory
#drop unnecessary columns
herbivory<-herbivory[,names(herbivory)%in%c("transect_id","plot","herbivory"),]
#average to the plot level
herb.avg<-aggregate(herbivory~plot+transect_id,data=herbivory,mean)
#merge herbivory and light data to create site dataframe
site_data<-merge(light, herb.avg,by=c("transect_id","plot"),all.x=T)

##Soil moisture
#Average
moist.melt<-melt(soil_moist, id.vars = c("date", "transect_id"))
moist.avg<-aggregate(value~variable+transect_id,data=moist.melt,mean,na.action=na.omit)
names(moist.avg)<-c("plot","transect_id","moist.avg")

#Minimum
moist.min<-aggregate(value~variable+transect_id,data=moist.melt,min,na.action=na.omit)
names(moist.min)<-c("plot","transect_id","moist.min")
soil.moist<-merge(moist.avg,moist.min,by=c("plot","transect_id"))

#merge with site data
levels(soil.moist$plot)<-c(1,2,3,4,5)
site_data<-merge(site_data,soil.moist,by=c("transect_id","plot"),all.x=T)

####clean up species count data -----------------------------------------------------
#count data
count<-count[,names(count)%in%c("Site","transect_id","spp_trt","source_trt","species","plot1","plot2","plot3","plot4","plot5"),]
count.melt<-melt(count,id.vars = c("Site","transect_id","spp_trt","source_trt","species"))

#make plot a factor that matches the rest of the data by removing the word "plot"
count.melt$variable<-as.factor(substring(count.melt$variable, 5))
names(count.melt)<-c("Site","transect_id","spp_trt","source_trt","species","plot","count")

###Add zeros for species that were sown but not counted at a site
#high diversity
count.high<-count.melt[count.melt$spp_trt=="High",]
count.high.cast<-dcast(Site+transect_id+spp_trt+plot~species,value.var = "count",fill=0,data=count.high,sum)
count.high.melt<-melt(count.high.cast)
names(count.high.melt)<-c("Site","transect_id","spp_trt","species","plot","count")

#low diversity
count.low<-count.melt[count.melt$spp_trt=="Low",]
count.low.cast<-dcast(Site+transect_id+spp_trt+plot~species,value.var = "count",fill=0,data=count.low,sum)
count.low.melt<-melt(count.low.cast)
names(count.low.melt)<-c("Site","transect_id","spp_trt","species","plot","count")

#combine low and high diversity count data frames
count.data<-rbind(count.high.melt,count.low.melt)

#### Trait data clean --------------------------------------------------------------------------------------------
#add leaf area
leaf_area$number<-as.factor(leaf_area$number)
traits<-merge(traits,leaf_area,by=c("species","source","number"),all.x=T)
#calculate SLA
traits$sla<-traits$total.leaf.area/traits$leaf_mass
#calculate root masss fraction
traits$root.mf<-traits$total_root_mass/traits$total_biomass

traits<-traits[,!(names(traits)%in%c("number","source"))] #drop some columns
trait.melt<-melt(traits,id.vars="species")
trait.ag<-dcast(trait.melt,species~variable,mean,na.rm=T)

seed.mass.ag<-aggregate(seed_mass~species,data=seed_mass,mean,na.rm=T)
trait.ag<-merge(trait.ag,seed.mass.ag,by="species",all.x=T)

#leaf C:N
#drop samples with <0.01
leaf_CN<-leaf_CN[leaf_CN$WEIGHT_g>=0.01,]
cn.avg<-aggregate(cbind(CARBON.,NITROGEN.,CN)~species,data=leaf_CN,mean)
#merge trait data
trait.ag<-merge(trait.ag,cn.avg,by="species",all.x=T)

#create data frame
species.data<-merge(count.melt,trait.ag,by="species",all.x=T)

#seed mix
species.data<-merge(species.data,seed_mix,by=c("species","spp_trt"),all.x=T)

####combine species and environmental data####
data<-merge(site_data,species.data,by=c("transect_id","plot"),all.x=T)

#scale data
data.scale<-scale(data[,c(3:6,12:24)])
data.scale<-cbind(data[,c(1:2,7:11)],data.scale)

#make variables factors
data.scale$plot<-as.factor(data$plot)

####Build GLMM --------------------------------------------------------------------
mod.tmb.nb<-glmmTMB(count~seeds_m2+total_biomass*moist.avg+seed_mass*light_available+NITROGEN.*herbivory+
                       root.mf*moist.avg+sla*moist.avg+sla*light_available+
                       (1|transect_id/plot)+(1|species), 
                     zi=~1,family=nbinom2(link = "log"), data=data.scale,
                     control=glmmTMBControl(optCtrl=list(iter.max=1e3,eval.max=1e3)))
summary(mod.tmb.nb)
Anova(mod.tmb.nb, type=3)

####Interaction plots -------------------------------------------------------------
controller=glmerControl(optimizer="bobyqa",optCtrl=list(maxfun=10000000))

mod.nb.2<-glmer.nb(count~seeds_m2+total_biomass*moist.avg+seed_mass*light_available+NITROGEN.*herbivory+
                     root.mf*moist.avg+sla*moist.avg+sla*light_available+
                     (1|transect_id/plot)+(1|species),control=controller,data=data.scale)

#herbivory-Leaf N interaction
eff.herb<-effect("NITROGEN.:herbivory",mod.nb.2,xlevels=2)
eff_df.herb <- data.frame(eff.herb)

#plot
p.herb <-ggplot(eff_df.herb, aes(herbivory,fit,color=factor(NITROGEN.)))+
  geom_line(size=1.25)+
  xlab("Herbivore pressure (% tissue missing)")+ylab(bquote('Seedling count (Indivduals/ 25'~m^2*')'))+
  scale_color_manual(values=c("#2c7bb6","#d7191c"),name="Leaf nitrogen",breaks=waiver(),labels = c("Low", "High"))+
  geom_ribbon(aes(ymin=fit-se,ymax=fit+se,fill=factor(NITROGEN.)),alpha=0.3, colour= NA)+
  scale_fill_manual(values=c("#2c7bb6","#d7191c"),guide=F)+
  guides(color=guide_legend(override.aes=list(fill=NA)))+
  annotate("text",label="p=0.02",x=-0.5,y=3.5,size=5)+
  annotate("text", label="b", x=-0.775, y=3.7, size=5)+
  theme(text = element_text(size=15),axis.text=element_text(colour="black"),panel.background=element_blank(),
        panel.grid.major=element_blank(),panel.grid.minor=element_blank(),axis.line = element_line(size=.7, color="black"),
        legend.key = element_blank(),legend.position=c("right"))

#RMF-soil moisture interaction
eff.moist<-effect("moist.avg:root.mf",mod.nb.2,xlevels=2)
eff_df.moist <- data.frame(eff.moist)

#plot
p.moist<- ggplot(eff_df.moist,aes(moist.avg,fit,color=factor(root.mf),group=factor(root.mf)))+
  geom_line(size=1.25)+
  xlab("Soil moisture (%)")+ylab(bquote('Seedling count (Indivduals/ 25'~m^2*')'))+
  scale_color_manual(values=c("#2c7bb6","#d7191c"),name="Root mass fraction",labels = c("Low", "High"))+
  geom_ribbon(aes(ymin=fit-se,ymax=fit+se,fill=factor(root.mf)),alpha=0.3, color=NA)+
  scale_fill_manual(values=c("#2c7bb6","#d7191c"),guide=F)+
  guides(color=guide_legend(override.aes=list(fill=NA)))+
  annotate("text",label="p=0.0002",x=-0.9,y=8.5,size=5)+
  annotate("text", label="a", x=-1.325, y=9, size=5)+
  theme(text = element_text(size=15),axis.text=element_text(colour="black"),panel.background=element_blank(),
        panel.grid.major=element_blank(),panel.grid.minor=element_blank(),axis.line = element_line(size=.7, color="black"),
        legend.key = element_blank(),legend.position="right")

#light-SLA interaction
eff.light<-effect("light_available:sla", mod.nb.2, xlevels=2)
eff_df.light<- data.frame(eff.light)

#plot
p.light<- ggplot(eff_df.light,aes(light_available,fit,color=factor(sla),group=factor(sla)))+
  geom_line(size=1.25)+
  xlab("Light available (PAR)")+ylab(bquote('Seedling count (Indivduals/ 25'~m^2*')'))+
  scale_color_manual(values=c("#2c7bb6","#d7191c"), name="Specific leaf area", labels= c("Low", "High"))+
  geom_ribbon(aes(ymin=fit-se,ymax=fit+se,fill=factor(sla)),alpha=0.3, color=NA)+
  scale_fill_manual(values=c("#2c7bb6","#d7191c"), guide=F)+
  guides(color=guide_legend(override.aes=list(fill=NA)))+
  annotate("text",label="p=0.08",x=-0.45,y=3.25,size=5)+
  annotate("text", label="c", x=-0.75, y=3.45, size=5)+
  theme(text = element_text(size=15),axis.text=element_text(colour="black"),panel.background=element_blank(),
        panel.grid.major=element_blank(),panel.grid.minor=element_blank(),axis.line = element_line(size=.7, color="black"),
        legend.key = element_blank(),legend.position="right")

#Create figure 2
tiff("int_plot.tiff",width = 6000, height = 12000, units = "px", res = 600)
pdf("Figure2.pdf", height= 11, width= 8.5)
plot_grid(p.moist, p.herb, p.light, align="v", ncol=1)
dev.off()

#### Main effects plot ----------------------------------------------------------------
tiff("leafN_plot.tiff",width = 4000, height = 4000, units = "px", res = 600)
ggplot(data.scale)+
  geom_point(aes(NITROGEN.,count),color="black",size=1.5,position = position_jitter(width = 0.1, height = 0.1))+
  stat_function(fun=function(x)exp(fixef(mod.tmb.nb)[[1]][1] + fixef(mod.tmb.nb)[[1]][7]*x),size=1.5,color="blue")+
  annotate("text",label="p=0.005",x=-1,y=60,size=5)+
  labs(x = "Leaf Nitrogen (%)", y =bquote('Seedling count (Indivduals/ 25'~m^2~')'))+
  theme(text = element_text(size=20),axis.text=element_text(color="black"),panel.background=element_blank(),
        panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"),legend.position = "none")
dev.off()

#### Effects plot ----------------------------------------------------------------------
#results.table<-as.data.frame(cbind(confint(mod.tmb$obj),fixef(mod.tmb$obj)))
results.table<-as.data.frame(confint(mod.tmb.nb))
names(results.table)<-c("lower","upper","effect")
results.table$var<-rownames(results.table)

#labels
results.table$var <- factor(results.table$var, levels = c("cond.moist.avg:root.mf","cond.total_biomass:moist.avg","cond.seed_mass:light_available","cond.NITROGEN.:herbivory","cond.light_available:sla","cond.moist.avg:sla","cond.root.mf","cond.NITROGEN.","cond.sla","cond.seed_mass","cond.total_biomass","cond.light_available","cond.herbivory","cond.moist.avg","cond.seeds_m2"))
var.label<-c("cond.seeds_m2"="Seeding density","cond.total_biomass"="Growth rate","cond.moist.avg"="Soil moisture","cond.seed_mass"="Seed mass","cond.light_available"="Light availability","cond.root.mf"="Root mass fraction","cond.sla"="Specific leaf area","cond.herbivory"="Herbivore pressure","cond.NITROGEN."="Leaf nitrogen","cond.moist.avg:root.mf"="Root mass fraction:Soil moisture","cond.total_biomass:moist.avg"="Growth rate:Soil moisture","cond.seed_mass:light_available"="Seed mass:light availability","cond.NITROGEN.:herbivory"="Leaf N:herbivore pressure","cond.moist.avg:sla"="Soil moisture:SLA","cond.light_available:sla"="Light availability:SLA")

#Create figure 1
pdf("effects_plot.pdf",width = 8.5, height = 11)
ggplot(results.table[2:16,], aes(var,effect))+
  geom_point(size=2)+
  geom_hline(yintercept=0, linetype="dotted")+
  coord_flip()+
  geom_errorbar(width=0, aes(ymin=lower, ymax=upper),size=1) +
  xlab(label="")+
  ylab(label="Standardized regression coefficents")+
  scale_x_discrete(labels = var.label)+
  theme(text = element_text(size=14),axis.text=element_text(colour="black"),strip.background =element_rect(fill="white"),
        panel.background=element_blank(),panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        panel.border = element_rect(color = "black", fill = NA, size = 0),
        axis.line = element_line(size=0, color="black"),legend.position="none")
dev.off()

#### Surface interaction plots ------------------------------------------------------------
tiff("herb_surface.tiff",width = 5000, height = 4000, units = "px", res = 600)
visreg2d(mod.tmb.nb, x="NITROGEN.", y="herbivory", plot.type="gg",
         xlab="Leaf nitrogen (%)",ylab="Herbivore pressure (% tissue missing)",main="", cex.lab=1.7, cex.axis = 2,
         col=colorRampPalette(c("white","black"))(30))+
  geom_point(aes(NITROGEN., herbivory), data=data.scale, col='red')+
  scale_fill_gradient(name = "Seedling count",low="white", high="black") 
dev.off()

tiff("moist_surface.tiff",width = 5000, height = 4000, units = "px", res = 600)
visreg2d(mod.tmb.nb, x="root.mf", y="moist.avg", plot.type="gg",
         xlab="Root mass fraction",ylab="Soil moisture (%)",main="", cex.lab=1.7, cex.axis = 2,
         col=colorRampPalette(c("white","black"))(30))+
  geom_point(aes(total_biomass, moist.avg), data=data.scale, col='red')+
  scale_fill_gradient(name = "Seedling count",low="white", high="black")+
  coord_cartesian(xlim = c(-1.9, 1.65))
dev.off()

tiff("light_surface.tiff",width = 5000, height = 4000, units = "px", res = 600)
visreg2d(mod.tmb.nb, x="sla", y="light_available", plot.type="gg",
         xlab="Specific leaf area",ylab="Light available (PAR)",main="", cex.lab=1.7, cex.axis = 2,
         col=colorRampPalette(c("white","black"))(30))+
  geom_point(aes(sla, light_available), data=data.scale, col='red')+
  scale_fill_gradient(name = "Seedling count",low="white", high="black")+
  coord_cartesian(xlim = c(-1.24, 1.65))
dev.off()

#### Correlation plots ---------------------------------------------------------------------
#correlation between leaf N and biomass
cor(trait.ag$NITROGEN.,trait.ag$total_shoot_mass, use="complete.obs", method="pearson")
cor(trait.ag$NITROGEN.,trait.ag$total_root_mass, use="complete.obs", method="pearson")

tiff("n-shoot_cor.tiff",width = 4, height = 4, units = "in", res = 300)
ggplot(trait.ag, aes(NITROGEN., total_shoot_mass))+
  geom_point(size=2, shape=16)+
  geom_smooth(method="lm", se=F, color="black", size=1.5)+
  annotate("text",label="r= -0.57", x=1.2, y=0.8, size=4)+
  annotate("text", label= "(a)", x=2.2, y=0.8)+
  labs(x ="Leaf nitrogen (%)", y = "Aboveground biomass (g)")+
  theme(text = element_text(size=18),axis.text=element_text(color="black"),panel.background=element_blank(),
        panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"),legend.position = "none")
dev.off()

tiff("n-root_cor.tiff",width = 4, height = 4, units = "in", res = 300)
ggplot(trait.ag, aes(NITROGEN., total_root_mass))+
  geom_point(size=2, shape=16)+
  geom_smooth(method="lm", se=F, color="black", size=1.5)+
  annotate("text",label="r= -0.42", x=2, y=0.75, size=4)+
  annotate("text", label= "(b)", x=2.2, y=0.85)+
  labs(x ="Leaf nitrogen (%)", y = "Belowground biomass (g)")+
  theme(text = element_text(size=18),axis.text=element_text(color="black"),panel.background=element_blank(),
        panel.grid.major=element_blank(),panel.grid.minor=element_blank(),
        axis.line = element_line(size=.7, color="black"),legend.position = "none")
dev.off()

##Trait correlation plot
#This function computes and line of best fit for bivariate plots
#commenting out loess fit line for this figure
panel.fit<-function(x, y, ...) {
  ll <- loess(y~x)
  points(x,y, ...)
  nx<-seq(min(x), max(x), length.out=150)
  #lines(nx, predict(ll, nx), col="blue",lwd=2)
  abline(a = lm(y ~ x)$coefficients[1] , b = lm(y ~ x)$coefficients[2] ,col="black",lwd=2, ...)
}

#This function computes the correlation between every combination of variables
panel.cor <- function(x, y, digits=2, prefix="",cex.cor, ...)
{
  usr <- par("usr"); on.exit(par(usr))
  par(usr = c(0, 1, 0, 1))
  r <- cor(x, y)
  txt <- format(c(r, 0.123456789), digits=digits)[1]
  txt <- paste(prefix, txt, sep="")
  if(missing(cex.cor)) cex.cor <- 1/strwidth(txt)
  text(0.5, 0.5, txt, cex = 2.75)
}

#This function computes the density histogram and boxplot of each variable
panel.density = function(x,...)
{
  pu <- par("usr")
  d <- density(x,...)
  par("usr" = c(pu[1:2], 0, max(d$y)*1.5))
  lines(d,lwd=2)
  par("usr" = c(pu[1:2], 0, 1))
  boxplot(x, at=0.5, boxwex=0.3, horizontal=TRUE, add=TRUE, axes=F)
}

#create data frame with diversity metrics
trait.cor.data<-trait.ag[c("total_biomass", "sla", "seed_mass", "NITROGEN.", "root.mf")]
names(trait.cor.data)<-c("Growth rate","Specific leaf area","Seed mass", "Leaf nitrogen content", "Root mass fraction")
trait.cor.data<-na.omit(trait.cor.data)

#plot
tiff("trait_cor.tiff",width = 6, height = 6, units = "in", res = 600)
pairs(trait.cor.data,
      upper.panel=panel.cor,
      lower.panel=panel.fit,
      diag.panel=panel.density)
dev.off()

#### AICc and R2 ---------------------------------------------------------------------
#Calculate AICc for main model, no interaction model, and intercept model
mod.tmb.nb.null<-glmmTMB(count~1+
                            (1|transect_id/plot)+(1|species), 
                          zi=~1,family=nbinom2(link = "log"), data=na.omit(data.scale),
                          control=glmmTMBControl(optCtrl=list(iter.max=1e3,eval.max=1e3)),REML=F)

mod.tmb.nb.noint<-glmmTMB(count~seeds_m2+total_biomass+moist.avg+seed_mass+light_available+NITROGEN.+herbivory+sla+root.mf+
                             (1|transect_id/plot)+(1|species), 
                           zi=~1,family=nbinom2(link = "log"), data=na.omit(data.scale),
                           control=glmmTMBControl(optCtrl=list(iter.max=1e3,eval.max=1e3)),REML=F)

mod.tmb.nb.full<-glmmTMB(count~seeds_m2+total_biomass*moist.avg+seed_mass*light_available+NITROGEN.*herbivory+
                      root.mf*moist.avg+sla*moist.avg+sla*light_available+
                      (1|transect_id/plot)+(1|species), 
                    zi=~1,family=nbinom2(link = "log"), data=data.scale,
                    control=glmmTMBControl(optCtrl=list(iter.max=1e3,eval.max=1e3)),REML=F)

AICc(mod.tmb.nb.full, mod.tmb.nb.noint, mod.tmb.nb.null)

#GLMM TMB R2
collapse_cond <- function(x)
  if (is.list(x) && "cond" %in% names(x)) x[["cond"]] else x

##' Cleaned-up/adapted version of Jon Lefcheck's code from SEMfit;
##' also incorporates some stuff from MuMIn::rsquaredGLMM.
##' Computes Nakagawa/Schielzeth/Johnson analogue of R^2 for
##' GLMMs. Should work for [g]lmer(.nb), glmmTMB models ...
##'
##' @param model a fitted model
##' @return a list composed of elements "family", "link", "marginal", "conditional"
rsq_tmb <- function(model) {
  
  ## get basics from model (as generally as possible)
  vals <- list(
    beta=fixef(model),
    X=getME(model,"X"),
    vc=VarCorr(model),
    re=ranef(model))
  
  ## glmmTMB-safety
  if (is(model,"glmmTMB")) {
    vals <- lapply(vals,collapse_cond)
    nullEnv <- function(x) {
      environment(x) <- NULL
      return(x)
    }
    if (!identical(nullEnv(model$modelInfo$allForm$ziformula),nullEnv(~0)))
      warning("R2 ignores effects of zero-inflation")
    dform <- nullEnv(model$modelInfo$allForm$dispformula)
    if (!identical(dform,nullEnv(~1)) &&
        (!identical(dform,nullEnv(~0))))
      warning("R2 ignores effects of dispersion model")
  }
  
  ## Test for non-zero random effects
  if (any(sapply(vals$vc, function(x) any(diag(x)==0)))) {
    ## FIXME: test more generally for singularity, via theta?
    stop("Some variance components equal zero. Respecify random structure!")
  }
  
  ## set family/link info
  ret <- list()
  if (is(model,"glmmTMB") || is(model,"glmerMod")) {
    ret$family <- family(model)$family
    ret$link <- family(model)$link
  } else {
    ret$family <- "gaussian"; ret$link <- "identity"
  }
  
  ## Get variance of fixed effects: multiply coefs by design matrix
  varF <- with(vals,var(as.vector(beta %*% t(X))))
  
  ## Are random slopes present as fixed effects? Warn.
  random.slopes <- if("list" %in% class(vals$re)) {
    ## multiple RE
    unique(c(sapply(vals$re,colnames)))
  } else {
    colnames(vals$re)
  }
  if (!all(random.slopes %in% names(vals$beta))) 
    warning("Random slopes not present as fixed effects. This artificially inflates the conditional R2. Respecify fixed structure!")
  
  ## Separate observation variance from variance of random effects
  nr <- sapply(vals$re, nrow)
  not.obs.terms <- names(nr[nr != nobs(model)])
  obs.terms <- names(nr[nr==nobs(model)])
  
  ## Compute variance associated with a random-effects term
  ## (Johnson 2014)
  getVarRand <- function(terms) {
    sum(
      sapply(vals$vc[terms],
             function(Sigma) {
               Z <- vals$X[, rownames(Sigma), drop = FALSE]
               Z.m <- Z %*% Sigma
               return(sum(diag(crossprod(Z.m, Z))) / nobs(model))
             } )
    )
  }
  
  ## Variance of random effects 
  varRand <- getVarRand(not.obs.terms)
  
  if (is(model,"lmerMod") ||
      (ret$family=="gaussian" && ret$link=="identity")) {
    ## Get residual variance
    varDist <- sigma(model)^2
    varDisp <- 0
  } else {
    varDisp <- if (length(obs.terms)==0) 0 else getVarRand(obs.terms)
    
    badlink <- function(link,family) {
      warning(sprintf("Model link '%s' is not yet supported for the %s distribution",link,family))
      return(NA)
    }
    
    if(ret$family == "binomial") {
      varDist <- switch(ret$link,
                        logit=pi^2/3,
                        probit=1,
                        badlink(ret$link,ret$family))
    } else if (ret$family == "poisson" ||
               grepl("nbinom",ret$family) ||
               grepl("Negative Binomial", ret$family)) {
      ## Generate null model (intercept and random effects only, no fixed effects)
      
      ## https://stat.ethz.ch/pipermail/r-sig-mixed-models/2014q4/023013.html
      ## FIXME: deparse is a *little* dangerous
      rterms <- paste0("(",sapply(findbars(formula(model)),deparse),")")
      nullform <- reformulate(rterms,response=".")
      null.model <- update(model,nullform)
      
      ## from MuMIn::rsquaredGLMM
      
      ## Get the fixed effects of the null model
      null.fixef <- unname(collapse_cond(fixef(null.model)))
      
      ## in general want log(1+var(x)/mu^2)
      logVarDist <- function(null.fixef) {
        mu <- exp(null.fixef)
        if (mu < 6)
          warning(sprintf("mu of %0.1f is too close to zero, estimate may be unreliable \n",mu))
        vv <- switch(ret$family,
                     poisson=mu,
                     nbinom1=,
                     nbinom2=family(model)$variance(mu,sigma(model)),
                     if (is(model,"merMod"))
                       mu*(1+mu/getME(model,"glmer.nb.theta"))
                     else mu*(1+mu/model$theta))
        cvsquared <- vv/mu^2
        return(log1p(cvsquared))
      }
      
      varDist <- switch(ret$link,
                        log=logVarDist(null.fixef),
                        sqrt=0.25,
                        badlink(ret$link,ret$family))
    }
  }
  ## Calculate R2 values
  ret$Marginal = varF / (varF + varRand + varDisp + varDist)
  ret$Conditional = (varF + varRand) / (varF + varRand + varDisp + varDist)
  return(ret)
}

##Calculate R2
rsq_tmb(mod.tmb.nb)