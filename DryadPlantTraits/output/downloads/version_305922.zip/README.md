# Data from: Differential responses of community-level functional traits to mid- and late-season experimental drought in a temperate grassland

[https://doi.org/10.5061/dryad.kh18932gb](https://doi.org/10.5061/dryad.kh18932gb)

The dataset contains the data and scripts to reproduce the analysis performed in Fenollosa et al 2024 JEcol, which mainly consists in contrasting grassland community composition between plots subjected to three precipitation treatments in a block design, calculating specific and fixed community-weighted means for five functional traits, calculating intraspecific variability, using the functional trait data to build a PCA and calculate functional diversity. Full information of the experimental design and the data can be found in the manuscript.

## Description of the data, file structure, and code

The file contains a folder with the data used and a folder with the scripts, together with a text file named "Metadata.txt" that reviews the content and purpose of each script in the context of the manuscript. In all datasets, missing values are marked as "NA". We are providing all the used data and code to reproduce the article in order of results presentation within the manuscript. In order to facilitate it we summarize here the analytic steps and the flow from raw data to all analysis included in the manuscript. 

The scripts and datasets provided are as follows, sorted from raw data to results presentation within the article:

1. In order to perform community composition analysis to compare plots from different treatments, use the R script "1_Community Analysis.R" that uses "abundance_data.RData". This data file contains the raw abundances (percentage of coverage 0-100%) of the different species registered in each grassland plot. In this dataframe, one can find the factors Season (July/September), Treatment (Drought, Fertilized, Ambient, Irrigated), the block (A:E) and the species scientific name. Note that no fertilization treatment was applied even though this label was used. Fertilized plots correspond to a replicate of ambient controls. Therefore within the code, Fertilized and Ambient plots are relabelled to "Control".
2. To calculate specific and fixed CWM as described in the methods, use the R script "2_CWMFlexSpec_Calculations.R" and import data from "abundance_data.RData" described previously and "TraitsData.xslx". Use this script also to plot CWM. The Excel file "TraitsData.xslx" contains the following variables:
   1. Plot: Plot number
   2. Block: Block number A:E
   3. Treatment: Drought, Control (Ambient and Fertilized) and Irrigated.
   4. Season: July, September.
   5. Species: Scientific species name found in that plot
   6. Functional traits: Height (mm), Thickness (Leaf thickness, mm), SLA (Specific leaf area, mm2/mg), LDMC (leaf dry matter content, mg/g), Phos (leaf phosphorous content mg/g)

      Note that in this dataset some cells in plant height (column F) were coloured in orange. This was done to highlight the fact that these trait data correspond to the applied height correction. Due to the graminoids identification difficulties at the late-season, and because all graminoids (*Agrostis capillaris*, *Arrhenatherum elatius*, *Brachypodium pinnatum*, *Brachypodium sylvaticum,* *Dactylis glomerata*, *Holcus lanatus*, and *Trisetum flavescens*) showed similar height in comparison to other functional groups in the mid-season, we used the height of *Brachypodium pinnatum, *the most abundant identifiable graminoid (*ca.* 34%, whereas the non-*Brachypodium* graminoids showed relative abundances <18% at the mid-season), as the height of late-season non-*Brachypodium* graminoids. Orange cells corresponds to the ones where this correction was applied.
3. To test differences between season timings and treatments in CWM, use the R script "3_StatisticsCWM.R" and import CWM from the excel file "CWM.xslx". The Excel file "CWM.xlsx", with treatment coloured acording to the manuscript colors, contains the same variables as in point 2 (plot, treatment, season, block), and then the specific and fixed CWM for each of the five functional traits, coded as: 
   1. P_specific.avg and P_fixed.avg: leaf phosphorous content (mg/g) specific and fixed CWM respectively. 
   2. LDMC_specific.avg and LDMC_fixed.avg: Same for (leaf dry matter content, (mg/g)
   3. Thick_specific.avg and Thick_fixed.avg: Same for Leaf thickness (mm)
   4. SLA_specific.avg and SLA_fixed.avg: Same for Specific leaf area (mm2/mg)
   5. log.height_specific.avg and log.height_fixed.avg: Same for Plant height (log mm). Note that this variable was log transformed. 
4. To build the PCA from Figure 3, use 4_PCASpecies.R that loads: traits.RData, abundance_data.RData and fg_summary.RData, it uses also the excel "DifferencesCommunities.xslx" which contains the differences in relative abundance between control and drought plots.
   1. In "DifferencesCommunities.xslx" we provide a list of species and their dissimilarity between drought and control plots (diss), their relative abundance in control plots (RelAbC), their relative abundance in drought plots (RelAbD) and the absolute difference between those (reldif) as RelAbC- RelAbD. The coloured cells in columns diss and reldif correspond to the conditional formating using a green to red colour scale, that helps visualizing the highest and lowest values in each column. 
   2. In " fg_summary.RData" we include the summary of the presented trait values for each functional group (needed for September graminoids). Find more details of this within the manuscript. 
5. To contrast species level traits, use "5_ConfIntPerSpecies.R" and load "Species level traits.RData" and traits.RData described previously. The script calculates confidence intervals for each species mean functional traits.
6. To calculate functional diversity, we used the fundiversity R package from Grenie and Gruison 2022 Ecography, and followed the tutorial: [https://cran.r-project.org/web/packages/fundiversity/vignettes/fundiversity.html](https://cran.r-project.org/web/packages/fundiversity/vignettes/fundiversity.html). Import mean trait data per species found in the Excel file "SpeciesMeanforFD.xsls" and use the script "Appendix_FunctionalDiversity.R". The excel file "SpeciesMeanforFD.xsls" contains:
   1. Season: July, September
   2. Species: Species scientific name, using underscore instead of empty spaces between words.
   3. The five studied functional traits values for the previously described variables: Height (mm), Thickness (mm), SLA (Specific leaf area, mm2/mg), LDMC (leaf dry matter content, mg/g), Phos (leaf phosphorous content mg/g).

## Sharing/Access information

If you have any issues with the data please contact: [erola.fenollosaromani@biology.ox.ac.uk](mailto:erola.fenollosaromani@biology.ox.ac.uk) or [erola.fenollosa@gmail.com](mailto:erola.fenollosa@gmail.com)

## Code/Software

We have provided the main R code file used to process this data for the manuscript. We used R version 4.2.1 and RStudio. 
