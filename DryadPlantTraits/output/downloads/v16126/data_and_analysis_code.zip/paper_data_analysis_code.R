
library(ggplot2)
library(vegan)
library(dplyr)
library(plotrix)
library(gridExtra)
library(lmPerm)

#load soil data and run the anova of soil variables.
soil <- read.table("soil.txt",header = TRUE)
head(soil)
summary(aovp(SWC ~ site*cushion*type, soil, perm = "Exact"))
summary(aovp(STP ~ site*cushion*type, soil, perm = "Exact"))
summary(aovp(STN ~ site*cushion*type, soil, perm = "Exact"))
summary(aovp(STOC ~site*cushion*type, soil, perm = "Exact"))
summary(aovp( pH ~ site*cushion*type, soil, perm = "Exact"))

#load RII (abundance RII & richness RII) and climate data (temperatrue & precipitation),
#then run ancova model.
rai <- read.table ( "TPRII.txt", sep='\t', row.names=1,header = TRUE)
head(rai)
rai$f <- paste(substr(rownames(rai),1,2),
               substr(rownames(rai),6,7),sep = "")
rai$g <- substr(rownames(rai),6,7)
rai$Phenotypes <- substr(rownames(rai),6,6)
rai$T2 <- rai$T^2
rai$P2 <- rai$P^2
head(rai)

summary(aov(RRII ~ T+T2+Phenotypes+T:Phenotypes+T2:Phenotypes,rai))
summary(aov(ARII ~ T+T2+Phenotypes+T:Phenotypes+T2:Phenotypes,rai))
summary(aov(RRII ~ P+P2+Phenotypes+P2:Phenotypes+P:Phenotypes,rai))
summary(aov(ARII ~ P+P2+Phenotypes+P2:Phenotypes+P:Phenotypes,rai))


raim <- summarize(group_by(rai,f),
                  RRIIm = mean(RRII),
                  ARIIm = mean(ARII),
                  Pm = mean(P),
                  Tm = mean(T),
                  se1 = std.error(RRII),
                  se2 = std.error(ARII))
raim$l <- substr(raim$f,1,2)
raim$g <- substr(raim$f,3,4)

#T ~ RRII

ANCOVAa <- ggplot()+
  geom_smooth(aes(rai$T,rai$RRII,group=rai$g,color=rai$g),method = "lm",
              formula =y ~ poly(x, 2),
              position=position_dodge(width=.5),se=F,size=0.75)+
  geom_point(aes(raim$Tm,raim$RRIIm,group=raim$g ,shape=raim$g, color=raim$g),
             position=position_dodge(width=.5),size=2.5)+
  geom_errorbar ( aes(raim$Tm,raim$RRIIm, ymin=raim$RRIIm-raim$se1,
                      ymax=raim$RRIIm+raim$se1,group=raim$g),
                  position=position_dodge(width=.5),width=0.35)+
  geom_text(aes(raim$Tm,-.88),label=raim$l,size=5,color="black")+
  scale_colour_manual (name="Phenotypes", values =c("grey50","black"),
                       labels = c("Loose cushion","Tight cushion"))+
  scale_shape_manual (name="Phenotypes", values =c(1,2),
                      labels = c("Loose cushion","Tight cushion"))+
  labs(x="",y="RIIrichness")+
  coord_cartesian(xlim = c(1,7),ylim = c(-1,1))+
  geom_hline(yintercept=0,linetype="dashed",size=.2)+
  scale_y_continuous(expand = c(0,0))+
  scale_x_continuous(expand = c(0,0),breaks = c(1,2,3,4,5,6,7))+
  theme_bw()+
  theme(panel.grid=element_blank(),
        panel.border=element_blank(),
        axis.line=element_line(color = "black",size=.5),
        legend.position=c(.85,.85),
        legend.key = element_blank(),
        legend.title= element_blank(),
        legend.text=element_text(size=16),
        axis.title=element_text(size=16),
        axis.text=element_text(size=16,color = "black"),
        axis.ticks = element_line(color = "black")) 
#P ~ RRII

ANCOVAb <- ggplot()+
  geom_smooth(aes(rai$P,rai$RRII,group=rai$g,color=rai$g),method = "lm",
              formula =y ~ poly(x, 2),
              position=position_dodge(width=6.67),se=F,size=0.75)+
  geom_point(aes(raim$Pm,raim$RRIIm,group=raim$g ,shape=raim$g, color=raim$g),
             position=position_dodge(width=6.67),size=2.5)+
  geom_errorbar ( aes(raim$Pm,raim$RRIIm, ymin=raim$RRIIm-raim$se1,
                      ymax=raim$RRIIm+raim$se1,group=raim$g),
                  position=position_dodge(width=6.67),width=4.67)+
  geom_text(aes(raim$Pm,-.88),label=raim$l,size=5,color="black")+
  scale_colour_manual (name="Phenotypes", values =c("grey50","black"),
                       labels = c("Loose cushion",
                                  "Tight cushion"))+
  scale_shape_manual (name="Phenotypes", values =c(1,2),
                      labels = c("Loose cushion",
                                 "Tight cushion"))+
  labs(x="" , y="")+
  coord_cartesian(xlim = c(30,110),ylim = c(-1,1))+
  geom_hline(yintercept=0,linetype="dashed",size=.2)+
  scale_y_continuous(expand = c(0,0))+
  scale_x_continuous(expand = c(0,0),breaks = c(30,40,50,60,70,80,90,100,110))+
  theme_bw()+
  theme(panel.grid=element_blank(),
        panel.border=element_blank(),
        axis.line=element_line(color = "black",size=.5),
        legend.position="none",
        axis.title=element_text(size=16),
        axis.text=element_text(size=16,color = "black"),
        axis.ticks = element_line(colour = "black")) 


#T ~ ARII

ANCOVAc <-  ggplot()+
  geom_smooth(aes(rai$T,rai$ARII,group=rai$g,color=rai$g),method = "lm",
              formula =y ~ poly(x, 2),
              position=position_dodge(width=0.5),se=F,size=0.75)+
  geom_point(aes(raim$Tm,raim$ARIIm,group=raim$g ,shape=raim$g, color=raim$g),
             position=position_dodge(width=0.5),size=2.5)+
  geom_errorbar ( aes(raim$Tm,raim$ARIIm, ymin=raim$ARIIm-raim$se1,
                      ymax=raim$ARIIm+raim$se1,group=raim$g),
                  position=position_dodge(width=0.5),width=0.35)+
  geom_text(aes(raim$Tm,-.88),label=raim$l,size=5,color="black")+
  scale_colour_manual (name="Phenotypes", values =c("grey50","black"),
                       labels = c("Loose cushion","Tight cushion"))+
  scale_shape_manual (name="Phenotypes", values =c(1,2),
                      labels = c("Loose cushion","Tight cushion"))+
  labs(x="Site",y="RIIabundance")+
  coord_cartesian(xlim = c(1,7),ylim = c(-1,1))+
  geom_hline(yintercept=0,linetype="dashed",size=.2)+
  scale_y_continuous(expand = c(0,0))+
  scale_x_continuous(expand = c(0,0),breaks = c(1,2,3,4,5,6,7))+
  theme_bw()+
  theme(panel.grid=element_blank(),
        panel.border=element_blank(),
        axis.line=element_line(color = "black",size=.5),
        legend.position="none",
        legend.key = element_blank(),
        legend.title= element_blank(),
        legend.text=element_text(size=16),
        axis.title=element_text(size=16),
        axis.text=element_text(size=16,color = "black"),
        axis.ticks = element_line(colour = "black")) 

#P ~ ARII

ANCOVAd <- ggplot()+
  geom_smooth(aes(rai$P,rai$ARII,group=rai$g,color=rai$g),method = "lm",
              formula =y ~ poly(x, 2),
              position=position_dodge(width=6.67),se=F,size=0.75)+
  geom_point(aes(raim$Pm,raim$ARIIm,group=raim$g ,shape=raim$g, color=raim$g),
             position=position_dodge(width=6.67),size=2.5)+
  geom_errorbar ( aes(raim$Pm,raim$ARIIm, ymin=raim$ARIIm-raim$se1,
                      ymax=raim$ARIIm+raim$se1,group=raim$g),
                  position=position_dodge(width=6.67),width=4.67)+
  geom_text(aes(raim$Pm,-.88),label=raim$l,size=5,color="black")+
  scale_colour_manual (name="Phenotypes", values =c("grey50","black"),
                       labels = c("Loose cushion",
                                  "Tight cushion"))+
  scale_shape_manual (name="Phenotypes", values =c(1,2),
                      labels = c("Loose cushion",
                                 "Tight cushion"))+
  labs(x="Site" , y="")+
  coord_cartesian(xlim = c(30,110),ylim = c(-1,1))+
  geom_hline(yintercept=0,linetype="dashed",size=.2)+
  scale_y_continuous(expand = c(0,0))+
  scale_x_continuous(expand = c(0,0),breaks = c(30,40,50,60,70,80,90,100,110))+
  theme_bw()+
  theme(panel.grid=element_blank(),
        panel.border=element_blank(),
        axis.line=element_line(color = "black",size=.5),
        legend.position="none",
        axis.title=element_text(size=16),
        axis.text=element_text(size=16,color = "black"),
        axis.ticks = element_line(colour = "black")) 

grid.arrange(ANCOVAa , ANCOVAb , ANCOVAc , ANCOVAd , ncol=2)


#load community data and run the PCoA.
d<-read.table("community.txt") 

#MY
my<-d[grep("MY", rownames(d)), ]

my <- my[rowSums(my) != 0, ]
my <- my[,colSums(my) != 0]
my <- my[,colSums(my != 0) >= 3]

#QL
ql<-d[grep("QL", rownames(d)), ]

ql <- ql[rowSums(ql) != 0, ]
ql <- ql[,colSums(ql) != 0]
ql <- ql[,colSums(ql != 0) >= 3]

#QH
qh<-d[grep("QH", rownames(d)), ]

qh <- qh[rowSums(qh) != 0, ]
qh <- qh[,colSums(qh) != 0]
qh <- qh[,colSums(qh != 0) >= 3]

#TS
ts<-d[grep("TS", rownames(d)), ]

ts <- ts[rowSums(ts) != 0, ]
ts <- ts[,colSums(ts) != 0]
ts <- ts[,colSums(ts != 0) >= 3]
#npMANOVA
npmanovaMY <- my
npmanovaMY$hab <- as.factor(substr(rownames(npmanovaMY),6,6))
npmanovaMY$cush <- as.factor(substr(rownames(npmanovaMY),7,7))###Cushion
head(npmanovaMY)
adonis(npmanovaMY[,1:23] ~ hab * cush , data = npmanovaMY,
       permutations = 9999, method = "bray")


npmanovaQL <- ql
npmanovaQL$hab <- substr(rownames(npmanovaQL),6,6)
npmanovaQL$cush <- substr(rownames(npmanovaQL),7,7)
head(npmanovaQL)
adonis(npmanovaQL[,1:14] ~ npmanovaQL$hab*npmanovaQL$cush,
       permutations = 9999,method = "bray")


npmanovaQH <- qh
npmanovaQH$hab <- substr(rownames(npmanovaQH),6,6)
npmanovaQH$cush <- substr(rownames(npmanovaQH),7,7)
head(npmanovaQH)
adonis(npmanovaQH[,1:15] ~ npmanovaQH$hab*npmanovaQH$cush,
       permutations = 9999,method = "bray")


npmanovaTS <- ts
npmanovaTS$hab <- substr(rownames(npmanovaTS),6,6)
npmanovaTS$cush <- substr(rownames(npmanovaTS),7,7)
head(npmanovaTS)
adonis(npmanovaTS[,1:9] ~ npmanovaTS$hab*npmanovaTS$cush,
       permutations = 9999,method = "bray")


pcoamy<-cmdscale(vegdist(my),k=(nrow(my)-1),eig=TRUE,add = TRUE)

sitemy<-as.data.frame(scores(pcoamy)[,1:2])
speciesmy<-as.data.frame(wascores(pcoamy$points[,1:2],my))

sitemy$g<-paste(substr(rownames(sitemy),1,2),substr(rownames(sitemy),6,7),sep = "")
sitemym<-summarize(group_by(sitemy,g),Dim1m=mean(Dim1),Dim2m=mean(Dim2),Dim1se=sd(Dim1)/sqrt(n()),Dim2se=sd(Dim2)/sqrt(n()))
sitemym$s<-substr(sitemym$g,1,2);sitemym$t<-substr(sitemym$g,3,3);sitemym$c<-substr(sitemym$g,4,4);sitemym$tc<-substr(sitemym$g,3,4)


plotmy <- ggplot(data= sitemym,aes(Dim1m,Dim2m))+
  geom_point(aes(shape=factor(tc)),size=6)+
  geom_text( data= speciesmy, aes(V1,V2,label=rownames(speciesmy)),size=4)+
  scale_shape_manual(name="",values = c(16,1,17,2),
                     labels=c("Loose cushion",
                              "Loose open",
                              "Tight cushion",
                              "Tight open"))+
  guides(shape=guide_legend(ncol=1))+
  geom_errorbar(aes(ymin=Dim2m-Dim2se,ymax=Dim2m+Dim2se),
                width=0.01)+
  geom_errorbarh(aes(y=Dim2m,xmin=Dim1m-Dim1se,xmax=Dim1m+Dim1se),
                 height=0.01)+
   geom_hline(yintercept=0,linetype="dashed",size=.2)+
  geom_vline(xintercept=0,linetype="dashed",size=.2)+
  labs( x="PC1" , y="PC2"  )+
  theme_bw()+
  theme(panel.grid=element_blank(),
        plot.title = element_blank(),
        legend.position=c(0.85,0.15),
        legend.key = element_blank(),
        legend.title = element_blank(),
        legend.text=element_text(size=12),
        axis.title = element_text(size=16),
        axis.text = element_text(size= 14, color="black"))


#QL
pcoaql<-cmdscale(vegdist(ql),k=(nrow(ql)-1),eig=TRUE ,add = TRUE)
siteql<-as.data.frame(scores(pcoaql)[,1:2])
speciesql<-as.data.frame(wascores(pcoaql$points[,1:2],ql))

siteql$g<-paste(substr(rownames(siteql),1,2),substr(rownames(siteql),6,7),sep = "")
siteqlm<-summarize(group_by(siteql,g),Dim1m=mean(Dim1),Dim2m=mean(Dim2),Dim1se=sd(Dim1)/sqrt(n()),Dim2se=sd(Dim2)/sqrt(n()))
siteqlm$s<-substr(siteqlm$g,1,2);siteqlm$t<-substr(siteqlm$g,3,3);siteqlm$c<-substr(siteqlm$g,4,4);siteqlm$tc<-substr(siteqlm$g,3,4)


plotql <- ggplot(data= siteqlm, aes(Dim1m,Dim2m))+
  geom_point( aes(shape=factor(tc)),size=6)+
  geom_text( data= speciesql, aes(V1,V2,label=rownames(speciesql)),size=4)+
  scale_shape_manual(name="",values = c(16,1,17,2),
                     labels=c("Loose cushion",
                              "Loose open",
                              "Tight cushion",
                              "Tight open"))+
  guides(shape=guide_legend(ncol=1))+
  geom_errorbar(aes(ymin=Dim2m-Dim2se,ymax=Dim2m+Dim2se),
                width=0.01)+
  geom_errorbarh(aes(xmin=Dim1m-Dim1se,xmax=Dim1m+Dim1se),
                 height=0.01)+
  geom_hline(yintercept=0,linetype="dashed",size=.2)+
  geom_vline(xintercept=0,linetype="dashed",size=.2)+
  labs( x="PC1" , y="PC2")+
  theme_bw()+
  theme(panel.grid=element_blank(),
        plot.title = element_blank(),
        legend.position="none",
        axis.title = element_text(size=16),
        axis.text = element_text(size= 14,color = "black"))


#QH
pcoaqh<-cmdscale(vegdist(qh),k=(nrow(qh)-1),eig=TRUE, add = TRUE)
siteqh<-as.data.frame(scores(pcoaqh)[,1:2])
speciesqh<-as.data.frame(wascores(pcoaqh$points[,1:2],qh))

siteqh$g<-paste(substr(rownames(siteqh),1,2),substr(rownames(siteqh),6,7),sep = "")
siteqhm<-summarize(group_by(siteqh,g),Dim1m=mean(Dim1),Dim2m=mean(Dim2),Dim1se=sd(Dim1)/sqrt(n()),Dim2se=sd(Dim2)/sqrt(n()))
siteqhm$s<-substr(siteqhm$g,1,2);siteqhm$t<-substr(siteqhm$g,3,3);siteqhm$c<-substr(siteqhm$g,4,4);siteqhm$tc<-substr(siteqhm$g,3,4)


plotqh <- ggplot(data= siteqhm, aes(Dim1m,Dim2m))+
  geom_point( aes(shape=factor(tc)),size=6)+
  geom_text( data= speciesqh, aes(V1,V2,label=rownames(speciesqh)),size=4)+
  scale_shape_manual(name="",values = c(16,1,17,2),
                     labels=c("Loose cushion",
                              "Loose open",
                              "Tight cushion",
                              "Tight open"))+
  guides(shape=guide_legend(ncol=1))+
  geom_errorbar(aes(ymin=Dim2m-Dim2se,ymax=Dim2m+Dim2se),
                width=0.01)+
  geom_errorbarh(aes(y=Dim2m,xmin=Dim1m-Dim1se,xmax=Dim1m+Dim1se),
                 height=0.01)+
  geom_hline(yintercept=0,linetype="dashed",size=.2)+
  geom_vline(xintercept=0,linetype="dashed",size=.2)+
  labs( x="PC1" , y="PC2"  )+
  theme_bw()+
  theme(panel.grid=element_blank(),
        plot.title = element_blank(),
        legend.position="none",
        axis.title = element_text(size=16),
        axis.text = element_text(size= 14,color="black"))

#TS
pcoats<-cmdscale(vegdist(ts),k=(nrow(ts)-1),eig=TRUE, add = TRUE)
sitets<-as.data.frame(scores(pcoats)[,1:2])
speciests<-as.data.frame(wascores(pcoats$points[,1:2],ts))

sitets$g<-paste(substr(rownames(sitets),1,2),substr(rownames(sitets),6,7),sep = "")
sitetsm<-summarize(group_by(sitets,g),Dim1m=mean(Dim1),Dim2m=mean(Dim2),Dim1se=sd(Dim1)/sqrt(n()),Dim2se=sd(Dim2)/sqrt(n()))
sitetsm$s<-substr(sitetsm$g,1,2);sitetsm$t<-substr(sitetsm$g,3,3);sitetsm$c<-substr(sitetsm$g,4,4);sitetsm$tc<-substr(sitetsm$g,3,4)


plotts <- ggplot(data= sitetsm, aes(Dim1m,Dim2m))+
  geom_point( aes(shape=factor(tc)),size=6)+
  geom_text( data= speciests, aes(V1,V2,label=rownames(speciests)),size=4)+
  scale_shape_manual(name="",values = c(16,1,17,2),
                     labels=c("Loose cushion",
                              "Loose open",
                              "Tight cushion",
                              "Tight open"))+
  guides(shape=guide_legend(ncol=1))+
  geom_errorbar(aes(ymin=Dim2m-Dim2se,ymax=Dim2m+Dim2se),
                width=0.01)+
  geom_errorbarh(aes(y=Dim2m,xmin=Dim1m-Dim1se,xmax=Dim1m+Dim1se),
                 height=0.01)+

  geom_hline(yintercept=0,linetype="dashed",size=.2)+
  geom_vline(xintercept=0,linetype="dashed",size=.2)+
  coord_cartesian(ylim = c(-0.3,0.7))+
  scale_y_continuous(breaks = c(-0.3,0.0,0.3,0.6))+
  labs( x="PC1" , y="PC2"  )+
  theme_bw()+
  theme(panel.grid=element_blank(),
        plot.title = element_blank(),
        legend.position="none",
        axis.title = element_text(size=16),
        axis.text = element_text(size= 14,color = "black"))

grid.arrange(plotmy, plotql, plotqh, plotts, ncol=2) 


#run PCA of environmental variable and draw PCA plot

classenv <- read.table ( "pcatca.txt")
head(classenv)
apaov <- classenv
apaov$site <- as.factor(rep(c("MY","QH","QL","TS"),each=20,len=80))
apaov$phe <- as.factor(rep(c("L","T"),each=10,len=80))
apaov$cush <- as.factor(rep(c("LC","LO","TC","TO"),each=5,len=80))
head(apaov)
adonis(apaov[,1:7] ~ apaov$site*apaov$phe*apaov$cush,
       permutations = 9999,method = "bray")


classenv <- as.data.frame(scale(classenv, center = TRUE, scale = TRUE))
pca <- prcomp(classenv, scale = TRUE)
head(pca$sdev)
summary(pca)


loading<- as.data.frame(pca$rotation[,1:2])
score <- as.data.frame(scores(pca)[,1:2])
score$group <- as.factor(paste(substr(rownames(score),1,2),
                               substr(rownames(score),6,7),sep=""))
scorem <- summarise(group_by(score,group),
                    m1 = mean(PC1),
                    m2 = mean(PC2),
                    se1 = std.error(PC1),
                    se2 = std.error(PC2))
scorem$Sites <- substr(scorem$group,1,2)
scorem$Habitats <- substr(scorem$group,3,4)

ggplot()+
  geom_point( data= scorem, aes(m1, -m2,color=Sites,shape=Habitats),size=6)+
  scale_color_manual(name="Sites",values = c("black",
                                             "black",
                                             "black",
                                             "black"),
                     labels=c("MY",
                              "QH",
                              "QL",
                              "TS"))+
  scale_shape_manual(name="Habitats",values = c(16,1,17,2),
                     labels=c("Loose cushion",
                              "Loose open",
                              "Tight cushion",
                              "Tight open"))+
  guides(color=guide_legend(ncol=4),shape=guide_legend(ncol=4))+
  geom_errorbar ( data= scorem, aes(x=m1, y=-m2, ymin=-m2-se2, 
                                    ymax=-m2+se2, width=0.04 ))+
  geom_errorbarh ( data= scorem, aes(x=m1, y=-m2, xmin=m1-se1, 
                                     xmax=m1+se1, height=0.04 ))+
  geom_segment ( data=loading, aes(x=0, y=0, xend=PC1*3,yend=-PC2*3),
                 color="black",arrow=arrow(angle=25, length=unit(0.25,"cm"),
                                           type = "open"),size=0.7)+
  geom_text(data= loading,aes(PC1*3,-PC2*3, 
                              label=row.names(loading)),color="black",
            vjust=.5, hjust=1.5,size=5 )+
  geom_hline(yintercept=0)+
  geom_vline(xintercept=0)+
  labs( x="PC1 (38.25%)" , y="PC2 (21.32%)"  )+
  theme_bw()+
  theme(panel.grid=element_blank(),
        plot.title = element_text(size= 14),
        legend.position="none",
        legend.key = element_blank(),
        legend.title =element_blank(),
        axis.title = element_text(size= 14,color="black"),
        axis.text = element_text(size= 14,color="black"),
        axis.ticks = element_line(color="black"),
        axis.line=element_line(color = "black"))

#run the anova of cushion traits.
traits <- read.table("traits.txt",header = TRUE)
traits$g <- paste(traits$site,traits$type,sep = "")
head(traits)

summary(aov(CA ~ site*type, traits))
summary(aov(CH ~ site*type, traits))
summary(aov(CI ~ site*type, traits))
summary(aov(CB ~ site*type, traits))

TukeyHSD(aov(CH ~ site*type, traits))
TukeyHSD(aov(CI ~ site*type, traits))

#run the anova of leaf physiological data.
cushionphy <- read.table("physiology.txt",header = TRUE)
head(cushionphy)
cushionphy$LCN <- cushionphy$COC/cushionphy$CTN
summary(aovp(CLDMC ~ site*type, cushionphy, perm = "Exact"))
summary(aovp(CSLA ~ site*type, cushionphy, perm = "Exact"))
summary(aovp(LCN ~ site*type, cushionphy, perm = "Exact"))

